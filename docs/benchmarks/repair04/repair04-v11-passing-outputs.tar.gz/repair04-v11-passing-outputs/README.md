# Corrected V11 saved passing outputs

These 7 final outputs are unchanged bytes with exact original conversion contexts. They are a passing-only evidence subset; the full benchmark keeps all 37/current15 members including failures and timeouts. Historical V8 counts omitted both via-to-pad checks and are withdrawn as clean-board claims.

From the autorouter checkout at `3a59a7e12b3003056ac5ebd9a46d411ad7fec7e6` with its recorded dependencies:

```sh
bun scripts/benchmark/verify-repair04-saved-outputs.ts /path/to/repair04-v11-passing-outputs
```

The verifier hashes every file, checks checker provenance, rebuilds circuit-json from the saved traces, and explicitly enables checkViasInPads plus checkViaPadClearance in both the default and relaxed checks. It performs no routing and exits nonzero on any discrepancy or DRC error.
