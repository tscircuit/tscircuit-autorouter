from pathlib import Path
import json,hashlib,shutil,sys,subprocess
root=Path(__file__).resolve().parent
source=root/'source-v12'
manifest=json.loads((source/'source-manifest.json').read_text())
destination=root/'baseline-v12'
if destination.exists():raise RuntimeError('Fresh baseline destination already exists; do not overwrite sealed evidence')
paths=[Path(p).resolve() for p in sys.argv[1:]]
if not paths:raise RuntimeError('Pass completed full-baseline cohort directories')
sha=lambda b:hashlib.sha256(b).hexdigest()
read=lambda p:json.loads(p.read_text())
expected=[r['id'] for r in read(root/'srj33-pinned-manifest.json')['samples']]
rows={};files={};cohorts=[];first=None
invariants=['datasetCommit','validationSuite','samples','denominator','mode','enableRepair04','revision','bundleSha256','effort','timeoutMs','bunVersion','architecture','platform','relaxed','strict']
for path in paths:
 config=read(path/'configuration.json');summary=read(path/'summary.json')
 if first is None:first=config
 assert all(config[k]==first[k] for k in invariants),path
 assert config['mode']=='baseline' and config['enableRepair04'] is False
 assert config['revision']==manifest['routerCommit']==manifest['fullBaselineSourceCommit']
 assert config['bundleSha256']==manifest['fullBaselineBundleSha256']
 assert config['validationSuite']==manifest['validationSuite']=='repair04-via-pad-v1'
 assert config['samples']==expected and config['denominator']==37
 assert config['effort']==1 and config['timeoutMs']==1800000
 assert config['bunVersion']=='1.4.2' and config['architecture']=='arm64' and config['platform']=='linux'
 assert summary['revision']==config['revision'] and summary['bundleSha256']==config['bundleSha256']
 assert summary['evaluated']==len(summary['results'])==len(config['selectedSamples'])
 assert {r['sample'] for r in summary['results']}==set(config['selectedSamples'])
 cohort={'directory':path.name,'configurationSha256':sha((path/'configuration.json').read_bytes()),'summarySha256':sha((path/'summary.json').read_bytes()),'samples':config['selectedSamples']}
 cohorts.append(cohort)
 for row in summary['results']:
  sample=row['sample'];assert sample in expected and sample not in rows,sample
  assert row==read(path/f'{sample}.result.json'),sample
  checkpoint=path/f'{sample}.post-repair03.json';output=path/f'{sample}.output.json'
  if row['solved']:
   assert not row['timedOut'] and checkpoint.is_file() and output.is_file(),sample
   cp=read(checkpoint);assert cp['inputSha256']==row['inputSha256'] and cp['validationSuite']==manifest['validationSuite']
   assert isinstance(row['strictErrors'],list) and isinstance(row['relaxedErrors'],list)
  rows[sample]=row
  for p in [path/f'{sample}.result.json',checkpoint,output]:
   if p.exists():files[p.name]=p
assert set(rows)==set(expected) and len(rows)==37
assert all(rows[s]['inputSha256']==manifest['preparedInputSha256'][s] for s in expected)
ordered=[rows[s] for s in expected]
summary={'datasetCommit':first['datasetCommit'],'validationSuite':first['validationSuite'],'mode':'baseline','revision':first['revision'],'bundleSha256':first['bundleSha256'],'denominator':37,'evaluated':37,'complete':True,'solved':sum(r['solved'] for r in ordered),'relaxedPassed':sum(r['solved'] and r.get('relaxedErrors')==[] for r in ordered),'strictPassed':sum(r['solved'] and r.get('strictErrors')==[] for r in ordered),'postRepair03RelaxedPassed':sum(r.get('postRepair03RelaxedErrors')==[] for r in ordered),'results':ordered}
config={**first,'selectedSamples':expected,'sourceCohorts':cohorts,'configurationNote':'All fresh disjoint full-baseline cohorts merged after raw row/output and source/runtime identity checks; no routing result reused.'}
destination.mkdir()
for name,path in files.items():shutil.copyfile(path,destination/name)
(destination/'summary.json').write_text(json.dumps(summary,indent=2)+'\n');(destination/'configuration.json').write_text(json.dumps(config,indent=2)+'\n')
manifest['fullBaselineConfigurationSha256']=sha((destination/'configuration.json').read_bytes());manifest['fullBaselineSummarySha256']=sha((destination/'summary.json').read_bytes());(source/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
protocol=read(source/'protocol.json');protocol['baselineSummarySha256']=manifest['fullBaselineSummarySha256'];protocol['baseline']['fullBaselineConfigurationSha256']=manifest['fullBaselineConfigurationSha256'];protocol['baseline']['solved']=summary['solved'];protocol['baseline']['geometryFileCount']=sum(name.endswith('.output.json') or name.endswith('.post-repair03.json') for name in files);(source/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
proof={'freshFullBaseline':True,'samples':37,'cohorts':cohorts,'configurationSha256':manifest['fullBaselineConfigurationSha256'],'summarySha256':manifest['fullBaselineSummarySha256'],'files':[{'path':name,'sha256':sha(path.read_bytes())} for name,path in sorted(files.items())]};(root/'v12-full-baseline-merge-verification.json').write_text(json.dumps(proof,indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='results'}))
