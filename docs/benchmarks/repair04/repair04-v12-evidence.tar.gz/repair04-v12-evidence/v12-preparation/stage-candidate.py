from pathlib import Path
import json,hashlib,shutil,tarfile
root=Path(__file__).resolve().parents[1];source=root/'source-v12';transfer=root.parent/'tscircuit-autorouter/scripts/benchmark/repair04-transfer';manifest=json.loads((source/'source-manifest.json').read_text());baseline=root/'baseline-v12';summary=json.loads((baseline/'summary.json').read_text());assert summary['complete'] and summary['evaluated']==37
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert manifest['fullBaselineSummarySha256']==sha(baseline/'summary.json');assert manifest['fullBaselineConfigurationSha256']==sha(baseline/'configuration.json')
archive=source/'baseline-v12.tar.gz'
with tarfile.open(archive,'w:gz') as t:t.add(baseline,arcname='repair04-baseline-v12')
manifest['fullBaselineArchiveSha256']=sha(archive);manifest['fullBaselineArchiveFile']=archive.name;(source/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
for original,target in [('replay-v12.js','replay-v12.js'),('runner-v12.ts','runner-v12.ts'),('baseline-v12.tar.gz','baseline-v12.tar.gz')]:shutil.copyfile(source/original,transfer/target)
expected=f"{manifest['bundleSha256']}  repair04-replay-v12.js\n{manifest['runnerSha256']}  repair04-runner-v12.ts\n{manifest['fullBaselineArchiveSha256']}  repair04-baseline-v12.tar.gz\n";(transfer/'expected-candidate-sha256.txt').write_text(expected);(source/'expected-candidate-sha256.txt').write_text(expected)
plan=json.loads((source/'cohort-plan.json').read_text());case='\n'.join(f"  {c}) SAMPLES={','.join(v['samples'])} ;;" for c,v in plan['cohorts'].items())
run=f'''#!/usr/bin/env bash
set -euo pipefail
BENCHMARK_BUN=/home/runner/.bun/bin/bun
COHORT="$1"
case "$COHORT" in
{case}
  *) exit 2 ;;
esac
"$BENCHMARK_BUN" -e 'if (Bun.version !== "1.4.2" || process.arch !== "arm64" || process.platform !== "linux") throw new Error("Benchmark runtime mismatch"); console.log(JSON.stringify({{bunVersion:Bun.version,architecture:process.arch,platform:process.platform}}))'
cd /tmp
sha256sum -c repair04-v12-expected-candidate-sha256.txt
tar -xzf repair04-baseline-v12.tar.gz
uname -a > "repair04-candidate-v12-$COHORT.machine.txt"
"$BENCHMARK_BUN" /tmp/repair04-runner-v12.ts /tmp/repair04-baseline-v12 "/tmp/repair04-candidate-v12-$COHORT" /tmp/repair04-replay-v12.js 2 "$SAMPLES" > "/tmp/repair04-candidate-v12-$COHORT.log" 2>&1
'''
launch='''#!/usr/bin/env bash
set -euo pipefail
COHORT="$1"
SOURCE=scripts/benchmark/repair04-transfer
cp "$SOURCE/replay-v12.js" /tmp/repair04-replay-v12.js
cp "$SOURCE/runner-v12.ts" /tmp/repair04-runner-v12.ts
cp "$SOURCE/baseline-v12.tar.gz" /tmp/repair04-baseline-v12.tar.gz
cp "$SOURCE/expected-candidate-sha256.txt" /tmp/repair04-v12-expected-candidate-sha256.txt
cp "$SOURCE/run-v12.sh" /tmp/repair04-run-v12.sh
nohup bash /tmp/repair04-run-v12.sh "$COHORT" > "/tmp/repair04-v12-$COHORT-launch.log" 2>&1 < /dev/null &
BENCHMARK_PID=$!
printf '%s\\n' "$BENCHMARK_PID" > "/tmp/repair04-v12-$COHORT-launch.pid"
printf 'Launched candidate cohort %s with PID %s\\n' "$COHORT" "$BENCHMARK_PID"
'''
for name,content in [('run-v12.sh',run),('launch-v12.sh',launch)]:
 (transfer/name).write_text(content);(source/name).write_text(content)
peek=(root/'transfer-v11-archived/peek-v11.py').read_text().replace('v11','v12');(transfer/'peek-v12.py').write_text(peek);(source/'peek-v12.py').write_text(peek)
print(json.dumps({'bundleSha256':manifest['bundleSha256'],'baselineSummarySha256':manifest['fullBaselineSummarySha256'],'baselineConfigurationSha256':manifest['fullBaselineConfigurationSha256'],'baselineArchiveSha256':manifest['fullBaselineArchiveSha256']}))
