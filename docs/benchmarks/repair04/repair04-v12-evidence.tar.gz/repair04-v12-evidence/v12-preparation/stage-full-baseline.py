from pathlib import Path
import json,hashlib,shutil,datetime
root=Path(__file__).resolve().parents[1];source=root/'source-v12';repo=root.parent/'tscircuit-autorouter';transfer=repo/'scripts/benchmark/repair04-transfer'
if transfer.exists():shutil.move(transfer,root/'transfer-v11-archived')
transfer.mkdir()
manifest=json.loads((source/'source-manifest.json').read_text())
cohorts={'a':{'id':'tbx_01m1taehrnqtk6tzz9817djp40','samples':[46,53,4,52,40,38,25]},'b':{'id':'tbx_01m1taehsbg5wf1jn5nrqxjxbp','samples':[6,32,5,41,20,42,35,43,47]},'c':{'id':'tbx_01m1taehrx7p6tnjzeqktg53zv','samples':[48,54,50,10,1,13,12,39,34]},'d':{'id':'tbx_01m1taehsbjjqws1c4qh7kex1t','samples':[44,55,37,11]},'e':{'id':'tbx_01m1taehytg3heb25csrcm07ms','samples':[49,56,2,36]},'f':{'id':'tbx_01m1taehsdyqd0tyds2bgggdfe','samples':[51,3,45,33]}}
for c,v in cohorts.items():v['samples']=[f'sample{n:03}' for n in v['samples']]
assert len({s for v in cohorts.values() for s in v['samples']})==37
plan={'version':'v12','kind':'fresh-full-baseline','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sourceRevision':manifest['routerCommit'],'fullBaselineBundleSha256':manifest['fullBaselineBundleSha256'],'cpuCountPerMachine':4,'workersPerMachine':2,'timeoutMs':1800000,'cohorts':cohorts}
(source/'full-baseline-cohort-plan.json').write_text(json.dumps(plan,indent=2)+'\n')
shutil.copyfile(source/'full-baseline-v12.js',transfer/'full-baseline-v12.js')
(transfer/'expected-baseline-sha256.txt').write_text(f"{manifest['fullBaselineBundleSha256']}  repair04-full-baseline-v12.js\n")
case='\n'.join(f"  {c}) SAMPLES={','.join(v['samples'])} ;;" for c,v in cohorts.items())
run=f'''#!/usr/bin/env bash
set -euo pipefail
BENCHMARK_BUN=/home/runner/.bun/bin/bun
COHORT="$1"
case "$COHORT" in
{case}
  *) exit 2 ;;
esac
"$BENCHMARK_BUN" -e 'if (Bun.version !== "1.4.2" || process.arch !== "arm64" || process.platform !== "linux") throw new Error("Benchmark runtime mismatch"); console.log(JSON.stringify({{bunVersion:Bun.version,architecture:process.arch,platform:process.platform}}))'
cd /tmp
sha256sum -c repair04-v12-expected-baseline-sha256.txt
uname -a > "repair04-baseline-v12-$COHORT.machine.txt"
"$BENCHMARK_BUN" /tmp/repair04-full-baseline-v12.js --mode baseline --out-dir "/tmp/repair04-baseline-v12-$COHORT" --effort 1 --concurrency 2 --timeout-ms 1800000 --source-revision {manifest['routerCommit']} --samples "$SAMPLES" > "/tmp/repair04-baseline-v12-$COHORT.log" 2>&1
'''
launch='''#!/usr/bin/env bash
set -euo pipefail
COHORT="$1"
SOURCE=scripts/benchmark/repair04-transfer
cp "$SOURCE/full-baseline-v12.js" /tmp/repair04-full-baseline-v12.js
cp "$SOURCE/expected-baseline-sha256.txt" /tmp/repair04-v12-expected-baseline-sha256.txt
cp "$SOURCE/run-full-baseline-v12.sh" /tmp/repair04-run-full-baseline-v12.sh
nohup bash /tmp/repair04-run-full-baseline-v12.sh "$COHORT" > "/tmp/repair04-v12-baseline-$COHORT-launch.log" 2>&1 < /dev/null &
BENCHMARK_PID=$!
printf '%s\\n' "$BENCHMARK_PID" > "/tmp/repair04-v12-baseline-$COHORT-launch.pid"
printf 'Launched full-baseline cohort %s with PID %s\\n' "$COHORT" "$BENCHMARK_PID"
'''
for name,content in [('run-full-baseline-v12.sh',run),('launch-full-baseline-v12.sh',launch)]:
 (transfer/name).write_text(content);(source/name).write_text(content)
peek='''from pathlib import Path
import json,sys,subprocess
c=sys.argv[1];r=Path(f"/tmp/repair04-baseline-v12-{c}")
rows=[]
if r.exists():
 for p in sorted(r.glob("*.result.json")):
  j=json.loads(p.read_text());rows.append({k:j.get(k) for k in ["sample","solved","timedOut","elapsedTimeMs","error"]}|{"errors":len(j["relaxedErrors"]) if "relaxedErrors" in j else None})
print(json.dumps({"cohort":c,"results":rows,"active":subprocess.check_output(["pgrep","-af","repair04-full-baseline-v12.js"],text=True).splitlines() if subprocess.run(["pgrep","-f","repair04-full-baseline-v12.js"],stdout=subprocess.DEVNULL).returncode==0 else [],"logTail":Path(f"/tmp/repair04-baseline-v12-{c}.log").read_text().splitlines()[-5:] if Path(f"/tmp/repair04-baseline-v12-{c}.log").exists() else [],"launch":Path(f"/tmp/repair04-v12-baseline-{c}-launch.log").read_text() if Path(f"/tmp/repair04-v12-baseline-{c}-launch.log").exists() else None}))
'''
(transfer/'peek-baseline-v12.py').write_text(peek);(source/'peek-baseline-v12.py').write_text(peek)
print(json.dumps(plan))
