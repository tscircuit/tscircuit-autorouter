from pathlib import Path
import json,shutil,subprocess
root=Path(__file__).resolve().parents[1];test=root/'v12-preparation/merge-control-tests';test.mkdir(exist_ok=True)
source=json.loads((root/'source-v12/source-manifest.json').read_text());members=[x['id'] for x in json.loads((root/'srj33-pinned-manifest.json').read_text())['samples']];before=json.loads((root/'baseline-v12/summary.json').read_text());rows={x['sample']:x for x in before['results']}
base=json.loads((root/'v12-preparation/frozen-actual-timer-check/configuration.json').read_text());base.update(revision=source['routerCommit'],bundleSha256=source['fullBaselineBundleSha256'],bunVersion='1.4.2',architecture='arm64',platform='linux',timeoutMs=1800000,concurrency=2)
case_results=[]
for case in ['valid','wrong-bundle','duplicate-cohort','changed-result','missing-output']:
 r=test/case;r.mkdir();(r/'source-v12').mkdir();(r/'source-v12/source-manifest.json').write_text(json.dumps(source));(r/'source-v12/protocol.json').write_text('{"baseline":{}}');shutil.copyfile(root/'srj33-pinned-manifest.json',r/'srj33-pinned-manifest.json');shutil.copyfile(root/'merge-v12-full-baselines.py',r/'merge-v12-full-baselines.py')
 paths=[]
 for index in range(2):
  path=r/f'cohort{index}';path.mkdir();selection=members[index::2];config={**base,'selectedSamples':selection};summary={**before,'revision':source['routerCommit'],'bundleSha256':source['fullBaselineBundleSha256'],'evaluated':len(selection),'complete':False,'results':[rows[s] for s in selection]}
  if case=='wrong-bundle' and index==1:config['bundleSha256']='0'*64
  (path/'configuration.json').write_text(json.dumps(config));(path/'summary.json').write_text(json.dumps(summary))
  for sample in selection:
   row=dict(rows[sample]);
   if case=='changed-result' and sample==members[0]:row['elapsedTimeMs']+=1
   (path/f'{sample}.result.json').write_text(json.dumps(row))
   cp=json.loads((root/f'baseline-v12/{sample}.post-repair03.json').read_text());cp['validationSuite']='repair04-via-pad-v1';(path/f'{sample}.post-repair03.json').write_text(json.dumps(cp))
   if not(case=='missing-output' and sample==members[0]):(path/f'{sample}.output.json').symlink_to((root/f'baseline-v12/{sample}.output.json').resolve())
  paths.append(path.resolve())
 if case=='duplicate-cohort':paths.append(paths[0])
 p=subprocess.run(['python3',str(r/'merge-v12-full-baselines.py'),*[str(x) for x in paths]],capture_output=True,text=True)
 (r/'run.log').write_text(p.stdout+p.stderr);passed=(p.returncode==0)==(case=='valid');assert passed,(case,p.stderr);case_results.append({'case':case,'expectedAccepted':case=='valid','accepted':p.returncode==0,'passed':passed})
(root/'v12-full-baseline-merge-control-checks.json').write_text(json.dumps({'scope':'Synthetic coordinator integrity fixtures using fresh baseline geometry, excluded from actual V12 results','results':case_results},indent=2)+'\n');print(json.dumps(case_results))
