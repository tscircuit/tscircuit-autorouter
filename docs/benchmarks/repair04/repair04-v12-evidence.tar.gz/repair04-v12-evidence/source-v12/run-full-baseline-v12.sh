#!/usr/bin/env bash
set -euo pipefail
BENCHMARK_BUN=/home/runner/.bun/bin/bun
COHORT="$1"
case "$COHORT" in
  a) SAMPLES=sample046,sample053,sample004,sample052,sample040,sample038,sample025 ;;
  b) SAMPLES=sample006,sample032,sample005,sample041,sample020,sample042,sample035,sample043,sample047 ;;
  c) SAMPLES=sample048,sample054,sample050,sample010,sample001,sample013,sample012,sample039,sample034 ;;
  d) SAMPLES=sample044,sample055,sample037,sample011 ;;
  e) SAMPLES=sample049,sample056,sample002,sample036 ;;
  f) SAMPLES=sample051,sample003,sample045,sample033 ;;
  *) exit 2 ;;
esac
"$BENCHMARK_BUN" -e 'if (Bun.version !== "1.4.2" || process.arch !== "arm64" || process.platform !== "linux") throw new Error("Benchmark runtime mismatch"); console.log(JSON.stringify({bunVersion:Bun.version,architecture:process.arch,platform:process.platform}))'
cd /tmp
sha256sum -c repair04-v12-expected-baseline-sha256.txt
uname -a > "repair04-baseline-v12-$COHORT.machine.txt"
"$BENCHMARK_BUN" /tmp/repair04-full-baseline-v12.js --mode baseline --out-dir "/tmp/repair04-baseline-v12-$COHORT" --effort 1 --concurrency 2 --timeout-ms 1800000 --source-revision 97c7ded4754e976d3ad0d94c52630a81b268984a --samples "$SAMPLES" > "/tmp/repair04-baseline-v12-$COHORT.log" 2>&1
