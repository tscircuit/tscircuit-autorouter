import { migrateLegacyObstacleCircuitJsonMetadata } from "../../lib/testing/utils/migrate-legacy-obstacle-circuit-json-metadata"
import type { SimpleRouteJson } from "../../lib/types/srj-types"

export const DATASET_NAMES = [
  "dataset01",
  "zdwiel",
  "srj05",
  "srj11",
  "srj12",
  "srj13",
  "srj14",
  "srj15",
  "srj16",
  "srj18",
  "srj19",
  "srj20",
  "srj21",
  "srj23",
  "srj24",
  "srj27",
  "srj28",
  "srj29",
  "srj33",
] as const

export type DatasetName = (typeof DATASET_NAMES)[number]

type DatasetModule = Record<string, unknown>

export const DATASET_OPTIONS_LABEL =
  "1/dataset01, zdwiel, 5/srj05, 11/srj11, 12/srj12, 13/srj13, 14/srj14, 15/srj15, 16/srj16, 18/srj18, 19/srj19, 20/srj20, 21/srj21, 23/srj23, 24/srj24, 27/srj27, 28/srj28, 29/srj29, 33/srj33"

const datasetAliases: Record<string, DatasetName> = {
  "1": "dataset01",
  "01": "dataset01",
  dataset1: "dataset01",
  dataset01: "dataset01",
  "5": "srj05",
  "05": "srj05",
  srj5: "srj05",
  srj05: "srj05",
  "dataset-srj05": "srj05",
  "11": "srj11",
  dataset11: "srj11",
  srj11: "srj11",
  "dataset-srj11-45-degree": "srj11",
  "12": "srj12",
  dataset12: "srj12",
  srj12: "srj12",
  "dataset-srj12-bus-routing": "srj12",
  "@tsci/tscircuit.dataset-srj12-bus-routing": "srj12",
  "13": "srj13",
  dataset13: "srj13",
  srj13: "srj13",
  "dataset-srj13": "srj13",
  "@tsci/seveibar.dataset-srj13": "srj13",
  "14": "srj14",
  dataset14: "srj14",
  srj14: "srj14",
  "dataset-srj14": "srj14",
  "15": "srj15",
  dataset15: "srj15",
  srj15: "srj15",
  "dataset-srj15": "srj15",
  "16": "srj16",
  dataset16: "srj16",
  srj16: "srj16",
  "dataset-srj16": "srj16",
  "dataset-srj16-bga-breakouts": "srj16",
  "@tsci/tscircuit.dataset-srj16-bga-breakouts": "srj16",
  "18": "srj18",
  dataset18: "srj18",
  srj18: "srj18",
  "dataset-srj18": "srj18",
  "19": "srj19",
  dataset19: "srj19",
  srj19: "srj19",
  "dataset-srj19": "srj19",
  "dataset-srj19-bga-passive-overlays": "srj19",
  "@tsci/tscircuit.dataset-srj19-bga-passive-overlays": "srj19",
  "20": "srj20",
  dataset20: "srj20",
  srj20: "srj20",
  "dataset-srj20": "srj20",
  "dataset-srj20-partial-bga-breakouts": "srj20",
  "@tsci/tscircuit.dataset-srj20-partial-bga-breakouts": "srj20",
  "21": "srj21",
  dataset21: "srj21",
  srj21: "srj21",
  "dataset-srj21": "srj21",
  "multi-component-dataset-srj01": "srj21",
  "@tsci/0hmx.multi-component-dataset-srj01": "srj21",
  "23": "srj23",
  dataset23: "srj23",
  srj23: "srj23",
  "dataset-srj23": "srj23",
  "45-degree-trace-srj23": "srj23",
  "@tsci/0hmx.45-degree-trace-srj23": "srj23",
  "24": "srj24",
  dataset24: "srj24",
  srj24: "srj24",
  "dataset-srj24": "srj24",
  "@tscircuit/dataset-srj24": "srj24",
  "27": "srj27",
  dataset27: "srj27",
  srj27: "srj27",
  "dataset-srj27-power-traces": "srj27",
  "@tscircuit/dataset-srj27-power-traces": "srj27",
  "28": "srj28",
  dataset28: "srj28",
  srj28: "srj28",
  "dataset-srj28-partially-prerouted": "srj28",
  "@tscircuit/dataset-srj28-partially-prerouted": "srj28",
  "29": "srj29",
  dataset29: "srj29",
  srj29: "srj29",
  "dataset-srj29-ddr3-bga-pairs": "srj29",
  "@tscircuit/dataset-srj29-ddr3-bga-pairs": "srj29",
  "33": "srj33",
  dataset33: "srj33",
  srj33: "srj33",
  "dataset-srj33-drc-failures": "srj33",
  "@tscircuit/dataset-srj33-drc-failures": "srj33",
  zdwiel: "zdwiel",
}

export const parseDatasetName = (value: string): DatasetName | null => {
  const normalized = value.trim().toLowerCase()
  return datasetAliases[normalized] ?? null
}

export const isDatasetName = (value: string): value is DatasetName =>
  DATASET_NAMES.includes(value as DatasetName)

const loadNumberedJsonDatasetModule = async ({
  sampleCount,
  getSpecifier,
}: {
  sampleCount: number
  getSpecifier: (sampleId: string) => string
}): Promise<DatasetModule> => {
  const entries = await Promise.all(
    Array.from({ length: sampleCount }, async (_, index) => {
      const sampleId = String(index + 1).padStart(3, "0")
      return [
        `sample${sampleId}Circuit`,
        await import(getSpecifier(sampleId), { with: { type: "json" } }),
      ] as const
    }),
  )
  return Object.fromEntries(entries)
}

const datasetLoaders: Record<DatasetName, () => Promise<DatasetModule>> = {
  dataset01: async () =>
    (await import("@tscircuit/autorouting-dataset-01")) as DatasetModule,
  zdwiel: async () => (await import("zdwiel-dataset")) as DatasetModule,
  srj05: async () =>
    (await import("@tscircuit/dataset-srj05")) as DatasetModule,
  srj11: async () =>
    loadNumberedJsonDatasetModule({
      sampleCount: 26,
      getSpecifier: (sampleId) =>
        `dataset-srj11-45-degree/circuits/sample${sampleId}.circuit.simple-route.json`,
    }),
  srj12: async () =>
    loadNumberedJsonDatasetModule({
      sampleCount: 10,
      getSpecifier: (sampleId) =>
        `@tsci/tscircuit.dataset-srj12-bus-routing/circuits/sample${sampleId}/sample${sampleId}.circuit.simple-route.json`,
    }),
  srj13: async () =>
    (await import("@tsci/seveibar.dataset-srj13")) as DatasetModule,
  srj14: async () =>
    loadNumberedJsonDatasetModule({
      sampleCount: 20,
      getSpecifier: (sampleId) => {
        const sampleFileNames = [
          "sample01-source_net_5_mst1_0.srj.json",
          "sample02-source_net_3_mst0_0.srj.json",
          "sample03-source_net_5_mst0_0.srj.json",
          "sample04-source_net_20_mst0_0.srj.json",
          "sample05-source_net_20_mst2_0.srj.json",
          "sample06-source_net_14_mst0_0.srj.json",
          "sample07-source_net_23_mst1_0.srj.json",
          "sample08-source_net_24_mst1_0.srj.json",
          "sample09-source_net_19_mst1_0.srj.json",
          "sample10-source_net_0_mst2_0.srj.json",
          "sample11-source_net_11_0.srj.json",
          "sample12-source_net_15_mst1_0.srj.json",
          "sample13-source_net_15_mst2_0.srj.json",
          "sample14-source_net_22_0.srj.json",
          "sample15-source_net_1_mst2_0.srj.json",
          "sample16-source_net_7_mst0_0.srj.json",
          "sample17-source_net_13_mst0_0.srj.json",
          "sample18-source_net_26_0.srj.json",
          "sample19-source_net_12_mst0_0.srj.json",
          "sample20-source_net_2_mst1_0.srj.json",
        ]
        return `../../fixtures/datasets/dataset-srj14/${sampleFileNames[Number(sampleId) - 1]}`
      },
    }),
  srj15: async () =>
    loadNumberedJsonDatasetModule({
      sampleCount: 55,
      getSpecifier: (sampleId) =>
        `../../fixtures/datasets/dataset-srj15/sample${sampleId.slice(1)}-region-reroute.srj.json`,
    }),
  srj16: async () =>
    loadNumberedJsonDatasetModule({
      sampleCount: 200,
      getSpecifier: (sampleId) =>
        `@tsci/tscircuit.dataset-srj16-bga-breakouts/circuits/sample${sampleId}/sample${sampleId}.circuit.simple-route.json`,
    }),
  srj18: async () => {
    const module = (await import("dataset-srj18")) as DatasetModule
    const dataset = module.dataset
    return dataset && typeof dataset === "object"
      ? (dataset as DatasetModule)
      : module
  },
  srj19: async () =>
    loadNumberedJsonDatasetModule({
      sampleCount: 200,
      getSpecifier: (sampleId) =>
        `@tsci/tscircuit.dataset-srj19-bga-passive-overlays/circuits/sample${sampleId}/sample${sampleId}.circuit.simple-route.json`,
    }),
  srj20: async () =>
    loadNumberedJsonDatasetModule({
      sampleCount: 200,
      getSpecifier: (sampleId) =>
        `@tsci/tscircuit.dataset-srj20-partial-bga-breakouts/circuits/sample${sampleId}/sample${sampleId}.circuit.simple-route.json`,
    }),
  srj21: async () =>
    (await import("@tsci/0hmX.multi-component-dataset-srj01")) as DatasetModule,
  srj23: async () =>
    (await import(
      "@tsci/dataset-srj23-partially-routed-subcircuits"
    )) as DatasetModule,
  srj24: async () => {
    const module = (await import("@tscircuit/dataset-srj24")) as DatasetModule
    const dataset = module.dataset
    return dataset && typeof dataset === "object"
      ? (dataset as DatasetModule)
      : module
  },
  srj27: async () => {
    const module = (await import(
      "@tscircuit/dataset-srj27-power-traces"
    )) as DatasetModule
    const dataset = module.dataset
    return dataset && typeof dataset === "object"
      ? (dataset as DatasetModule)
      : module
  },
  srj28: async () =>
    (await import(
      "@tscircuit/dataset-srj28-partially-prerouted"
    )) as DatasetModule,
  srj29: async () => {
    const module = (await import(
      "@tscircuit/dataset-srj29-ddr3-bga-pairs"
    )) as DatasetModule
    const dataset = module.dataset
    return dataset && typeof dataset === "object"
      ? (dataset as DatasetModule)
      : module
  },
  srj33: async () =>
    (await import("@tscircuit/dataset-srj33-drc-failures")) as DatasetModule,
}

const datasetScenarioKeyPatterns: Record<DatasetName, RegExp> = {
  dataset01: /^circuit\d+$/,
  zdwiel: /^ts\d+_/,
  srj05: /^sample\d{3}.*Circuit$/,
  srj11: /^sample\d{3}Circuit$/,
  srj12: /^sample\d{3}Circuit$/,
  srj13: /^example_\d+$/,
  srj14: /^sample\d{3}Circuit$/,
  srj15: /^sample\d{3}Circuit$/,
  srj16: /^sample\d{3}Circuit$/,
  srj18: /^sample\d{3}$/,
  srj19: /^sample\d{3}Circuit$/,
  srj20: /^sample\d{3}Circuit$/,
  srj21: /^circuit\d{3}$/,
  srj23: /^circuit\d{3}$/,
  srj24: /^sample\d{3}$/,
  srj27: /^sample\d{3}$/,
  srj28: /^circuit\d{3}$/,
  srj29: /^sample\d{3}$/,
  srj33: /^sample\d{3}$/,
}

export const toSimpleRouteJson = (value: unknown): SimpleRouteJson | null => {
  if (!value || typeof value !== "object") {
    return null
  }

  const asRecord = value as Record<string, unknown>
  const unwrappedValue =
    asRecord.default && typeof asRecord.default === "object"
      ? asRecord.default
      : value
  const unwrappedRecord = unwrappedValue as Record<string, unknown>
  const candidate =
    (unwrappedRecord.simpleRouteJson &&
      typeof unwrappedRecord.simpleRouteJson === "object" &&
      unwrappedRecord.simpleRouteJson) ||
    (unwrappedRecord.simple_route_json &&
      typeof unwrappedRecord.simple_route_json === "object" &&
      unwrappedRecord.simple_route_json) ||
    unwrappedValue

  if (!candidate || typeof candidate !== "object") {
    return null
  }

  return "bounds" in candidate ? (candidate as SimpleRouteJson) : null
}

export const loadScenarios = async (
  datasetName: DatasetName,
  opts: {
    scenarioLimit?: number
    effort?: number
  } = {},
) => {
  const applyEffortOverride = <T extends SimpleRouteJson>(
    scenario: T,
    effortOverride: number,
  ) =>
    ({
      ...scenario,
      effort: effortOverride,
    }) as T & { effort: number }

  const datasetModule = await datasetLoaders[datasetName]()
  const scenarioKeyPattern = datasetScenarioKeyPatterns[datasetName]
  const allScenarios = Object.entries(datasetModule)
    .map(([name, value]) => [name, toSimpleRouteJson(value)] as const)
    .filter((entry): entry is [string, SimpleRouteJson] => Boolean(entry[1]))
    .filter(([name]) => scenarioKeyPattern.test(name))
    .sort(([a], [b]) => a.localeCompare(b))
    .map(([name, scenario]) => {
      const scenarioWithCircuitJsonMetadata =
        migrateLegacyObstacleCircuitJsonMetadata(scenario)

      return [
        name,
        opts.effort === undefined
          ? scenarioWithCircuitJsonMetadata
          : applyEffortOverride(scenarioWithCircuitJsonMetadata, opts.effort),
      ] as const
    })

  return opts.scenarioLimit
    ? allScenarios.slice(0, opts.scenarioLimit)
    : allScenarios
}

export const loadScenarioBySampleNumber = async (
  datasetName: DatasetName,
  sampleNumber: number,
  effort?: number,
) => {
  if (!Number.isFinite(sampleNumber) || sampleNumber < 1) {
    throw new Error("--sample must be a positive integer")
  }

  const scenarios = await loadScenarios(datasetName, { effort })
  const scenario = scenarios[sampleNumber - 1]

  if (!scenario) {
    throw new Error(
      `Sample ${sampleNumber} is out of range for dataset ${datasetName} (${scenarios.length} samples)`,
    )
  }

  const [scenarioName, simpleRouteJson] = scenario
  return {
    scenarioName,
    scenario: simpleRouteJson,
    sampleNumber,
    totalSamples: scenarios.length,
    sourceLabel: `${datasetName}#${sampleNumber}:${scenarioName}`,
  }
}
