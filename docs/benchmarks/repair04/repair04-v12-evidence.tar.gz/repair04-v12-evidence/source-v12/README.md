# Frozen repair04 V12 source

Router `97c7ded4754e976d3ad0d94c52630a81b268984a` and core `5b840f89af83a19f74e9d03e6eed8b8cac4487d3` are verified against exact Git blobs. Both the full-baseline bundle and candidate replay bundle use these same frozen source/dependency bytes. All37 pinned raw dataset files are verified against their manifest hashes.

The baseline runs the entire Pipeline9 with repair04 disabled and saves new post-repair03 checkpoints and final outputs. Only after all37 baseline members have a result is the exact baseline summary and raw-output fingerprint sealed. Every candidate first passes a disabled replay identity gate against its own fresh full-baseline output. No older geometry or prototype outputs are reused. All37/current15 denominators retain failures/timeouts, and all clean outputs must pass both added via-pad checks.

The full-baseline builder leaves imports for unused datasets external while bundling the actual unmodified scenarios loader, migration code, and all37 SRJ33 JSON inputs. Those other dataset branches are never invoked. Actual timer-control-flow tests are separate synthetic artifacts and do not contribute benchmark results.
