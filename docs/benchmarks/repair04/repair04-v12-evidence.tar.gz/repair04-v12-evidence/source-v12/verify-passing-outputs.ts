import { createHash } from "node:crypto"
import { readFile, readdir, writeFile } from "node:fs/promises"
import { resolve } from "node:path"
import { getDrcErrors } from "../../tscircuit-autorouter/lib/testing/getDrcErrors"
import { RELAXED_DRC_OPTIONS } from "../../tscircuit-autorouter/lib/testing/drcPresets"
import { convertToCircuitJson } from "../../tscircuit-autorouter/lib/testing/utils/convertToCircuitJson"

const root = resolve(import.meta.dir, "..")
const repo = resolve(root, "../tscircuit-autorouter")
const manifest = JSON.parse(await readFile(resolve(import.meta.dir, "source-manifest.json"), "utf8"))
const digest = (bytes: Uint8Array): string => createHash("sha256").update(bytes).digest("hex")
const sourcePaths = ["lib/testing/getDrcErrors.ts", "lib/testing/utils/convertToCircuitJson.ts", "lib/testing/drcPresets.ts", "node_modules/@tscircuit/checks/dist/index.js"]
for (const path of sourcePaths) {
  const actual = digest(new Uint8Array(await readFile(resolve(repo, path))))
  if (actual !== manifest.bundleInputsSha256[path]) throw new Error(`Frozen checker source mismatch: ${path}`)
}
const results = []
for (const cohort of "abcdef") {
  const directory = resolve(root, `candidate-v12-${cohort}`)
  if (!(await Bun.file(resolve(directory, "summary.json")).exists())) continue
  const summary = await Bun.file(resolve(directory, "summary.json")).json()
  if (summary.validationSuite !== "repair04-via-pad-v1" || summary.bundleSha256 !== manifest.bundleSha256) throw new Error("Wrong candidate provenance")
  for (const row of summary.results) {
    if (!row.solved || row.relaxedErrors.length || row.strictErrors.length) continue
    const outputBytes = await readFile(resolve(directory, `${row.sample}.candidate.json`))
    if (digest(new Uint8Array(outputBytes)) !== row.outputSha256) throw new Error(`Saved output hash mismatch: ${row.sample}`)
    if (row.inputSha256 !== manifest.preparedInputSha256[row.sample]) throw new Error(`Prepared input hash mismatch: ${row.sample}`)
    const output = JSON.parse(outputBytes.toString("utf8"))
    const contextBytes = await readFile(resolve(root, "baseline-v12", `${row.sample}.post-repair03.json`))
    const context = JSON.parse(contextBytes.toString("utf8"))
    const circuitJson = convertToCircuitJson(context.srjWithPointPairs, output.traces, {
      minTraceWidth: context.originalSrj.minTraceWidth,
      minViaDiameter: context.originalSrj.minViaDiameter,
      originalSrj: context.originalSrj,
      includeOriginalConnections: true,
    })
    const baselineOutput = JSON.parse(await readFile(resolve(root, "baseline-v12", `${row.sample}.output.json`), "utf8"))
    const baselineCircuitJson = convertToCircuitJson(context.srjWithPointPairs, baselineOutput.traces, {
      minTraceWidth: context.originalSrj.minTraceWidth,
      minViaDiameter: context.originalSrj.minViaDiameter,
      originalSrj: context.originalSrj,
      includeOriginalConnections: true,
    })
    const viaGeometry = (elements: typeof circuitJson): string[] => elements
      .filter(element => element.type === "pcb_via")
      .map(element => JSON.stringify({ x: element.x, y: element.y, outerDiameter: element.outer_diameter, holeDiameter: element.hole_diameter, layers: [...element.layers].sort() }))
      .sort()
    const beforeVias = viaGeometry(baselineCircuitJson)
    const afterVias = viaGeometry(circuitJson)
    const strict = getDrcErrors(circuitJson, { includeViaPadChecks: true })
    const relaxed = getDrcErrors(circuitJson, { ...RELAXED_DRC_OPTIONS, includeViaPadChecks: true })
    results.push({ sample: row.sample, outputSha256: digest(new Uint8Array(outputBytes)), checkpointSha256: digest(new Uint8Array(contextBytes)), strictErrorCount: strict.errors.length, relaxedErrorCount: relaxed.errors.length, strictErrors: strict.errors, relaxedErrors: relaxed.errors, circuitElementCount: circuitJson.length, baselineViaCount: beforeVias.length, candidateViaCount: afterVias.length, viaGeometryUnchanged: JSON.stringify(beforeVias) === JSON.stringify(afterVias) })
  }
}
results.sort((a,b) => a.sample.localeCompare(b.sample))
const result = {
  kind: "Independent expanded DRC evaluation of saved final output geometry; no routing executed",
  validationSuite: "repair04-via-pad-v1",
  bundleSha256: manifest.bundleSha256,
  testedSourceCommit: manifest.testedSourceCommit,
  coreCommit: manifest.coreCommit,
  checkerSourceSha256: Object.fromEntries(sourcePaths.map(path => [path, manifest.bundleInputsSha256[path]])),
  runtime: { bunVersion: Bun.version, platform: process.platform, architecture: process.arch },
  results,
}
await writeFile(resolve(root, "independent-v12-passing-outputs.json"), JSON.stringify(result, null, 2))
console.log(JSON.stringify({ verifiedOutputs: results.length, samples: results.map(r=>r.sample), allExpandedClean: results.every(r=>r.strictErrorCount===0 && r.relaxedErrorCount===0) }))
if (results.some(r=>r.strictErrorCount || r.relaxedErrorCount)) process.exitCode=1
