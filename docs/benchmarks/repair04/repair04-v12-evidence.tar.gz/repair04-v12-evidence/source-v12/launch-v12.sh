#!/usr/bin/env bash
set -euo pipefail
COHORT="$1"
SOURCE=scripts/benchmark/repair04-transfer
cp "$SOURCE/replay-v12.js" /tmp/repair04-replay-v12.js
cp "$SOURCE/runner-v12.ts" /tmp/repair04-runner-v12.ts
cp "$SOURCE/baseline-v12.tar.gz" /tmp/repair04-baseline-v12.tar.gz
cp "$SOURCE/expected-candidate-sha256.txt" /tmp/repair04-v12-expected-candidate-sha256.txt
cp "$SOURCE/run-v12.sh" /tmp/repair04-run-v12.sh
nohup bash /tmp/repair04-run-v12.sh "$COHORT" > "/tmp/repair04-v12-$COHORT-launch.log" 2>&1 < /dev/null &
BENCHMARK_PID=$!
printf '%s\n' "$BENCHMARK_PID" > "/tmp/repair04-v12-$COHORT-launch.pid"
printf 'Launched candidate cohort %s with PID %s\n' "$COHORT" "$BENCHMARK_PID"
