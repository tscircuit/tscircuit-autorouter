from pathlib import Path
import json,sys,time
cohort=sys.argv[1]
p=Path('/tmp')/f'repair04-candidate-v12-{cohort}'
summary=p/'summary.json'
rows=[]
if summary.exists():
 d=json.loads(summary.read_text())
 for r in d['results']:
  rows.append({'sample':r['sample'],'solved':r['solved'],'timedOut':r['timedOut'],'errors':len(r['relaxedErrors']) if 'relaxedErrors' in r else None,'byteExact':r.get('baselineReplayByteExact'),'error':r.get('error')})
complete={r['sample'] for r in rows}
active=[]
for log in p.glob('*.log'):
 sample=log.name.split('.')[0]
 if sample in complete:continue
 if log.name.endswith('.baseline.log') and (p/f'{sample}.candidate.log').exists():continue
 active.append({'sample':sample,'mode':log.name.split('.')[1],'lastLog':log.read_text()[-180:]})
launch=Path('/tmp')/f'repair04-v12-{cohort}-launch.log'
print(json.dumps({'cohort':cohort,'directoryExists':p.exists(),'results':rows,'active':active,'launch':launch.read_text()[-600:] if launch.exists() else None}))
