from pathlib import Path
import hashlib,json,subprocess,shutil
root=Path(__file__).resolve().parent
repo=root.parent.parent/'tscircuit-autorouter'
core=root.parent.parent/'repair04'
router_commit='97c7ded4754e976d3ad0d94c52630a81b268984a'
core_commit='5b840f89af83a19f74e9d03e6eed8b8cac4487d3'
def sha(b):return hashlib.sha256(b).hexdigest()
files={}
meta=json.loads((root/'replay-v12-metafile.json').read_text())
paths=set(meta['inputs'])
full_meta=json.loads((root/'full-baseline-v12-metafile.json').read_text())
paths.update(full_meta['inputs'])
paths.update(['package.json','scripts/benchmark/replay-repair04-srj33.ts','scripts/benchmark/compare-repair04-srj33.ts','scripts/benchmark/merge-repair04-replays.ts','scripts/benchmark/repair04-srj33.ts','scripts/benchmark/repair04-srj33.md','scripts/benchmark/verify-repair04-saved-outputs.ts','lib/testing/drcPresets.ts'])
repo_count=0;core_count=0;packages={}
for name in sorted(paths):
 p=repo/name
 if not p.is_file(): raise RuntimeError('Missing bundle input '+name)
 b=p.read_bytes()
 if not name.startswith('node_modules/'):
  expected=subprocess.check_output(['git','show',router_commit+':'+name],cwd=repo)
  assert b==expected,name
  repo_count+=1
 elif name.startswith('node_modules/@tscircuit/repair04/lib/'):
  relative=name.removeprefix('node_modules/@tscircuit/repair04/')
  expected=subprocess.check_output(['git','show',core_commit+':'+relative],cwd=core)
  assert b==expected,name
  core_count+=1
 target=root/'bundle-inputs'/name
 target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(b)
 files[name]=sha(b)
 if name.startswith('node_modules/'):
  for parent in p.parents:
   manifest=parent/'package.json'
   if manifest.is_file():
    package=json.loads(manifest.read_text());key=str(manifest.relative_to(repo))
    packages[key]={'name':package.get('name'),'version':package.get('version'),'packageJsonSha256':sha(manifest.read_bytes())}
    dest=root/'package-manifests'/key;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(manifest.read_bytes())
    break
for path in (core/'lib').rglob('*.ts'):
 relative=path.relative_to(core).as_posix();b=path.read_bytes()
 assert b==subprocess.check_output(['git','show',core_commit+':'+relative],cwd=core)
 target=root/'core-source'/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(b)
shutil.copyfile(repo/'scripts/benchmark/replay-repair04-srj33.ts',root/'runner-v12.ts')
manifest={'version':'v12','validationSuite':'repair04-via-pad-v1','routerCommit':router_commit,'testedSourceCommit':router_commit,'coreCommit':core_commit,'routerMatchesCommit':True,'pipelineMatchesCommit':True,'coreMatchesCommit':True,'verifiedRepositoryFileCount':repo_count,'verifiedBundledCoreFileCount':core_count,'bundleSha256':sha((root/'replay-v12.js').read_bytes()),'runnerSha256':sha((root/'runner-v12.ts').read_bytes()),'bundleInputsSha256':files,'bundledDependencyPackages':packages,'datasetCommit':'f566b62be0f83395d9ab63ddc068f9d645b68b16','currentDatasetCommit':'026a78cb005ab33dde24f2db8fefbfd8d8efa614','buildRuntime':{'bunVersion':subprocess.check_output(['/Users/seve/.bun/bin/bun','--version'],text=True).strip(),'platform':'darwin','architecture':'arm64'},'externalImports':meta['outputs'][next(iter(meta['outputs']))]['imports']}
(root/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k not in ['bundleInputsSha256','bundledDependencyPackages']}))
