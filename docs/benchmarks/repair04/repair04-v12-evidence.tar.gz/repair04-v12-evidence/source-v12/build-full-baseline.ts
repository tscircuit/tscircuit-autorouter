import { resolve } from "node:path"
import { mkdir, writeFile } from "node:fs/promises"
const repo = resolve(import.meta.dir, "../../tscircuit-autorouter")
const destination = process.argv[2] ? resolve(process.argv[2]) : import.meta.dir
await mkdir(destination, { recursive: true })
process.chdir(repo)
const result = await Bun.build({
  root: repo,
  entrypoints: [resolve(repo, "scripts/benchmark/repair04-srj33.ts")],
  outdir: destination,
  naming: "full-baseline-v12.js",
  target: "bun",
  metafile: true,
  plugins: [{
    name: "leave-unselected-dataset-imports-external",
    setup(builder) {
      builder.onResolve({filter: /.*/}, (args) => {
        if (args.importer.endsWith("/scripts/benchmark/scenarios.ts") &&
            !args.path.startsWith(".") &&
            args.path !== "@tscircuit/dataset-srj33-drc-failures") {
          return {path: args.path, external: true}
        }
      })
    },
  }],
})
if (!result.success) throw new Error(result.logs.join("\n"))
await writeFile(resolve(destination, "full-baseline-v12-metafile.json"), JSON.stringify(result.metafile, null, 2) + "\n")
console.log(JSON.stringify({outputs: result.outputs.map(x => ({path: x.path, bytes:x.size})), inputCount: Object.keys(result.metafile.inputs).length}))
