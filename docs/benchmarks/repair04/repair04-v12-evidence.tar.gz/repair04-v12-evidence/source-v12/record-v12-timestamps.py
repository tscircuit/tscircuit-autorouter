from pathlib import Path
import datetime,json,subprocess,sys
cohort=sys.argv[1];directory=Path(f'/tmp/repair04-candidate-v12-{cohort}')
def utc(seconds):return datetime.datetime.fromtimestamp(seconds,datetime.timezone.utc).isoformat()
rows=[]
for path in sorted(directory.glob('*.result.json')):
 if path.name.endswith(('.baseline.json.result.json','.candidate.json.result.json')):continue
 row=json.loads(path.read_text());sample=row['sample'];record={'sample':sample,'solved':row['solved'],'timedOut':row['timedOut'],'resultWrittenUtc':utc(path.stat().st_mtime),'validationAndReplayElapsedTimeMs':row.get('validationAndReplayElapsedTimeMs')}
 for mode in ['baseline','candidate']:
  log=directory/f'{sample}.{mode}.log'
  if log.exists():
   birth=int(subprocess.check_output(['stat','-c','%W',str(log)],text=True).strip());assert birth>0
   record[f'{mode}LogCreatedUtc']=utc(birth)
   if mode=='candidate':record['candidateCreationToResultSeconds']=path.stat().st_mtime-birth
 rows.append(record)
result={'scope':'Read-only filesystem creation timestamps for actual child log creation, and final result write timestamps. Log creation precedes child spawn by a small interval; birth timestamps have one-second resolution, so these are explicit timing bounds rather than exact high-resolution process-start events.','cohort':cohort,'recordedUtc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'nominalPerChildTimeoutMs':1800000,'rows':rows}
(directory/'actual-runtime-timestamps.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'cohort':cohort,'recordedCases':len(rows),'rows':rows}))
