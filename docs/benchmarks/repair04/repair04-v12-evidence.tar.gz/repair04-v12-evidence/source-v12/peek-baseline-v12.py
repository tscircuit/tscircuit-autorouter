from pathlib import Path
import json,sys,subprocess
c=sys.argv[1];r=Path(f"/tmp/repair04-baseline-v12-{c}")
rows=[]
if r.exists():
 for p in sorted(r.glob("*.result.json")):
  j=json.loads(p.read_text());rows.append({k:j.get(k) for k in ["sample","solved","timedOut","elapsedTimeMs","error"]}|{"errors":len(j["relaxedErrors"]) if "relaxedErrors" in j else None})
print(json.dumps({"cohort":c,"results":rows,"active":subprocess.check_output(["pgrep","-af","repair04-full-baseline-v12.js"],text=True).splitlines() if subprocess.run(["pgrep","-f","repair04-full-baseline-v12.js"],stdout=subprocess.DEVNULL).returncode==0 else [],"logTail":Path(f"/tmp/repair04-baseline-v12-{c}.log").read_text().splitlines()[-5:] if Path(f"/tmp/repair04-baseline-v12-{c}.log").exists() else [],"launch":Path(f"/tmp/repair04-v12-baseline-{c}-launch.log").read_text() if Path(f"/tmp/repair04-v12-baseline-{c}-launch.log").exists() else None}))
