#!/usr/bin/env bash
set -euo pipefail
COHORT="$1"
SOURCE=scripts/benchmark/repair04-transfer
cp "$SOURCE/full-baseline-v12.js" /tmp/repair04-full-baseline-v12.js
cp "$SOURCE/expected-baseline-sha256.txt" /tmp/repair04-v12-expected-baseline-sha256.txt
cp "$SOURCE/run-full-baseline-v12.sh" /tmp/repair04-run-full-baseline-v12.sh
nohup bash /tmp/repair04-run-full-baseline-v12.sh "$COHORT" > "/tmp/repair04-v12-baseline-$COHORT-launch.log" 2>&1 < /dev/null &
BENCHMARK_PID=$!
printf '%s\n' "$BENCHMARK_PID" > "/tmp/repair04-v12-baseline-$COHORT-launch.pid"
printf 'Launched full-baseline cohort %s with PID %s\n' "$COHORT" "$BENCHMARK_PID"
