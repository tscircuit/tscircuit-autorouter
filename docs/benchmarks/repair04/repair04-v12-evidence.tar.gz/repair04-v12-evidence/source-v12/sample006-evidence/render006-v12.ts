import {createHash} from "node:crypto"
import {Resvg} from "../tscircuit-autorouter/node_modules/@resvg/resvg-js"
import {getSvgFromGraphicsObject,type GraphicsObject} from "../tscircuit-autorouter/node_modules/graphics-debug"
import {convertSrjToGraphicsObject} from "../tscircuit-autorouter/lib/utils/convertSrjToGraphicsObject"
const {before,candidate,metrics}=await Bun.file(new URL("./sample006-v12-figure-data.json",import.meta.url)).json()
if(metrics.version!=="v12"||!metrics.allEndpointsExact||!metrics.allCopperWidthsPreserved||!metrics.allTraceMetadataExact||!metrics.nonTracePropertiesExact) throw Error("V12 figure requires fresh preservation audit")
const hash=(bytes:string|Uint8Array)=>createHash("sha256").update(bytes).digest("hex")
const audit=await Bun.file(new URL("./sample006-two-pass-v12-audit.json",import.meta.url)).text()
if(hash(audit)!==metrics.independentAuditSha256)throw Error("Independent audit changed")
const counts=metrics.fullOutputCounts,vias=metrics.viaAudit,stages=metrics.stageAudit
const issues=(n:number)=>`${n} DRC ${n===1?"issue":"issues"}`
const viaHeadline=vias.allFieldsExactlyEqual?`all ${vias.beforeCount} vias identical`:`${vias.beforeCount} → ${vias.afterCount} vias; geometry changes`
const changedHeadline=`${metrics.changedTraceIds.length} ${metrics.changedTraceIds.length===1?"trace changes":"traces change"}`
const viaDescription=vias.allFieldsExactlyEqual?`All ${vias.beforeCount} vias retain identical trace/net ownership, XY, layer span, copper diameter, drill diameter and other fields.`:`Via identities change; exact before and after geometry is recorded in the accompanying audit.`
const jointDescription=stages.jointInputReferenceErrors===null||stages.jointOutputReferenceErrors===null?"Joint stage statistics unavailable.":`Normal joint stage: ${stages.jointInputReferenceErrors} → ${stages.jointOutputReferenceErrors} issues.`
const advancedDescription=Object.keys(stages.repair04AdvancedStats).length===0?"Advanced stage: no repair work recorded.":`Advanced stage: ${stages.repair04AdvancedStats.acceptedRegions??"unknown"} accepted regions.`
const accepted=stages.repair04Stats.acceptedRegions??"unknown"
const stageDescription=`Trace-only pass: ${accepted} accepted ${accepted===1?"region":"regions"}. ${jointDescription} ${advancedDescription}`
const W=1540,H=1300,c={ink:"#172C34",muted:"#53666D",top:"#C8463D",bottom:"#287CAB",green:"#267650",amber:"#BD7D11",border:"#CCD7D9"}
const f=(n:number)=>Number(n.toFixed(4)).toString()
const txt=(x:number,y:number,s:string,size=18,color=c.ink,extra="")=>`<text x="${x}" y="${y}" font-size="${size}" fill="${color}" ${extra}>${s}</text>`
const box=(x:number,y:number,w:number,h:number,attr:string)=>`<rect x="${x}" y="${y}" width="${w}" height="${h}" ${attr}/>`
const ln=(x1:number,y1:number,x2:number,y2:number,attr:string)=>`<line x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" ${attr}/>`
const native=(srj:any)=>{
 const g:GraphicsObject=convertSrjToGraphicsObject(srj)
 g.points=[]
 g.lines=g.lines?.map(l=>({...l,label:undefined,strokeColor:l.layer==="z0"?c.top:"rgba(40,124,171,0.6)",zIndex:l.layer==="z0"?1:0}))
 g.rects=g.rects?.map(r=>({...r,label:undefined,fill:"rgba(191,103,91,0.25)",stroke:"none"}))
 g.circles=g.circles?.map(r=>({...r,label:undefined,fill:c.bottom,stroke:"none"}))
 for(const t of srj.traces)for(const v of t.route)if(v.route_type==="via"&&v.via_hole_diameter)g.circles!.push({center:{x:v.x,y:v.y},radius:v.via_hole_diameter/2,fill:"white",stroke:"none"})
 // Explicit invisible reference extent fixes identical 38 px/mm projection in
 // graphics-debug: (1600 - 2*40px native padding) / 40mm.
 g.rects!.push({center:{x:0,y:0},width:40,height:40,fill:"none",stroke:"none"})
 const svg=getSvgFromGraphicsObject(g,{backgroundColor:"white",svgWidth:1600,svgHeight:1600,includeTextLabels:false})
 return svg.slice(svg.indexOf(">")+1,svg.lastIndexOf("</svg>"))
}
const bNative=native(before),aNative=native(candidate)
const overview={minX:-8,maxX:8,minY:-7.5,maxY:8.5}
const detail={minX:-4.65,maxX:-.15,minY:-3.1,maxY:-.56875}
const err=metrics.errorsBefore.relaxed.errorsWithCenters.find((e:any)=>e.center)?.center
if(err&&(err.x<detail.minX||err.x>detail.maxX||err.y<detail.minY||err.y>detail.maxY))throw Error("Measured defect needs a different detail window")
function plot(x:number,y:number,w:number,h:number,bounds:any,content:string,error:boolean,zoom:boolean){
 const scale=w/(bounds.maxX-bounds.minX),sx=(v:number)=>x+(v-bounds.minX)*scale,sy=(v:number)=>y+(bounds.maxY-v)*scale
 const vx=800+38*bounds.minX,vy=800-38*bounds.maxY,vw=38*(bounds.maxX-bounds.minX),vh=38*(bounds.maxY-bounds.minY)
 let s=`<svg x="${x}" y="${y}" width="${w}" height="${h}" viewBox="${vx} ${vy} ${vw} ${vh}" overflow="hidden">${content}</svg>`
 if(!zoom){s+=box(sx(detail.minX),sy(detail.maxY),(detail.maxX-detail.minX)*scale,(detail.maxY-detail.minY)*scale,`fill="none" stroke="${c.muted}" stroke-width="1.3" stroke-dasharray="5 4"`)}
 if(error&&err){const r=zoom?23:14;s+=`<circle cx="${sx(err.x)}" cy="${sy(err.y)}" r="${r}" fill="none" stroke="${c.amber}" stroke-width="3"/>`;if(zoom){s+=ln(x+246,y+32,sx(err.x)-r,sy(err.y)-r,`stroke="${c.amber}" stroke-width="1.5"`);s+=box(x+14,y+12,242,28,'fill="white" fill-opacity="0.96"');s+=txt(x+22,y+32,"Measured baseline DRC issue",15,c.amber)}}
 s+=box(x,y,w,h,`fill="none" stroke="${c.border}" stroke-width="1"`)
 const bar=zoom?.5:2,bx=x+22,by=y+h-22
 s+=ln(bx,by,bx+bar*scale,by,`stroke="${c.ink}" stroke-width="2"`)
 s+=ln(bx,by-4,bx,by+4,`stroke="${c.ink}" stroke-width="2"`)+ln(bx+bar*scale,by-4,bx+bar*scale,by+4,`stroke="${c.ink}" stroke-width="2"`)
 s+=txt(bx+bar*scale/2,by-9,`${bar} mm`,14,c.ink,'text-anchor="middle"')
 return s
}
let s=`<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" role="img" aria-labelledby="title desc"><title id="title">Corrected repair04 sample006 final-output comparison</title><desc id="desc">Actual complete final baseline and V12 candidate outputs. Expanded strict DRC changes from ${counts.strictBefore} to ${counts.strictAfter}, and relaxed DRC from ${counts.relaxedBefore} to ${counts.relaxedAfter}. ${viaDescription} Overview windows cover sixteen by sixteen millimeters. ${changedHeadline}. ${stageDescription} This is a one-board example, not a dataset performance claim.</desc><rect width="100%" height="100%" fill="white"/><g font-family="Helvetica,Arial,sans-serif">`
s+=txt(70,58,"repair04 · sample006 · corrected comparison",33,c.ink,'font-weight="600"')
s+=txt(70,96,`Complete final outputs · ${viaHeadline} · ${changedHeadline}`,22,c.muted)
s+=txt(70,145,"Baseline · repair04 disabled",23,c.ink,'font-weight="600"')
s+=txt(710,145,issues(counts.strictBefore),22,counts.strictBefore?c.amber:c.green,'text-anchor="end" font-weight="600"')
s+=txt(830,145,"Candidate · repair04 enabled",23,c.ink,'font-weight="600"')
s+=txt(1470,145,issues(counts.strictAfter),22,counts.strictAfter?c.amber:c.green,'text-anchor="end" font-weight="600"')
s+=txt(70,174,"16 × 16 mm view of saved final board",16,c.muted)+txt(830,174,`Same scale; strict ${counts.strictAfter} / relaxed ${counts.relaxedAfter} errors`,16,c.muted)
s+=plot(70,196,640,640,overview,bNative,true,false)
s+=plot(830,196,640,640,overview,aNative,false,false)
s+=txt(70,872,"Detail · saved baseline geometry",19,c.ink,'font-weight="600"')
s+=txt(830,872,"Detail · saved candidate geometry",19,c.ink,'font-weight="600"')
s+=plot(70,894,640,360,detail,bNative,true,true)
s+=plot(830,894,640,360,detail,aNative,false,true)
// Keep document annotations outside the native copper render.
s=s.replace(`height="${H}" viewBox="0 0 ${W} ${H}"`,`height="1436" viewBox="0 0 ${W} 1436"`)
s+=ln(70,1287,105,1287,`stroke="${c.top}" stroke-width="5"`)+txt(117,1293,"Top copper",16)
s+=ln(279,1287,314,1287,`stroke="${c.bottom}" stroke-width="5" stroke-dasharray="7 5"`)+txt(326,1293,"Bottom copper",16)
s+=box(513,1278,23,18,'fill="rgba(191,103,91,0.25)"')+txt(548,1293,"Pads / fixed obstacles",16)
s+=`<circle cx="798" cy="1286" r="8" fill="${c.bottom}"/><circle cx="798" cy="1286" r="4" fill="white"/>`+txt(817,1293,"Via copper + drill",16)
s+=txt(1040,1293,"Copper widths and drill sizes are to scale",16,c.muted)
s+=txt(70,1333,viaDescription,17,c.muted)
s+=txt(70,1361,stageDescription,17,c.muted)
s+=ln(70,1381,1470,1381,`stroke="${c.border}" stroke-width="1"`)
s+=txt(70,1410,`Frozen V12 · core ${metrics.source.coreCommit.slice(0,7)} · Pipeline9 ${metrics.source.routerCommit.slice(0,7)} · candidate SHA-256 ${metrics.source.outputHashes.candidate.slice(0,8)}…${metrics.source.outputHashes.candidate.slice(-4)} · expanded via/pad checks included`,15,c.muted)
s+="</g></svg>"
const out=new URL("../../outputs/repair04-v12-srj33-sample006-corrected.svg",import.meta.url)
await Bun.write(out,s)
const png=new Resvg(s,{fitTo:{mode:"width",value:W*2},font:{loadSystemFonts:true}}).render().asPng()
await Bun.write(new URL("../../outputs/repair04-v12-srj33-sample006-corrected.png",import.meta.url),png)
metrics.renderedFigureSha256=hash(s)
metrics.renderedPngSha256=hash(png)
await Bun.write(new URL("../../outputs/repair04-v12-srj33-sample006-corrected-metrics.json",import.meta.url),JSON.stringify(metrics,null,2)+"\n")
console.log(JSON.stringify({svg:out.pathname,pngBytes:png.length,errorCenter:err,counts,viaHeadline,changedHeadline,stageDescription}))
