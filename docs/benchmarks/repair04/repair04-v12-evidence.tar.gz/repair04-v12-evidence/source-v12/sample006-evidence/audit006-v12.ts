import { createHash } from 'node:crypto'
import { resolve, dirname, join } from 'node:path'
import { getDrcErrors } from '../tscircuit-autorouter/lib/testing/getDrcErrors'
import { RELAXED_DRC_OPTIONS } from '../tscircuit-autorouter/lib/testing/drcPresets'
import { convertToCircuitJson } from '../tscircuit-autorouter/lib/testing/utils/convertToCircuitJson'

const [candidateArgument, baselineArgument] = process.argv.slice(2)
if (!candidateArgument || !baselineArgument) throw Error('Usage: bun audit006-v12.ts candidate/sample006.candidate.json baseline-v12-directory')
const root = resolve(import.meta.dir, '../..')
const sourceFile = join(root, 'work/repair04-benchmark/source-v12/source-manifest.json')
const source = await Bun.file(sourceFile).json()
if (source.version !== 'v12' || source.fullBaselineSourceCommit !== source.routerCommit) throw Error('Wrong fresh paired source')
const candidateFile = resolve(candidateArgument), baselineDir = resolve(baselineArgument)
const candidateResultFile = join(dirname(candidateFile), 'sample006.result.json')
const baselineResultFile = join(baselineDir, 'sample006.result.json')
const candidateConfigFile = join(dirname(candidateFile), 'configuration.json')
const baselineConfigFile = join(baselineDir, 'configuration.json')
const files = {baseline:join(baselineDir,'sample006.output.json'),candidate:candidateFile,context:join(baselineDir,'sample006.post-repair03.json')}
const hash = async(file:string):Promise<string> => createHash('sha256').update(new Uint8Array(await Bun.file(file).arrayBuffer())).digest('hex')
const hashes = Object.fromEntries(await Promise.all(Object.entries(files).map(async([key,file])=>[key,await hash(file)])))
const [before,candidate,context,result,baselineResult,config,baselineConfig] = await Promise.all([files.baseline,files.candidate,files.context,candidateResultFile,baselineResultFile,candidateConfigFile,baselineConfigFile].map(path=>Bun.file(path).json()))
if (result.sample!=='sample006'||baselineResult.sample!=='sample006'||!result.solved||!baselineResult.solved||result.timedOut||baselineResult.timedOut||result.outputSha256!==hashes.candidate||!result.baselineReplayMatches) throw Error('Missing actual complete candidate and fresh baseline proof')
if (result.inputSha256!==source.preparedInputSha256.sample006||baselineResult.inputSha256!==result.inputSha256) throw Error('Fresh prepared input identity mismatch')
if (config.bundleSha256!==source.bundleSha256||config.validationSuite!=='repair04-via-pad-v1'||baselineConfig.bundleSha256!==source.fullBaselineBundleSha256||baselineConfig.revision!==source.routerCommit||baselineConfig.enableRepair04!==false) throw Error('Figure configuration differs from frozen source')
const equal = (a:any,b:any):boolean => JSON.stringify(a)===JSON.stringify(b)
const viaIdentities = (srj:any):any[] => srj.traces.flatMap((trace:any)=>trace.route.filter((p:any)=>p.route_type==='via').map((via:any,viaOrdinal:number)=>({pcb_trace_id:trace.pcb_trace_id,connection_name:trace.connection_name,connectsTo:trace.connectsTo??null,viaOrdinal,via}))).sort((a:any,b:any)=>a.pcb_trace_id<b.pcb_trace_id?-1:a.pcb_trace_id>b.pcb_trace_id?1:a.viaOrdinal-b.viaOrdinal)
const compare = (before:any,after:any):any => {
 const expected = new Map(before.traces.map((trace:any)=>[trace.pcb_trace_id,trace])), actual = new Map(after.traces.map((trace:any)=>[trace.pcb_trace_id,trace]))
 if(expected.size!==before.traces.length||actual.size!==after.traces.length) throw Error('Duplicate trace identity')
 const ids = Array.from(expected.keys()).sort(), actualIds = Array.from(actual.keys()).sort()
 const nonTraceBefore={...before};delete nonTraceBefore.traces
 const nonTraceAfter={...after};delete nonTraceAfter.traces
 const traces=ids.map((id:any)=>{
  const b:any=expected.get(id),a:any=actual.get(id)
  if(!a)return{id,missing:true}
  const beforeMetadata={...b};delete beforeMetadata.route
  const afterMetadata={...a};delete afterMetadata.route
  const beforeWidths=[...new Set(b.route.filter((p:any)=>p.route_type==='wire').map((p:any)=>p.width))].sort(),afterWidths=[...new Set(a.route.filter((p:any)=>p.route_type==='wire').map((p:any)=>p.width))].sort()
  const changed=!equal(b,a)
  // Changed variable-width geometry requires a separate segment-level audit;
  // this example may claim preservation only when unchanged or uniform.
  return{id,changed,metadataExact:equal(beforeMetadata,afterMetadata),firstPointExact:equal(b.route[0],a.route[0]),lastPointExact:equal(b.route.at(-1),a.route.at(-1)),beforeWidths,afterWidths,widthsPreserved:!changed||(beforeWidths.length===1&&afterWidths.length===1&&beforeWidths[0]===afterWidths[0]),...(changed?{before:b,after:a}:{})}
 })
 const beforeVias=viaIdentities(before),afterVias=viaIdentities(after)
 return{sameTraceIds:equal(ids,actualIds),nonTracePropertiesExact:equal(nonTraceBefore,nonTraceAfter),viaCountBefore:beforeVias.length,viaCountAfter:afterVias.length,allViaIdentitiesExact:equal(beforeVias,afterVias),allTraceMetadataExact:traces.every((t:any)=>t.metadataExact),allEndpointsExact:traces.every((t:any)=>t.firstPointExact&&t.lastPointExact),allCopperWidthsPreserved:traces.every((t:any)=>t.widthsPreserved),changedTraceIds:traces.filter((t:any)=>t.changed).map((t:any)=>t.id),traces}
}
const evaluate=(output:any):any=>{
 const circuitJson=convertToCircuitJson(context.srjWithPointPairs,output.traces,{minTraceWidth:context.originalSrj.minTraceWidth,minViaDiameter:context.originalSrj.minViaDiameter,originalSrj:context.originalSrj,includeOriginalConnections:true})
 const strict=getDrcErrors(circuitJson,{includeViaPadChecks:true}),relaxed=getDrcErrors(circuitJson,{...RELAXED_DRC_OPTIONS,includeViaPadChecks:true})
 return{circuitElementCount:circuitJson.length,strictErrorCount:strict.errors.length,relaxedErrorCount:relaxed.errors.length,strictErrors:strict.errorsWithCenters,relaxedErrors:relaxed.errorsWithCenters}
}
const checkerFiles=['lib/testing/getDrcErrors.ts','lib/testing/drcPresets.ts','lib/testing/utils/convertToCircuitJson.ts','node_modules/@tscircuit/checks/dist/index.js']
const checkerSourceSha256=Object.fromEntries(await Promise.all(checkerFiles.map(async(file)=>[file,await hash(join(root,'work/tscircuit-autorouter',file))])))
for(const [path,digest] of Object.entries(checkerSourceSha256))if(source.bundleInputsSha256[path]!==digest)throw Error(`Checker differs from frozen V12: ${path}`)
const baselineComparison=compare(before,candidate),baselineDrc=evaluate(before),candidateDrc=evaluate(candidate)
for(const [row,drc] of [[baselineResult,baselineDrc],[result,candidateDrc]])for(const kind of ['strict','relaxed'])if(row[`${kind}Errors`].length!==drc[`${kind}ErrorCount`])throw Error('Independent checker count differs from frozen row')
const checkerOptions={strict:{includeViaPadChecks:true},relaxed:{...RELAXED_DRC_OPTIONS,includeViaPadChecks:true}}
const report={kind:'Independent saved-output audit: no routing executed',label:'v12',files,sha256:hashes,validationSuite:'repair04-via-pad-v1',runtime:{bunVersion:Bun.version,platform:process.platform,architecture:process.arch},frozenRun:{routerCommit:source.routerCommit,coreCommit:source.coreCommit,bundleSha256:source.bundleSha256,sourceManifestSha256:await hash(sourceFile)},evidence:{candidateResultSha256:await hash(candidateResultFile),baselineResultSha256:await hash(baselineResultFile),candidateConfigurationSha256:await hash(candidateConfigFile),baselineConfigurationSha256:await hash(baselineConfigFile)},checkerSourceSha256,checkerOptions,baseline:baselineDrc,candidate:candidateDrc,baselineComparison,baselineViaIdentities:viaIdentities(before),candidateViaIdentities:viaIdentities(candidate)}
const auditFile=join(import.meta.dir,'sample006-two-pass-v12-audit.json')
await Bun.write(auditFile,JSON.stringify(report,null,2)+'\n')
const repair04Stats=result.repair04Stats??{},repair04AdvancedStats=result.repair04AdvancedStats??{},joint=result.jointRepairStats??{}
const metrics={version:'v12',sample:'sample006',scope:'Complete fresh V12 final outputs, disabled versus enabled repair04; identical frozen upstream routing source',source:{coreCommit:source.coreCommit,routerCommit:source.routerCommit,bundleSha256:source.bundleSha256,outputHashes:hashes},validationSuite:report.validationSuite,checkerOptions,fullOutputCounts:{strictBefore:baselineDrc.strictErrorCount,strictAfter:candidateDrc.strictErrorCount,relaxedBefore:baselineDrc.relaxedErrorCount,relaxedAfter:candidateDrc.relaxedErrorCount},viaAudit:{beforeCount:report.baselineViaIdentities.length,afterCount:report.candidateViaIdentities.length,allFieldsExactlyEqual:baselineComparison.allViaIdentitiesExact,beforeIdentities:report.baselineViaIdentities,afterIdentities:report.candidateViaIdentities},changedTraceIds:baselineComparison.changedTraceIds,allEndpointsExact:baselineComparison.allEndpointsExact,allCopperWidthsPreserved:baselineComparison.allCopperWidthsPreserved,allTraceMetadataExact:baselineComparison.allTraceMetadataExact,nonTracePropertiesExact:baselineComparison.nonTracePropertiesExact,baselineReplayByteExact:result.baselineReplayByteExact,stageAudit:{repair04Stats,repair04AdvancedStats,jointInputReferenceErrors:joint.initialFinalReferenceDrcIssueCount??null,jointOutputReferenceErrors:joint.outputFinalReferenceDrcIssueCount??null},errorsBefore:{strict:{errors:baselineDrc.strictErrors,errorsWithCenters:baselineDrc.strictErrors},relaxed:{errors:baselineDrc.relaxedErrors,errorsWithCenters:baselineDrc.relaxedErrors}},errorsAfter:{strict:{errors:candidateDrc.strictErrors,errorsWithCenters:candidateDrc.strictErrors},relaxed:{errors:candidateDrc.relaxedErrors,errorsWithCenters:candidateDrc.relaxedErrors}},independentAuditSha256:await hash(auditFile)}
await Bun.write(join(import.meta.dir,'sample006-v12-figure-data.json'),JSON.stringify({before,candidate,metrics},null,2)+'\n')
console.log(JSON.stringify({auditFile,sha256:hashes,counts:metrics.fullOutputCounts,baselineComparison:{...baselineComparison,traces:undefined},stageAudit:metrics.stageAudit},null,2))
if(!baselineComparison.sameTraceIds||!baselineComparison.allEndpointsExact||!baselineComparison.allCopperWidthsPreserved||!baselineComparison.allTraceMetadataExact||!baselineComparison.nonTracePropertiesExact)throw Error('Candidate needs further preservation review before illustration')
