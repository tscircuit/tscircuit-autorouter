from pathlib import Path
import json, hashlib, platform
repo=Path(__file__).resolve().parents[2]/"tscircuit-autorouter"
out=Path(__file__).resolve().parent/"build-environment"
out.mkdir(exist_ok=True)
manifest=json.loads((out.parent/"source-manifest.json").read_text())
lockfiles=[]
for name in ["bun.lock","bun.lockb","package-lock.json","yarn.lock","pnpm-lock.yaml"]:
 p=repo/name
 if p.exists():
  b=p.read_bytes();(out/name).write_bytes(b);lockfiles.append({"name":name,"sha256":hashlib.sha256(b).hexdigest()})
(out/"router-package.json").write_bytes((repo/"package.json").read_bytes())
(out/"inventory.json").write_text(json.dumps({"scope":"Exact dependencies that contribute bytes to frozen replay bundle; package manifests and every included source file are archived separately", "bunVersion":"1.4.1","platform":"darwin","architecture":"arm64","lockfiles":lockfiles,"packages":manifest["bundledDependencyPackages"]},indent=2)+"\n")
print(json.dumps({"bundledPackages":len(manifest["bundledDependencyPackages"]),"lockfiles":lockfiles}))
