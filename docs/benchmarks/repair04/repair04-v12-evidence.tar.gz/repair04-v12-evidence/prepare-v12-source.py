from pathlib import Path
import hashlib,json,subprocess,shutil,sys,re
root=Path(__file__).resolve().parent
repo=root.parent/'tscircuit-autorouter';source=root/'source-v12'
router_commit,core_commit=sys.argv[1:3]
source.mkdir(exist_ok=True)
sha=lambda b:hashlib.sha256(b).hexdigest()
prior=root/'source-v11'
script=(prior/'freeze-source.py').read_text().replace('v11','v12')
script=re.sub(r"router_commit='[0-9a-f]{40}'",f'router_commit={router_commit!r}',script)
script=re.sub(r"core_commit='[0-9a-f]{40}'",f'core_commit={core_commit!r}',script)
script=script.replace("paths=set(meta['inputs'])", "paths=set(meta['inputs'])\nfull_meta=json.loads((root/'full-baseline-v12-metafile.json').read_text())\npaths.update(full_meta['inputs'])")
(source/'freeze-source.py').write_text(script)
shutil.copyfile(prior/'dependency-inventory.py',source/'dependency-inventory.py')
shutil.copyfile(root/'v12-preparation/build-full-baseline.ts',source/'build-full-baseline.ts')
subprocess.run(['/Users/seve/.bun/bin/bun',str(root/'v12-preparation/build-full-baseline.ts'),str(source)],check=True)
subprocess.run(['/Users/seve/.bun/bin/bun','build','scripts/benchmark/replay-repair04-checkpoint.ts','--target=bun',f'--outfile={source}/replay-v12.js',f'--metafile={source}/replay-v12-metafile.json','--external=canvas','--external=sharp'],cwd=repo,check=True)
subprocess.run(['python3',str(source/'freeze-source.py')],check=True)
manifest=json.loads((source/'source-manifest.json').read_text())
manifest.update(analysisToolsCommit=router_commit,fullBaselineSourceCommit=router_commit,fullBaselineBundleFile='full-baseline-v12.js',fullBaselineBundleSha256=sha((source/'full-baseline-v12.js').read_bytes()),fullBaselineProtocol='Fresh full Pipeline9 routing with enableRepair04:false on all37 pinned inputs. No historical checkpoint/output reuse.')
meta=json.loads((source/'full-baseline-v12-metafile.json').read_text());manifest['fullBaselineBundleInputsSha256']={p:manifest['bundleInputsSha256'][p] for p in meta['inputs']};manifest['fullBaselineExternalImports']=meta['outputs'][next(iter(meta['outputs']))]['imports']
data=repo/'node_modules/@tscircuit/dataset-srj33-drc-failures'
pinned=json.loads((root/'srj33-pinned-manifest.json').read_text())
raw=[]
for entry in pinned['samples']:
 b=(data/entry['input']).read_bytes();assert sha(b)==entry['inputSha256'],entry['id'];raw.append({'sample':entry['id'],'path':entry['input'],'rawInputSha256':sha(b)})
assert len(raw)==37
manifest['verifiedRawDatasetInputs']=raw
prepared_script='import {createHash} from "node:crypto"; import {loadScenarios} from "./scripts/benchmark/scenarios"; const rows=await loadScenarios("srj33"); console.log(JSON.stringify(Object.fromEntries(rows.map(([name,srj])=>[name,createHash("sha256").update(JSON.stringify(srj)).digest("hex")]))));'
prepared_bytes=subprocess.check_output(['/Users/seve/.bun/bin/bun','-e',prepared_script],cwd=repo)
(source/'prepared-dataset-inputs.json').write_bytes(prepared_bytes)
manifest['preparedInputSha256']=json.loads(prepared_bytes)
assert len(manifest['preparedInputSha256'])==37
(source/'source-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
subprocess.run(['python3',str(source/'dependency-inventory.py')],check=True)
protocol={'version':'v12','validationSuite':'repair04-via-pad-v1','sourceRouterCommit':router_commit,'sourceCommit':router_commit,'coreCommit':core_commit,'bundleSha256':manifest['bundleSha256'],'frozenBundleSha256':manifest['bundleSha256'],'runnerSha256':manifest['runnerSha256'],'fullBaselineBundleSha256':manifest['fullBaselineBundleSha256'],'baselineDirectory':'baseline-v12','datasetCommit':manifest['datasetCommit'],'currentDatasetCommit':manifest['currentDatasetCommit'],'denominator':37,'currentDenominator':15,'effort':1,'cacheProvider':None,'perSolverTimeoutMs':1800000,'workersPerMachine':2,'cpuCountPerMachine':4,'runtime':{'bunVersion':'1.4.2','architecture':'arm64','platform':'linux'},'baseline':{'routingSourceCommit':router_commit,'fullPipelineBaselineCount':37,'upstreamRoutingRepeated':True,'historicalCheckpointReuse':False,'enableRepair04':False,'fullBaselineBundleSha256':manifest['fullBaselineBundleSha256'],'expandedMetadataRuntime':{'bunVersion':'1.4.2','platform':'linux','architecture':'arm64'}},'replay':{'effort':1,'workersPerMachine':2,'machineCpuCount':4,'machineCount':6,'baselineGate':'Real disabled Pipeline9 tail must reproduce the newly saved full baseline output. Record byte-exact status and maximum numeric difference. At most1e-12 numeric-only difference is accepted by the unchanged runner, never structure/metadata differences.','timeoutPerChildMs':1800000,'denominator':'All37 pinned inputs and all15 members of the separately pinned current dataset, retaining failures/timeouts.','expandedFinalCheckOptions':{'strict':{'includeViaPadChecks':True},'relaxed':{'traceClearance':.1,'viaClearance':.1,'includeViaPadChecks':True}}},'identityGate':'Every successful fresh full baseline gets a disabled replay identity gate before its enabled candidate. Failed full baselines remain denominator members and are not silently replaced.','validation':'Actual saved final geometry with original SRJ conversion context; both default and relaxed checks explicitly include checkViasInPads and checkViaPadClearance.','timeoutPolicy':'Each full baseline, disabled replay gate, and enabled candidate has its own hard30min timer. Infrastructure interruption is distinct and does not become a solver timeout.','timingInterpretation':'Full baseline timings include upstream routing; candidate timings start afterrepair03 and are not a speed comparison.','candidatePolicy':'Production defaults only: planar3regions/512candidates, guarded joint repair, advanced32regions/8000 bridge candidates with traceOnlyFirst:false, length matching and power routing. Core preserves atomic through-obstacle transitions and permits JSON-roundtripped optional metadata.','knownLimitations':'HistoricalV8 clean-board claims omitted both via-pad checks and are withdrawn. V9/V10/V11 are separate frozen historical comparisons. V12 repeats the entire baseline after merging current main; no historical route outputs or checkpoints are reused.','independentValidation':'Every passing saved final output is independently reconverted and checked; cached counts are insufficient.'}
(source/'protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
(source/'README.md').write_text(f'''# Frozen repair04 V12 source

Router `{router_commit}` and core `{core_commit}` are verified against exact Git blobs. Both the full-baseline bundle and candidate replay bundle use these same frozen source/dependency bytes. All37 pinned raw dataset files are verified against their manifest hashes.

The baseline runs the entire Pipeline9 with repair04 disabled and saves new post-repair03 checkpoints and final outputs. Only after all37 baseline members have a result is the exact baseline summary and raw-output fingerprint sealed. Every candidate first passes a disabled replay identity gate against its own fresh full-baseline output. No older geometry or prototype outputs are reused. All37/current15 denominators retain failures/timeouts, and all clean outputs must pass both added via-pad checks.

The full-baseline builder leaves imports for unused datasets external while bundling the actual unmodified scenarios loader, migration code, and all37 SRJ33 JSON inputs. Those other dataset branches are never invoked. Actual timer-control-flow tests are separate synthetic artifacts and do not contribute benchmark results.
''')
print(json.dumps({k:manifest[k] for k in ['version','routerCommit','coreCommit','bundleSha256','runnerSha256','fullBaselineBundleSha256','verifiedRepositoryFileCount','verifiedBundledCoreFileCount']}))
