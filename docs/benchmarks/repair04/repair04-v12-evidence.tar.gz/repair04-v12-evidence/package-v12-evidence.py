from pathlib import Path
import hashlib,io,json,tarfile,shutil,sys
root=Path(__file__).resolve().parent
outputs=root.parents[1]/'outputs'
def read(name):return json.loads((root/name).read_text())
def sha(data):return hashlib.sha256(data).hexdigest()
merged=read('candidate-v12-complete/summary.json')
assert merged['complete'] and merged['evaluated']==37 and merged['validationSuite']=='repair04-via-pad-v1'
assert len({r['sample'] for r in merged['results']})==37
source=read('source-v12/source-manifest.json')
raw_inputs={r['id']:r['inputSha256'] for r in read('srj33-pinned-manifest.json')['samples']}
assert merged['bundleSha256']==source['bundleSha256']
for filename,denominator in [('comparison-v12-current15.json',15),('comparison-v12-legacy37.json',37)]:
 comparison=read(filename)
 assert comparison['validationSuite']=='repair04-via-pad-v1'
config=read('candidate-v12-complete/configuration.json')
independent=read('independent-v12-passing-outputs.json')
passes={r['sample'] for r in merged['results'] if r['solved'] and not r['relaxedErrors'] and not r['strictErrors']}
assert passes=={r['sample'] for r in independent['results']}
assert all(r['strictErrorCount']==0 and r['relaxedErrorCount']==0 for r in independent['results'])
artifact=root/'passing-output-artifact-v12'/'repair04-v12-passing-outputs'
artifact.mkdir(parents=True,exist_ok=True)
samples=[]
for sample in sorted(passes):
 cohort=next(c for c in 'abcdef' if (root/f'candidate-v12-{c}/{sample}.result.json').exists())
 output_name=f'{sample}.candidate.json'
 output_bytes=(root/f'candidate-v12-{cohort}'/output_name).read_bytes()
 checkpoint_bytes=(root/'baseline-v12'/f'{sample}.post-repair03.json').read_bytes()
 checkpoint=json.loads(checkpoint_bytes)
 context_name=f'{sample}.context.json'
 context_bytes=(json.dumps({'originalSrj':checkpoint['originalSrj'],'srjWithPointPairs':checkpoint['srjWithPointPairs']},separators=(',',':'))+'\n').encode()
 (artifact/output_name).write_bytes(output_bytes);(artifact/context_name).write_bytes(context_bytes)
 samples.append({'sample':sample,'sourceCohort':f'candidate-v12-{cohort}','outputFile':output_name,'outputSha256':sha(output_bytes),'outputBytes':len(output_bytes),'contextFile':context_name,'contextSha256':sha(context_bytes),'contextBytes':len(context_bytes),'baselineCheckpointSha256':sha(checkpoint_bytes),'preparedInputSha256':checkpoint['inputSha256'],'rawDatasetInputSha256':raw_inputs[sample]})
source_paths=['lib/testing/getDrcErrors.ts','lib/testing/drcPresets.ts','lib/testing/utils/convertToCircuitJson.ts','node_modules/@tscircuit/checks/dist/index.js']
compact_manifest={'schemaVersion':1,'kind':'repair04-passing-final-outputs','validationSuite':'repair04-via-pad-v1','scope':'Passing-output evidence subset only. This is not a denominator or a new benchmark. The full benchmark retains all 37 original pinned boards and all 15 current main members, including failures and timeouts.','benchmark':{'bundleSha256':source['bundleSha256'],'baselineFingerprintSha256':config['baselineFingerprintSha256'],'datasetCommit':source['datasetCommit'],'solverCommit':source['coreCommit'],'autorouterCommit':source['routerCommit'],'effort':1,'denominators':{'allDatasetBoards':37,'currentDatasetBoards':15},'originalRuntime':{'bunVersion':config['bunVersion'],'architecture':config['architecture'],'platform':config['platform']}},'verificationProvenance':{'checksVersion':'0.0.163','lockfile':'none; exact bundled dependency source and package manifests archived in full evidence','repositoryFiles':{p:source['bundleInputsSha256'][p] for p in source_paths},'conversionContextFields':['originalSrj','srjWithPointPairs'],'strictCheck':'getDrcErrors(circuitJson, {includeViaPadChecks:true})','relaxedCheck':'getDrcErrors(circuitJson, {...RELAXED_DRC_OPTIONS, includeViaPadChecks:true})'},'samples':samples}
compact_bytes=(json.dumps(compact_manifest,indent=2)+'\n').encode()
(artifact/'manifest.json').write_bytes(compact_bytes)
(outputs/'repair04-v12-passing-outputs-manifest.json').write_bytes(compact_bytes)
(artifact/'README.md').write_text(f'''# Corrected V12 saved passing outputs

These {len(samples)} final outputs are unchanged bytes with exact original conversion contexts. They are a passing-only evidence subset; the full benchmark keeps all 37/current15 members including failures and timeouts. Historical V8 counts omitted both via-to-pad checks and are withdrawn as clean-board claims.

From the autorouter checkout at `{source['routerCommit']}` with its recorded dependencies:

```sh
bun scripts/benchmark/verify-repair04-saved-outputs.ts /path/to/repair04-v12-passing-outputs
```

The verifier hashes every file, checks checker provenance, rebuilds circuit-json from the saved traces, and explicitly enables checkViasInPads plus checkViaPadClearance in both the default and relaxed checks. It performs no routing and exits nonzero on any discrepancy or DRC error.
''')
compact_archive=outputs/'repair04-v12-passing-outputs.tar.gz'
with tarfile.open(compact_archive,'w:gz') as archive:archive.add(artifact,arcname=artifact.name)
if '--compact-only' in sys.argv:
 print(json.dumps({'compactArchive':str(compact_archive),'compactArchiveSha256':sha(compact_archive.read_bytes()),'passingSamples':sorted(passes)}))
 sys.exit(0)
protocol=read('source-v12/protocol.json')
protocol['baselineIdentityObserved']={'evaluated':37,'byteExact':sum(r.get('baselineReplayByteExact') is True for r in merged['results']),'maximumNumericDifference':max(r.get('baselineReplayMaximumNumericDifference',0) for r in merged['results'])}
(root/'source-v12/protocol.json').write_text(json.dumps(protocol,indent=2)+'\n')
selected=['baseline-v12','source-v12','candidate-v12-complete','comparison-v12-current15.json','comparison-v12-legacy37.json','srj33-current-manifest.json','srj33-pinned-manifest.json','independent-v12-passing-outputs.json','v12-final-raw-linkage-verification.json','v12-compact-archive-verification.json','timer-path-v9-synthetic','package-v12-evidence.py','collect-v12-snapshots.py','passing-output-artifact-v12','verify-replay-raw-linkage.py','v12-through-obstacle-checkpoint-audit.json','audit-v12-through-obstacle-spans.py','v12-full-baseline-merge-verification.json','v12-full-baseline-merge-control-checks.json','merge-v12-full-baselines.py','collect-v12-full-baselines.py','prepare-v12-source.py','v12-preparation/test-full-baseline-merge.py','v12-preparation/stage-full-baseline.py','v12-preparation/stage-candidate.py']
selected.extend(f'candidate-v12-{c}' for c in 'abcdef')
selected.extend(f'baseline-v12-{c}' for c in 'abcdef')
files=[]
for name in selected:
 path=root/name;assert path.exists(),name
 files.extend(path.rglob('*') if path.is_dir() else [path])
files=sorted({p for p in files if p.is_file()});assert all(not p.is_symlink() for p in files)
records=[{'path':str(p.relative_to(root)),'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in files]
checksums=''.join(f"{r['sha256']}  {r['path']}\n" for r in records).encode()
archive_path=outputs/'repair04-v12-evidence.tar.gz'
prefix='repair04-v12-evidence'
with tarfile.open(archive_path,'w:gz') as archive:
 for p in files:archive.add(p,arcname=f'{prefix}/{p.relative_to(root)}',recursive=False)
 info=tarfile.TarInfo(f'{prefix}/SHA256SUMS');info.size=len(checksums);info.mode=0o644;archive.addfile(info,io.BytesIO(checksums))
with tarfile.open(archive_path) as archive:
 for row in records:assert sha(archive.extractfile(f"{prefix}/{row['path']}").read())==row['sha256']
manifest={'archive':str(archive_path),'archiveBytes':archive_path.stat().st_size,'archiveSha256':sha(archive_path.read_bytes()),'fileCount':len(records),'allArchivedFileHashesVerified':True,'compactArchive':str(compact_archive),'compactArchiveBytes':compact_archive.stat().st_size,'compactArchiveSha256':sha(compact_archive.read_bytes()),'compactManifestSha256':sha(compact_bytes),'files':records}
(root/'v12-evidence-archive-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in manifest.items() if k!='files'}))
