from pathlib import Path
import json
import tarfile

root = Path(__file__).parent
rows = []
for archive in sorted(root.glob("baseline-v12-?-snapshot.tar.gz")):
    cohort = archive.name.split("-")[2]
    output = root / f"baseline-v12-{cohort}"
    output.mkdir(exist_ok=True)
    prefix = f"repair04-baseline-v12-{cohort}/"
    with tarfile.open(archive) as contents:
        for member in contents.getmembers():
            if member.isfile() and member.name.startswith(prefix):
                relative = member.name[len(prefix):]
                assert ".." not in Path(relative).parts
                target = output / relative
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(contents.extractfile(member).read())
        log = f"repair04-baseline-v12-{cohort}.log"
        if log in contents.getnames():
            (output / "cohort.log").write_bytes(contents.extractfile(log).read())
    with tarfile.open(archive) as contents:
        for suffix, local in [("machine.txt", "machine.txt"), ("launch.log", "launch.log")]:
            name = f"repair04-baseline-v12-{cohort}.{suffix}" if suffix == "machine.txt" else f"repair04-v12-baseline-{cohort}-launch.log"
            if name in contents.getnames():
                (output / local).write_bytes(contents.extractfile(name).read())
    summary = output / "summary.json"
    if summary.exists():
        data = json.loads(summary.read_text())
        assert data["validationSuite"] == "repair04-via-pad-v1"
        for result in data["results"]:
            rows.append({
                "cohort": cohort,
                "sample": result["sample"],
                "solved": result["solved"],
                "timedOut": result["timedOut"],
                "relaxedErrorCount": len(result["relaxedErrors"]) if "relaxedErrors" in result else None,
                "strictErrorCount": len(result["strictErrors"]) if "strictErrors" in result else None,
                "byteExactBaseline": result.get("baselineReplayByteExact"),
                "maximumNumericDifference": result.get("baselineReplayMaximumNumericDifference"),
            })
assert len(rows) == len({row["sample"] for row in rows})
status = {"complete": len(rows) == 37, "evaluated": len(rows), "denominator": 37, "rows": rows}
(root / "v12-full-baseline-progress.json").write_text(json.dumps(status, indent=2) + "\n")
print(json.dumps(status))
