from pathlib import Path
import json,hashlib
root=Path(__file__).resolve().parent
rows=[]
for p in sorted((root/'baseline-v12').glob('*.post-repair03.json')):
 d=json.loads(p.read_text());marked=[];noncolocated=[];transitions=0
 for ri,r in enumerate(d['hdRoutes']):
  for pi,(a,b) in enumerate(zip(r['route'],r['route'][1:])):
   if a['z']!=b['z']:
    transitions+=1
    detail={'routeIndex':ri,'segmentIndex':pi,'connectionName':r['connectionName'],'a':a,'b':b,'markedThroughObstacle':a.get('toNextSegmentType')=='through_obstacle','colocated':a['x']==b['x'] and a['y']==b['y']}
    if detail['markedThroughObstacle']:marked.append(detail)
    if not detail['colocated']:noncolocated.append(detail)
 rows.append({'sample':p.name.split('.')[0],'checkpointSha256':hashlib.sha256(p.read_bytes()).hexdigest(),'routeCount':len(d['hdRoutes']),'zChangingSegmentCount':transitions,'markedZChangingSpanCount':len(marked),'noncolocatedZChangingSpanCount':len(noncolocated),'markedNoncolocatedZChangingSpanCount':sum(x['markedThroughObstacle'] for x in noncolocated),'markedZChangingSpans':marked,'noncolocatedZChangingSpans':noncolocated})
result={'kind':'Read-only audit of exact post-repair03 HD checkpoint inputs for marked noncolocated z-changing through_obstacle spans','sourceBaseline':'baseline-v12','sourceDatasetCommit':'f566b62be0f83395d9ab63ddc068f9d645b68b16','checkpointCount':len(rows),'allCheckpointsScanned':len(rows)==37,'totalMarkedZChangingSpans':sum(r['markedZChangingSpanCount'] for r in rows),'totalNoncolocatedZChangingSpans':sum(r['noncolocatedZChangingSpanCount'] for r in rows),'totalMarkedNoncolocatedZChangingSpans':sum(r['markedNoncolocatedZChangingSpanCount'] for r in rows),'affectedSamples':[r['sample'] for r in rows if r['markedNoncolocatedZChangingSpanCount']],'limits':'These are the exact entry inputs to the early repair04 stage. This audit alone does not establish absence in later joint/advanced-stage HD state, which the frozen full replay does not separately persist for every board. Saved final SRJ output uses a different trace representation.','results':rows}
(root/'v12-through-obstacle-checkpoint-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='results'}))
