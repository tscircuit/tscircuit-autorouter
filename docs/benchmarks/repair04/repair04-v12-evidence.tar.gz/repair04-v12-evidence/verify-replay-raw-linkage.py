from pathlib import Path
import json,hashlib,sys
root=Path(__file__).resolve().parent
version=sys.argv[1]
assert version in ['v10','v11','v12']
baseline_version='v12' if version=='v12' else 'v9'
merged=json.loads((root/f'candidate-{version}-complete/summary.json').read_text())
assert merged['complete'] and len(merged['results'])==37
sha=lambda b:hashlib.sha256(b).hexdigest()
rows=[]
for row in merged['results']:
 sample=row['sample']
 directories=[root/f'candidate-{version}-{c}' for c in 'abcdef' if (root/f'candidate-{version}-{c}/{sample}.result.json').exists()]
 assert len(directories)==1,sample
 directory=directories[0]
 assert json.loads((directory/f'{sample}.result.json').read_text())==row,sample
 baseline=(directory/f'{sample}.baseline.json').read_bytes()
 assert baseline==(root/f'baseline-{baseline_version}/{sample}.output.json').read_bytes(),sample
 result={'sample':sample,'rawRowEqualsMerged':True,'disabledOutputByteExact':True,'baselineOutputSha256':sha(baseline),'solved':row['solved'],'timedOut':row['timedOut']}
 if row['solved']:
  output_sha=sha((directory/f'{sample}.candidate.json').read_bytes())
  assert output_sha==row['outputSha256'],sample
  result.update(candidateSha256MatchesRow=True,candidateOutputSha256=output_sha)
 rows.append(result)
result={'version':version,'validationSuite':'repair04-via-pad-v1','evaluated':len(rows),'allRawRowsEqualMerged':True,'all37DisabledOutputsByteExact':True,'solvedOutputsVerified':sum(r['solved'] for r in rows),'results':rows}
(root/f'{version}-final-raw-linkage-verification.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k!='results'}))
