# Saved repair04 passing outputs

This archive contains the eight final passing output files as unchanged bytes, plus only the two original checkpoint fields used for independent DRC conversion. It is passing-only evidence, not a dataset result: the complete report keeps all 37 boards and the current 15-board subset in their denominators, including failures and timeouts.

From the accompanying autorouter PR checkout after installing its dependencies:

```sh
mkdir -p work/repair04-saved-output-check
tar -xzf repair04-passing-outputs.tar.gz -C work/repair04-saved-output-check
bun scripts/benchmark/verify-repair04-saved-outputs.ts work/repair04-saved-output-check/repair04-passing-outputs
```

The verifier checks all payload hashes and checker provenance, converts the saved trace geometry with the exact original SRJ contexts, and runs unchanged default and relaxed DRC checks. It never routes a board or reads recorded scores. A nonzero exit indicates a hash/provenance mismatch or a DRC failure. The runtime is reported for diagnostics; Linux/ARM is not required for verification.

The manifest binds every output/context to bundle 19371644175eadbd80bb21fd6b4cdfce0f06f12560d442790ff5b88417985f8d, dataset f566b62be0f83395d9ab63ddc068f9d645b68b16, its input and checkpoint hashes, and @tscircuit/checks 0.0.163. The dependency inventory for the routing experiment belongs to the full benchmark evidence archive.
