import type { HighDensityIntraNodeRoute, HighDensityRoutePoint } from "./types"

interface Point {
  x: number
  y: number
}

export interface SameLayerIntersection {
  trace1: string
  trace2: string
  z: number
  point: Point
  type: "crossing" | "shared_point"
  seg1?: [Point, Point]
  seg2?: [Point, Point]
}

interface SegmentOnLayer {
  minX: number
  maxX: number
  minY: number
  maxY: number
  z: number
  a: Point
  b: Point
}

export interface RouteGeometryViolation {
  trace1: string
  trace2: string
  type:
    | "crossing"
    | "shared_point"
    | "trace_clearance"
    | "via_trace_clearance"
    | "via_via_clearance"
  z: number | null
  distance: number
  requiredDistance: number
  point?: Point
  point2?: Point
  seg1?: [Point, Point]
  seg2?: [Point, Point]
}

const EPSILON = 1e-9
const POINT_TOLERANCE = 0.01
const CLEARANCE_TOLERANCE = 1e-6
const DEFAULT_DETAILS_LIMIT = 20

function cross(a: Point, b: Point, c: Point): number {
  return (b.x - a.x) * (c.y - a.y) - (b.y - a.y) * (c.x - a.x)
}

function segmentsIntersect(
  p1: Point,
  p2: Point,
  p3: Point,
  p4: Point,
): Point | null {
  const d1 = cross(p3, p4, p1)
  const d2 = cross(p3, p4, p2)
  const d3 = cross(p1, p2, p3)
  const d4 = cross(p1, p2, p4)

  if (
    ((d1 > EPSILON && d2 < -EPSILON) || (d1 < -EPSILON && d2 > EPSILON)) &&
    ((d3 > EPSILON && d4 < -EPSILON) || (d3 < -EPSILON && d4 > EPSILON))
  ) {
    const t = d1 / (d1 - d2)
    return {
      x: p1.x + t * (p2.x - p1.x),
      y: p1.y + t * (p2.y - p1.y),
    }
  }

  return null
}

function getSegmentsOnLayer(
  route: HighDensityIntraNodeRoute,
  z: number,
): Array<[Point, Point]> {
  const segments: Array<[Point, Point]> = []
  for (let i = 0; i < route.route.length - 1; i++) {
    const a = route.route[i]!
    const b = route.route[i + 1]!
    if (a.z !== z || b.z !== z) continue
    segments.push([
      { x: a.x, y: a.y },
      { x: b.x, y: b.y },
    ])
  }
  return segments
}

function getPointsOnLayer(
  route: HighDensityIntraNodeRoute,
  z: number,
): Point[] {
  return route.route
    .filter((pt) => pt.z === z)
    .map((pt) => ({ x: pt.x, y: pt.y }))
}

function getAllSegments(route: HighDensityIntraNodeRoute): SegmentOnLayer[] {
  const segments: SegmentOnLayer[] = []
  for (let i = 0; i < route.route.length - 1; i++) {
    const a = route.route[i]!
    const b = route.route[i + 1]!
    if (a.z !== b.z) continue
    segments.push({
      minX: Math.min(a.x, b.x),
      maxX: Math.max(a.x, b.x),
      minY: Math.min(a.y, b.y),
      maxY: Math.max(a.y, b.y),
      z: a.z,
      a: { x: a.x, y: a.y },
      b: { x: b.x, y: b.y },
    })
  }
  return segments
}

function dot(ax: number, ay: number, bx: number, by: number): number {
  return ax * bx + ay * by
}

function pointDistance(a: Point, b: Point): number {
  return Math.hypot(a.x - b.x, a.y - b.y)
}

function pointsShareLocation(
  a: Point,
  b: Point,
  tolerance = POINT_TOLERANCE,
): boolean {
  return Math.abs(a.x - b.x) < tolerance && Math.abs(a.y - b.y) < tolerance
}

function getEndpointPortPointIdsAt(
  route: HighDensityIntraNodeRoute,
  z: number,
  point: Point,
): Set<string> {
  const ids = new Set<string>()
  const endpoints: Array<HighDensityRoutePoint | undefined> = [
    route.route[0],
    route.route[route.route.length - 1],
  ]

  for (const endpoint of endpoints) {
    if (!endpoint) continue
    if (endpoint.z !== z) continue
    if (!endpoint.portPointId) continue
    if (!pointsShareLocation(endpoint, point)) continue
    ids.add(endpoint.portPointId)
  }

  return ids
}

function isAllowedSharedEndpointPoint(
  route1: HighDensityIntraNodeRoute,
  route2: HighDensityIntraNodeRoute,
  z: number,
  point: Point,
): boolean {
  const ids1 = getEndpointPortPointIdsAt(route1, z, point)
  if (ids1.size === 0) return false

  const ids2 = getEndpointPortPointIdsAt(route2, z, point)
  if (ids2.size === 0) return false

  for (const id of ids1) {
    if (ids2.has(id)) return true
  }

  return false
}

function segmentsMeetAtAllowedSharedEndpoint(
  route1: HighDensityIntraNodeRoute,
  seg1: SegmentOnLayer,
  route2: HighDensityIntraNodeRoute,
  seg2: SegmentOnLayer,
): boolean {
  const seg1Endpoints = [seg1.a, seg1.b]
  const seg2Endpoints = [seg2.a, seg2.b]

  for (const p1 of seg1Endpoints) {
    for (const p2 of seg2Endpoints) {
      if (!pointsShareLocation(p1, p2)) continue
      if (isAllowedSharedEndpointPoint(route1, route2, seg1.z, p1)) {
        return true
      }
    }
  }

  return false
}

function pointToSegmentDistance(p: Point, a: Point, b: Point): number {
  const abx = b.x - a.x
  const aby = b.y - a.y
  const abLenSq = abx * abx + aby * aby
  if (abLenSq <= EPSILON) return pointDistance(p, a)

  const apx = p.x - a.x
  const apy = p.y - a.y
  const t = Math.max(0, Math.min(1, dot(apx, apy, abx, aby) / abLenSq))
  const qx = a.x + abx * t
  const qy = a.y + aby * t
  return Math.hypot(p.x - qx, p.y - qy)
}

function segmentDistance(a1: Point, a2: Point, b1: Point, b2: Point): number {
  if (segmentsIntersect(a1, a2, b1, b2)) return 0
  return Math.min(
    pointToSegmentDistance(a1, b1, b2),
    pointToSegmentDistance(a2, b1, b2),
    pointToSegmentDistance(b1, a1, a2),
    pointToSegmentDistance(b2, a1, a2),
  )
}

function toRootNetName(route: HighDensityIntraNodeRoute): string {
  return (
    route.rootConnectionName ?? route.connectionName.replace(/_mst\d+$/, "")
  )
}

function pushViolation(
  out: RouteGeometryViolation[],
  violation: RouteGeometryViolation,
) {
  out.push(violation)
}

export function findSameLayerIntersections(
  routes: HighDensityIntraNodeRoute[],
): SameLayerIntersection[] {
  const intersections: SameLayerIntersection[] = []

  const zLayers = new Set<number>()
  for (const route of routes) {
    for (const pt of route.route) {
      zLayers.add(pt.z)
    }
  }

  for (const z of zLayers) {
    const layerInfo = routes.map((route) => ({
      points: getPointsOnLayer(route, z),
      segments: getSegmentsOnLayer(route, z),
      root: toRootNetName(route),
    }))
    for (let i = 0; i < routes.length; i++) {
      const route1 = routes[i]!
      const { points: pts1, segments: segs1, root: rootNet1 } = layerInfo[i]!

      for (let j = i + 1; j < routes.length; j++) {
        const route2 = routes[j]!
        const { points: pts2, segments: segs2, root: rootNet2 } = layerInfo[j]!
        if (rootNet1 === rootNet2) continue

        const seen = new Set<string>()
        for (const p1 of pts1) {
          for (const p2 of pts2) {
            if (pointsShareLocation(p1, p2)) {
              if (isAllowedSharedEndpointPoint(route1, route2, z, p1)) {
                continue
              }
              const key = `${p1.x.toFixed(2)},${p1.y.toFixed(2)}`
              if (seen.has(key)) continue
              seen.add(key)
              intersections.push({
                trace1: route1.connectionName,
                trace2: route2.connectionName,
                z,
                point: p1,
                type: "shared_point",
              })
            }
          }
        }

        for (const [a1, a2] of segs1) {
          for (const [b1, b2] of segs2) {
            const pt = segmentsIntersect(a1, a2, b1, b2)
            if (!pt) continue
            intersections.push({
              trace1: route1.connectionName,
              trace2: route2.connectionName,
              z,
              point: pt,
              type: "crossing",
              seg1: [a1, a2],
              seg2: [b1, b2],
            })
          }
        }
      }
    }
  }

  return intersections
}

export function formatSameLayerIntersections(
  intersections: SameLayerIntersection[],
  limit = DEFAULT_DETAILS_LIMIT,
): string {
  return intersections
    .slice(0, limit)
    .map(
      (ix) =>
        `  ${ix.trace1} x ${ix.trace2} on z=${ix.z} [${ix.type}] at (${ix.point.x.toFixed(3)}, ${ix.point.y.toFixed(3)})`,
    )
    .join("\n")
}

export function getSameLayerIntersectionError(
  routes: HighDensityIntraNodeRoute[],
): string | null {
  const intersections = findSameLayerIntersections(routes)
  if (intersections.length === 0) return null
  return `Found ${intersections.length} same-layer intersection(s):\n${formatSameLayerIntersections(intersections)}`
}

export function findRouteGeometryViolations(
  routes: HighDensityIntraNodeRoute[],
): RouteGeometryViolation[] {
  const violations: RouteGeometryViolation[] = findSameLayerIntersections(
    routes,
  ).map((ix) => ({
    trace1: ix.trace1,
    trace2: ix.trace2,
    type: ix.type,
    z: ix.z,
    point: ix.point,
    seg1: ix.seg1,
    seg2: ix.seg2,
    distance: 0,
    requiredDistance: 0,
  }))

  const routeInfo = routes.map((route) => {
    const segments = getAllSegments(route)
    const zLayers = new Set<number>()
    const pointsByLayer = new Map<number, Point[]>()
    const segmentsByLayer = new Map<number, SegmentOnLayer[]>()

    for (const pt of route.route) {
      zLayers.add(pt.z)
      const points = pointsByLayer.get(pt.z) ?? []
      points.push({ x: pt.x, y: pt.y })
      pointsByLayer.set(pt.z, points)
    }

    for (const segment of segments) {
      const layerSegments = segmentsByLayer.get(segment.z) ?? []
      layerSegments.push(segment)
      segmentsByLayer.set(segment.z, layerSegments)
    }

    return {
      route,
      rootNet: toRootNetName(route),
      pointsByLayer,
      segmentsByLayer,
      segments,
      vias: route.vias.map((via) => ({ x: via.x, y: via.y })),
      traceRadius: route.traceThickness / 2,
      viaRadius: route.viaDiameter / 2,
      zLayers,
    }
  })

  for (let i = 0; i < routeInfo.length; i++) {
    const route1 = routeInfo[i]!
    for (let j = i + 1; j < routeInfo.length; j++) {
      const route2 = routeInfo[j]!
      if (route1.rootNet === route2.rootNet) continue

      const sharedLayers = new Set<number>([
        ...route1.zLayers.values(),
        ...route2.zLayers.values(),
      ])
      for (const z of sharedLayers) {
        const segs1 = route1.segmentsByLayer.get(z) ?? []
        const segs2 = route2.segmentsByLayer.get(z) ?? []
        const points1 = route1.pointsByLayer.get(z) ?? []
        const points2 = route2.pointsByLayer.get(z) ?? []
        const traceClearance = route1.traceRadius + route2.traceRadius

        for (const seg1 of segs1) {
          for (const seg2 of segs2) {
            // A separating axis proves these segments cannot violate clearance.
            // Keep the exact distance calculation (and its tolerances) for candidates.
            if (
              seg1.minX - seg2.maxX >= traceClearance ||
              seg2.minX - seg1.maxX >= traceClearance ||
              seg1.minY - seg2.maxY >= traceClearance ||
              seg2.minY - seg1.maxY >= traceClearance
            )
              continue
            const distance = segmentDistance(seg1.a, seg1.b, seg2.a, seg2.b)
            if (distance + CLEARANCE_TOLERANCE >= traceClearance) continue
            if (
              distance <= POINT_TOLERANCE &&
              segmentsMeetAtAllowedSharedEndpoint(
                route1.route,
                seg1,
                route2.route,
                seg2,
              )
            ) {
              continue
            }
            pushViolation(violations, {
              trace1: route1.route.connectionName,
              trace2: route2.route.connectionName,
              type:
                distance <= POINT_TOLERANCE
                  ? "shared_point"
                  : "trace_clearance",
              z,
              distance,
              requiredDistance: traceClearance,
              seg1: [seg1.a, seg1.b],
              seg2: [seg2.a, seg2.b],
            })
          }
        }

        for (const p1 of points1) {
          for (const p2 of points2) {
            if (
              Math.abs(p1.x - p2.x) >= traceClearance ||
              Math.abs(p1.y - p2.y) >= traceClearance
            )
              continue
            const distance = pointDistance(p1, p2)
            if (distance + CLEARANCE_TOLERANCE >= traceClearance) continue
            if (
              distance <= POINT_TOLERANCE &&
              isAllowedSharedEndpointPoint(route1.route, route2.route, z, p1)
            ) {
              continue
            }
            pushViolation(violations, {
              trace1: route1.route.connectionName,
              trace2: route2.route.connectionName,
              type:
                distance <= POINT_TOLERANCE
                  ? "shared_point"
                  : "trace_clearance",
              z,
              distance,
              requiredDistance: traceClearance,
              point: p1,
              point2: p2,
            })
          }
        }
      }

      const viaToViaClearance = route1.viaRadius + route2.viaRadius
      for (const via1 of route1.vias) {
        for (const via2 of route2.vias) {
          if (
            Math.abs(via1.x - via2.x) >= viaToViaClearance ||
            Math.abs(via1.y - via2.y) >= viaToViaClearance
          )
            continue
          const distance = pointDistance(via1, via2)
          if (distance + CLEARANCE_TOLERANCE >= viaToViaClearance) continue
          pushViolation(violations, {
            trace1: route1.route.connectionName,
            trace2: route2.route.connectionName,
            type: "via_via_clearance",
            z: null,
            distance,
            requiredDistance: viaToViaClearance,
            point: via1,
            point2: via2,
          })
        }
      }

      for (const via1 of route1.vias) {
        const requiredDistance = route1.viaRadius + route2.traceRadius
        for (const seg2 of route2.segments) {
          if (
            via1.x - seg2.maxX >= requiredDistance ||
            seg2.minX - via1.x >= requiredDistance ||
            via1.y - seg2.maxY >= requiredDistance ||
            seg2.minY - via1.y >= requiredDistance
          )
            continue
          const distance = pointToSegmentDistance(via1, seg2.a, seg2.b)
          if (distance + CLEARANCE_TOLERANCE >= requiredDistance) continue
          pushViolation(violations, {
            trace1: route1.route.connectionName,
            trace2: route2.route.connectionName,
            type: "via_trace_clearance",
            z: seg2.z,
            distance,
            requiredDistance,
            point: via1,
            seg2: [seg2.a, seg2.b],
          })
        }
      }

      for (const via2 of route2.vias) {
        const requiredDistance = route2.viaRadius + route1.traceRadius
        for (const seg1 of route1.segments) {
          if (
            via2.x - seg1.maxX >= requiredDistance ||
            seg1.minX - via2.x >= requiredDistance ||
            via2.y - seg1.maxY >= requiredDistance ||
            seg1.minY - via2.y >= requiredDistance
          )
            continue
          const distance = pointToSegmentDistance(via2, seg1.a, seg1.b)
          if (distance + CLEARANCE_TOLERANCE >= requiredDistance) continue
          pushViolation(violations, {
            trace1: route1.route.connectionName,
            trace2: route2.route.connectionName,
            type: "via_trace_clearance",
            z: seg1.z,
            distance,
            requiredDistance,
            point: via2,
            seg1: [seg1.a, seg1.b],
          })
        }
      }
    }
  }

  return violations
}

export function formatRouteGeometryViolations(
  violations: RouteGeometryViolation[],
  limit = DEFAULT_DETAILS_LIMIT,
): string {
  return violations
    .slice(0, limit)
    .map((violation) => {
      const zPart = violation.z === null ? "z=all" : `z=${violation.z}`
      return `  ${violation.trace1} x ${violation.trace2} [${violation.type}] ${zPart} dist=${violation.distance.toFixed(3)} req=${violation.requiredDistance.toFixed(3)}`
    })
    .join("\n")
}

export function getRouteGeometryViolationError(
  routes: HighDensityIntraNodeRoute[],
): string | null {
  const violations = findRouteGeometryViolations(routes)
  if (violations.length === 0) return null
  return `Found ${violations.length} route geometry violation(s):\n${formatRouteGeometryViolations(violations)}`
}

export function validateRouteGeometry(
  routes: HighDensityIntraNodeRoute[],
): void {
  const error = getRouteGeometryViolationError(routes)
  if (error) throw new Error(error)
}

export function validateNoIntersections(
  routes: HighDensityIntraNodeRoute[],
): void {
  const error = getSameLayerIntersectionError(routes)
  if (error) throw new Error(error)
}
