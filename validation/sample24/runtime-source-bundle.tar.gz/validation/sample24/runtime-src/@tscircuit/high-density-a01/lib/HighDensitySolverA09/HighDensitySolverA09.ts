import { BaseSolver } from "@tscircuit/solver-utils"
import type { GraphicsObject } from "graphics-debug"
import {
  HighDensitySolverA03,
  type HighDensitySolverA03Props,
} from "../HighDensitySolverA03/HighDensitySolverA03"
import {
  findRouteGeometryViolations,
  findSameLayerIntersections,
} from "../routeGeometryValidation"
import type {
  HighDensityIntraNodeRoute,
  NodeWithPortPoints,
  PortPoint,
} from "../types"

type Side = "left" | "right" | "top" | "bottom"

type ConnectionInfo = {
  connectionName: string
  rootConnectionName?: string
  portPoints: PortPoint[]
  sides: Set<Side>
}

type CandidateSolution = {
  order: string[]
  routes: HighDensityIntraNodeRoute[]
  complete: boolean
  intersections: number
  violations: number
}

type PointToCellResult = {
  z: number
  cellId: number
}

type A03Internals = {
  availableZ: number[]
  layers: number
  planeSize: number
  pointToCell: (pt: { x: number; y: number; z: number }) => PointToCellResult
  portOwnerFlat: Int32Array
  usedCellsFlat: Int32Array
}

export interface HighDensitySolverA09Props
  extends Pick<
    HighDensitySolverA03Props,
    | "nodeWithPortPoints"
    | "highResolutionCellSize"
    | "highResolutionCellThickness"
    | "lowResolutionCellSize"
    | "viaDiameter"
    | "maxCellCount"
    | "traceThickness"
    | "traceMargin"
    | "viaMinDistFromBorder"
    | "showPenaltyMap"
    | "showUsedCellMap"
    | "effort"
    | "hyperParameters"
  > {
  boundaryBonus?: number
  boundaryBonusSigma?: number
  portShadowStrength?: number
  portShadowTangentSigma?: number
  portShadowDepthSigma?: number
  fullOrderSearchConnectionCountLimit?: number
  priorityHeadSize?: number
  maxCandidateOrders?: number
}

const TRACE_COLORS = [
  "rgba(255,0,0,0.8)",
  "rgba(0,0,255,0.8)",
  "rgba(255,165,0,0.8)",
  "rgba(0,128,0,0.8)",
] as const

const PORT_COLORS = ["red", "blue", "orange", "green"] as const
const FIXED_OBSTACLE_CONN_ID = 9_999

function* permutations<T>(
  items: T[],
  prefix: T[] = [],
): Generator<T[], void, void> {
  if (items.length === 0) {
    yield prefix
    return
  }

  for (let index = 0; index < items.length; index += 1) {
    const current = items[index]
    if (!current) continue
    const remaining = items.slice(0, index).concat(items.slice(index + 1))
    yield* permutations(remaining, [...prefix, current])
  }
}

function scoreConnection(
  connection: ConnectionInfo,
  centerY: number,
  rootSiblingCount: number,
) {
  const xs = connection.portPoints.map((portPoint) => portPoint.x)
  const ys = connection.portPoints.map((portPoint) => portPoint.y)
  const widthSpan = Math.max(...xs) - Math.min(...xs)
  const heightSpan = Math.max(...ys) - Math.min(...ys)
  const minY = Math.min(...ys)

  let score = widthSpan + heightSpan * 0.75
  if (connection.sides.has("left") && connection.sides.has("right")) score += 4
  if (connection.sides.has("top") && connection.sides.has("bottom")) score += 4
  if (minY < centerY) score += 1.5
  score += Math.max(0, rootSiblingCount - 1) * 0.25
  return score
}

export class HighDensitySolverA09 extends BaseSolver {
  override getSolverName(): string {
    return "HighDensitySolverA09"
  }

  nodeWithPortPoints: NodeWithPortPoints
  highResolutionCellSize: number
  highResolutionCellThickness: number
  lowResolutionCellSize: number
  viaDiameter: number
  maxCellCount?: number
  traceThickness: number
  traceMargin: number
  viaMinDistFromBorder: number
  showPenaltyMap: boolean
  showUsedCellMap: boolean
  effort: number
  hyperParameters?: HighDensitySolverA03Props["hyperParameters"]
  boundaryBonus: number
  boundaryBonusSigma: number
  portShadowStrength: number
  portShadowTangentSigma: number
  portShadowDepthSigma: number
  fullOrderSearchConnectionCountLimit: number
  priorityHeadSize: number
  maxCandidateOrders: number

  private boundsMinX = 0
  private boundsMaxX = 0
  private boundsMinY = 0
  private boundsMaxY = 0
  private sidePortPoints: Array<PortPoint & { side: Side }> = []
  private connections: ConnectionInfo[] = []
  private candidateOrders: ConnectionInfo[][] = []
  private outputRoutes: HighDensityIntraNodeRoute[] = []
  private bestCandidate: CandidateSolution | null = null
  private searchComplete = false
  private candidateOrderIndex = 0
  private candidateOrdersTried = 0
  private activeOrder: ConnectionInfo[] | null = null
  private activeOrderRoutes: HighDensityIntraNodeRoute[] = []
  private activeOrderConnectionIndex = 0
  private activeOrderFailed = false
  private activeConnection: ConnectionInfo | null = null
  private activeConnectionSolver: HighDensitySolverA03 | null = null

  constructor(props: HighDensitySolverA09Props) {
    super()
    this.nodeWithPortPoints = props.nodeWithPortPoints
    this.highResolutionCellSize = props.highResolutionCellSize ?? 0.1
    this.highResolutionCellThickness = props.highResolutionCellThickness ?? 8
    this.lowResolutionCellSize = props.lowResolutionCellSize ?? 0.4
    this.viaDiameter = props.viaDiameter ?? 0.3
    this.maxCellCount = props.maxCellCount
    this.traceThickness = props.traceThickness ?? 0.1
    this.traceMargin = props.traceMargin ?? 0.15
    this.viaMinDistFromBorder = props.viaMinDistFromBorder ?? 0.15
    this.showPenaltyMap = props.showPenaltyMap ?? false
    this.showUsedCellMap = props.showUsedCellMap ?? false
    this.effort = props.effort ?? 1
    this.hyperParameters = props.hyperParameters
    this.boundaryBonus = props.boundaryBonus ?? 0.18
    this.boundaryBonusSigma = props.boundaryBonusSigma ?? 0.22
    this.portShadowStrength = props.portShadowStrength ?? 0.55
    this.portShadowTangentSigma = props.portShadowTangentSigma ?? 0.18
    this.portShadowDepthSigma = props.portShadowDepthSigma ?? 0.5
    this.fullOrderSearchConnectionCountLimit =
      props.fullOrderSearchConnectionCountLimit ?? 6
    this.priorityHeadSize = props.priorityHeadSize ?? 4
    this.maxCandidateOrders = props.maxCandidateOrders ?? 720
    this.MAX_ITERATIONS = 100_000_000
  }

  override getConstructorParams(): [HighDensitySolverA09Props] {
    return [
      {
        nodeWithPortPoints: this.nodeWithPortPoints,
        highResolutionCellSize: this.highResolutionCellSize,
        highResolutionCellThickness: this.highResolutionCellThickness,
        lowResolutionCellSize: this.lowResolutionCellSize,
        viaDiameter: this.viaDiameter,
        maxCellCount: this.maxCellCount,
        traceThickness: this.traceThickness,
        traceMargin: this.traceMargin,
        viaMinDistFromBorder: this.viaMinDistFromBorder,
        showPenaltyMap: this.showPenaltyMap,
        showUsedCellMap: this.showUsedCellMap,
        effort: this.effort,
        hyperParameters: this.hyperParameters,
        boundaryBonus: this.boundaryBonus,
        boundaryBonusSigma: this.boundaryBonusSigma,
        portShadowStrength: this.portShadowStrength,
        portShadowTangentSigma: this.portShadowTangentSigma,
        portShadowDepthSigma: this.portShadowDepthSigma,
        fullOrderSearchConnectionCountLimit:
          this.fullOrderSearchConnectionCountLimit,
        priorityHeadSize: this.priorityHeadSize,
        maxCandidateOrders: this.maxCandidateOrders,
      },
    ]
  }

  override _setup(): void {
    const { center, width, height, portPoints } = this.nodeWithPortPoints
    this.boundsMinX = center.x - width / 2
    this.boundsMaxX = center.x + width / 2
    this.boundsMinY = center.y - height / 2
    this.boundsMaxY = center.y + height / 2

    this.sidePortPoints = portPoints.map((portPoint) => ({
      ...portPoint,
      side: this.getSide(portPoint),
    }))
    this.connections = this.getConnections()
    this.candidateOrders = this.generateCandidateOrders()
    this.outputRoutes = []
    this.bestCandidate = null
    this.searchComplete = false
    this.candidateOrderIndex = 0
    this.candidateOrdersTried = 0
    this.activeOrder = null
    this.activeOrderRoutes = []
    this.activeOrderConnectionIndex = 0
    this.activeOrderFailed = false
    this.activeConnection = null
    this.activeConnectionSolver = null
    this.activeSubSolver = null

    if (this.connections.length === 0) {
      this.solved = true
    }
  }

  override _step(): void {
    if (this.searchComplete || this.solved || this.failed) return

    if (this.activeConnectionSolver) {
      this.stepActiveConnectionSolver()
      return
    }

    if (!this.activeOrder) {
      this.startNextCandidateOrder()
      return
    }

    if (this.activeOrderConnectionIndex < this.activeOrder.length) {
      this.startNextActiveOrderConnection()
      return
    }

    this.finishActiveCandidateOrder()
  }

  override getOutput(): HighDensityIntraNodeRoute[] {
    return this.outputRoutes
  }

  override visualize(): GraphicsObject {
    const activeSubVisualization = this.activeConnectionSolver?.visualize()
    const rects: NonNullable<GraphicsObject["rects"]> = [
      {
        center: this.nodeWithPortPoints.center,
        width: this.nodeWithPortPoints.width,
        height: this.nodeWithPortPoints.height,
        stroke: "gray",
      },
    ]
    const points: NonNullable<GraphicsObject["points"]> =
      this.nodeWithPortPoints.portPoints.map((portPoint) => ({
        x: portPoint.x,
        y: portPoint.y,
        color: PORT_COLORS[portPoint.z] ?? "black",
        label: portPoint.connectionName,
      }))
    const lines: NonNullable<GraphicsObject["lines"]> = []
    const circles: NonNullable<GraphicsObject["circles"]> = []
    const texts: NonNullable<GraphicsObject["texts"]> = []

    if (this.activeOrder) {
      this.appendRoutesToGraphics(
        this.bestCandidate?.routes ?? [],
        lines,
        circles,
        {
          alpha: 0.24,
          strokeDash: "0.08 0.08",
        },
      )
      this.appendRoutesToGraphics(this.activeOrderRoutes, lines, circles, {
        alpha: 0.8,
      })
    } else {
      this.appendRoutesToGraphics(this.outputRoutes, lines, circles, {
        alpha: 0.8,
      })
    }

    if (activeSubVisualization) {
      points.push(...(activeSubVisualization.points ?? []))
      lines.push(...(activeSubVisualization.lines ?? []))
      circles.push(...(activeSubVisualization.circles ?? []))
      rects.push(...(activeSubVisualization.rects ?? []).slice(1))
    }

    texts.push({
      x: this.boundsMinX,
      y: this.boundsMaxY,
      text: this.getVisualizationStatusText(),
      anchorSide: "bottom_left",
      fontSize: 0.14,
      color: "black",
    })

    return {
      points,
      lines,
      circles,
      rects,
      texts,
      coordinateSystem: "cartesian" as const,
      title: `HighDensityA09 ${this.getVisualizationStatusText()}`,
    }
  }

  override preview(): GraphicsObject {
    return this.visualize()
  }

  private appendRoutesToGraphics(
    routes: HighDensityIntraNodeRoute[],
    lines: NonNullable<GraphicsObject["lines"]>,
    circles: NonNullable<GraphicsObject["circles"]>,
    options: { alpha: number; strokeDash?: string | number[] },
  ) {
    for (const route of routes) {
      let segmentStart = 0
      for (let index = 1; index < route.route.length; index += 1) {
        const previous = route.route[index - 1]
        const current = route.route[index]
        if (!previous || !current) continue

        if (current.z !== previous.z) {
          if (index - segmentStart >= 2) {
            const segmentZ = route.route[segmentStart]?.z ?? previous.z
            lines.push({
              points: route.route
                .slice(segmentStart, index)
                .map((point) => ({ x: point.x, y: point.y })),
              strokeColor: this.getTraceColor(segmentZ, options.alpha),
              strokeWidth: route.traceThickness,
              strokeDash: options.strokeDash,
            })
          }
          segmentStart = index
        }
      }

      if (route.route.length - segmentStart >= 2) {
        const segmentZ = route.route[segmentStart]?.z ?? 0
        lines.push({
          points: route.route
            .slice(segmentStart)
            .map((point) => ({ x: point.x, y: point.y })),
          strokeColor: this.getTraceColor(segmentZ, options.alpha),
          strokeWidth: route.traceThickness,
          strokeDash: options.strokeDash,
        })
      }

      for (const via of route.vias) {
        circles.push({
          center: { x: via.x, y: via.y },
          radius: route.viaDiameter / 2,
          fill: `rgba(0,0,0,${Math.min(0.3, options.alpha).toFixed(3)})`,
          stroke: "black",
        })
      }
    }
  }

  private getTraceColor(z: number, alpha: number) {
    const color = TRACE_COLORS[z % TRACE_COLORS.length]
    if (!color) return `rgba(0,0,0,${alpha.toFixed(3)})`
    return color.replace(/[\d.]+\)$/, `${alpha.toFixed(3)})`)
  }

  private getVisualizationStatusText() {
    const orderNumber =
      this.activeOrder || this.candidateOrderIndex > 0
        ? Math.max(1, this.candidateOrderIndex)
        : 0
    const connectionName =
      this.activeConnection?.connectionName ??
      this.activeOrder?.[this.activeOrderConnectionIndex]?.connectionName ??
      "none"
    const activeSolvedCount = this.activeOrderRoutes.length
    const bestSolvedCount = this.bestCandidate?.routes.length ?? 0

    if (this.solved) {
      return `[solved, best ${bestSolvedCount}/${this.connections.length}]`
    }
    if (this.failed) {
      return `[failed, best ${bestSolvedCount}/${this.connections.length}]`
    }
    if (this.activeOrder) {
      return (
        `[order ${orderNumber}/${this.candidateOrders.length}, ` +
        `connection ${this.activeOrderConnectionIndex + 1}/${this.activeOrder.length}: ` +
        `${connectionName}, active ${activeSolvedCount}/${this.activeOrder.length}, ` +
        `best ${bestSolvedCount}/${this.connections.length}]`
      )
    }
    return `[orders tried ${this.candidateOrdersTried}/${this.candidateOrders.length}, best ${bestSolvedCount}/${this.connections.length}]`
  }

  private startNextCandidateOrder() {
    const order = this.candidateOrders[this.candidateOrderIndex]
    if (!order) {
      this.finishSearch()
      return
    }

    this.candidateOrderIndex += 1
    this.activeOrder = order
    this.activeOrderRoutes = []
    this.activeOrderConnectionIndex = 0
    this.activeOrderFailed = false
  }

  private startNextActiveOrderConnection() {
    const connection = this.activeOrder?.[this.activeOrderConnectionIndex]
    if (!connection) {
      return
    }

    const solver = this.createConnectionSolver(connection)
    solver.setup()
    this.applyExactRouteObstacles(solver, this.activeOrderRoutes)
    this.activeConnection = connection
    this.activeConnectionSolver = solver
    this.activeSubSolver = solver
  }

  private stepActiveConnectionSolver() {
    if (!this.activeConnectionSolver) return

    this.activeConnectionSolver.step()

    if (this.activeConnectionSolver.solved) {
      this.finishSolvedActiveConnection()
      return
    }

    if (this.activeConnectionSolver.failed) {
      this.activeOrderFailed = true
      this.activeOrderConnectionIndex = this.activeOrder?.length ?? 0
      this.activeConnection = null
      this.activeConnectionSolver = null
      this.activeSubSolver = null
    }
  }

  private finishSolvedActiveConnection() {
    const connection = this.activeConnection
    const solver = this.activeConnectionSolver
    if (!connection || !solver) return

    const routes = solver.getOutput()
    if (routes.length === 0) {
      this.activeOrderFailed = true
      this.activeOrderConnectionIndex = this.activeOrder?.length ?? 0
    } else {
      this.activeOrderRoutes.push(
        ...routes.map((route) => ({
          ...route,
          rootConnectionName: connection.rootConnectionName,
          regionId:
            route.regionId ?? this.nodeWithPortPoints.capacityMeshNodeId,
        })),
      )
      this.activeOrderConnectionIndex += 1
    }

    this.activeConnection = null
    this.activeConnectionSolver = null
    this.activeSubSolver = null
  }

  private finishActiveCandidateOrder() {
    if (!this.activeOrder) return

    const routes = this.activeOrderRoutes
    const candidate: CandidateSolution = {
      order: this.activeOrder.map((connection) => connection.connectionName),
      routes,
      complete: !this.activeOrderFailed,
      intersections: findSameLayerIntersections(routes).length,
      violations: findRouteGeometryViolations(routes).length,
    }

    if (this.isBetterCandidate(candidate, this.bestCandidate)) {
      this.bestCandidate = candidate
      this.outputRoutes = candidate.routes
    }

    this.candidateOrdersTried += 1
    this.activeOrder = null
    this.activeOrderRoutes = []
    this.activeOrderConnectionIndex = 0
    this.activeOrderFailed = false
    this.refreshStats()

    if (this.isValidCandidate(candidate)) {
      this.searchComplete = true
      this.solved = true
    }
  }

  private finishSearch() {
    this.searchComplete = true
    this.refreshStats()

    if (!this.bestCandidate) {
      this.error = "A09 could not route any sample order"
      this.failed = true
      return
    }

    const status = this.bestCandidate.complete ? "complete" : "partial"
    this.error =
      `A09 best ${status} candidate still invalid: ` +
      `${this.bestCandidate.routes.length} routed, ` +
      `${this.bestCandidate.intersections} intersections, ` +
      `${this.bestCandidate.violations} geometry violations`
    this.failed = true
  }

  private refreshStats() {
    this.stats = {
      candidateOrdersTried: this.candidateOrdersTried,
      bestOrder: this.bestCandidate?.order ?? [],
      bestRouteCount: this.bestCandidate?.routes.length ?? 0,
      bestViolations: this.bestCandidate?.violations ?? 0,
      bestIntersections: this.bestCandidate?.intersections ?? 0,
    }
  }

  private isValidCandidate(candidate: CandidateSolution) {
    return (
      candidate.complete &&
      candidate.intersections === 0 &&
      candidate.violations === 0
    )
  }

  private createConnectionSolver(connection: ConnectionInfo) {
    const solver = new HighDensitySolverA03({
      nodeWithPortPoints: this.makeSubproblem(connection),
      highResolutionCellSize: this.highResolutionCellSize,
      highResolutionCellThickness: this.highResolutionCellThickness,
      lowResolutionCellSize: this.lowResolutionCellSize,
      viaDiameter: this.viaDiameter,
      maxCellCount: this.maxCellCount,
      traceThickness: this.traceThickness,
      traceMargin: this.traceMargin,
      viaMinDistFromBorder: this.viaMinDistFromBorder,
      showPenaltyMap: this.showPenaltyMap,
      showUsedCellMap: this.showUsedCellMap,
      effort: this.effort,
      hyperParameters: this.hyperParameters,
      initialPenaltyFn: ({ x, y }) => this.computeInitialPenalty(x, y),
    })
    solver.MAX_RIPS = 0
    solver.MAX_ITERATIONS = Math.max(1, this.MAX_ITERATIONS)
    return solver
  }

  private applyExactRouteObstacles(
    solver: HighDensitySolverA03,
    occupiedRoutes: HighDensityIntraNodeRoute[],
  ) {
    const internals = solver as unknown as A03Internals
    const blockedFlatIndices = new Set<number>()
    const fallbackZ = internals.availableZ[0] ?? 0

    for (const route of occupiedRoutes) {
      for (const point of route.route) {
        const cell = internals.pointToCell(point)
        blockedFlatIndices.add(point.z * internals.planeSize + cell.cellId)
      }

      for (const via of route.vias) {
        const cell = internals.pointToCell({
          x: via.x,
          y: via.y,
          z: fallbackZ,
        })
        for (
          let layerIndex = 0;
          layerIndex < internals.layers;
          layerIndex += 1
        ) {
          blockedFlatIndices.add(layerIndex * internals.planeSize + cell.cellId)
        }
      }
    }

    for (const flatIndex of blockedFlatIndices) {
      internals.portOwnerFlat[flatIndex] = FIXED_OBSTACLE_CONN_ID
      internals.usedCellsFlat[flatIndex] = FIXED_OBSTACLE_CONN_ID
    }
  }

  private computeInitialPenalty(x: number, y: number) {
    let penalty = 0
    const tangentSigmaSq =
      2 * this.portShadowTangentSigma * this.portShadowTangentSigma
    const depthSigmaSq =
      2 * this.portShadowDepthSigma * this.portShadowDepthSigma
    const boundarySigmaSq =
      2 * this.boundaryBonusSigma * this.boundaryBonusSigma

    for (const portPoint of this.sidePortPoints) {
      const tangential =
        portPoint.side === "top" || portPoint.side === "bottom"
          ? Math.abs(x - portPoint.x)
          : Math.abs(y - portPoint.y)
      const inward =
        portPoint.side === "top"
          ? portPoint.y - y
          : portPoint.side === "bottom"
            ? y - portPoint.y
            : portPoint.side === "left"
              ? x - portPoint.x
              : portPoint.x - x

      if (inward <= 0) continue
      penalty +=
        this.portShadowStrength *
        Math.exp(-(tangential * tangential) / tangentSigmaSq) *
        Math.exp(-(inward * inward) / depthSigmaSq)
    }

    for (const depth of [
      this.boundsMaxY - y,
      y - this.boundsMinY,
      x - this.boundsMinX,
      this.boundsMaxX - x,
    ]) {
      if (depth < 0) continue
      penalty -=
        this.boundaryBonus * Math.exp(-(depth * depth) / boundarySigmaSq)
    }

    return penalty
  }

  private generateCandidateOrders() {
    if (this.connections.length <= 1) return [this.connections]

    if (
      this.connections.length <= this.fullOrderSearchConnectionCountLimit &&
      this.factorial(this.connections.length) <= this.maxCandidateOrders
    ) {
      return Array.from(permutations(this.connections))
    }

    const rootSiblingCounts = new Map<string, number>()
    for (const connection of this.connections) {
      const rootName =
        connection.rootConnectionName ??
        connection.connectionName.replace(/_mst\d+$/, "")
      rootSiblingCounts.set(
        rootName,
        (rootSiblingCounts.get(rootName) ?? 0) + 1,
      )
    }

    const sorted = [...this.connections].sort((left, right) => {
      const leftRoot =
        left.rootConnectionName ?? left.connectionName.replace(/_mst\d+$/, "")
      const rightRoot =
        right.rootConnectionName ?? right.connectionName.replace(/_mst\d+$/, "")
      const leftScore = scoreConnection(
        left,
        this.nodeWithPortPoints.center.y,
        rootSiblingCounts.get(leftRoot) ?? 1,
      )
      const rightScore = scoreConnection(
        right,
        this.nodeWithPortPoints.center.y,
        rootSiblingCounts.get(rightRoot) ?? 1,
      )
      return rightScore - leftScore
    })

    const headSize = Math.min(Math.max(1, this.priorityHeadSize), sorted.length)
    const head = sorted.slice(0, headSize)
    const tail = sorted.slice(headSize)
    const orders: ConnectionInfo[][] = []

    for (const headOrder of permutations(head)) {
      orders.push([...headOrder, ...tail])
      if (orders.length >= this.maxCandidateOrders) {
        break
      }
    }

    if (orders.length === 0) {
      orders.push(sorted)
    }

    return orders
  }

  private getConnections() {
    const byConnection = new Map<string, ConnectionInfo>()

    for (const portPoint of this.nodeWithPortPoints.portPoints) {
      const existing = byConnection.get(portPoint.connectionName)
      if (existing) {
        existing.portPoints.push(portPoint)
        existing.sides.add(this.getSide(portPoint))
        continue
      }

      byConnection.set(portPoint.connectionName, {
        connectionName: portPoint.connectionName,
        rootConnectionName: portPoint.rootConnectionName,
        portPoints: [portPoint],
        sides: new Set([this.getSide(portPoint)]),
      })
    }

    return Array.from(byConnection.values()).filter(
      (connection) => connection.portPoints.length >= 2,
    )
  }

  private makeSubproblem(connection: ConnectionInfo): NodeWithPortPoints {
    return {
      capacityMeshNodeId: this.nodeWithPortPoints.capacityMeshNodeId,
      center: this.nodeWithPortPoints.center,
      width: this.nodeWithPortPoints.width,
      height: this.nodeWithPortPoints.height,
      availableZ: this.nodeWithPortPoints.availableZ,
      portPoints: connection.portPoints.map((portPoint) => ({ ...portPoint })),
    }
  }

  private getSide(portPoint: PortPoint): Side {
    const dx = portPoint.x - this.nodeWithPortPoints.center.x
    const dy = portPoint.y - this.nodeWithPortPoints.center.y
    return Math.abs(dx) > Math.abs(dy)
      ? dx < 0
        ? "left"
        : "right"
      : dy < 0
        ? "bottom"
        : "top"
  }

  private isBetterCandidate(
    candidate: CandidateSolution,
    currentBest: CandidateSolution | null,
  ) {
    if (!currentBest) return true
    if (Number(candidate.complete) !== Number(currentBest.complete)) {
      return Number(candidate.complete) > Number(currentBest.complete)
    }
    if (
      !candidate.complete &&
      candidate.routes.length !== currentBest.routes.length
    ) {
      return candidate.routes.length > currentBest.routes.length
    }
    if (candidate.violations !== currentBest.violations) {
      return candidate.violations < currentBest.violations
    }
    if (candidate.intersections !== currentBest.intersections) {
      return candidate.intersections < currentBest.intersections
    }
    return candidate.routes.length > currentBest.routes.length
  }

  private factorial(value: number) {
    let total = 1
    for (let index = 2; index <= value; index += 1) {
      total *= index
      if (total > this.maxCandidateOrders) {
        return total
      }
    }
    return total
  }
}
