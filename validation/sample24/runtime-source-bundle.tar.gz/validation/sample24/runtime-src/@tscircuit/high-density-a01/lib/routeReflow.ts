import type { HighDensityIntraNodeRoute, NodeWithPortPoints } from "./types"

type RoutePoint = HighDensityIntraNodeRoute["route"][number]
type ViaPoint = HighDensityIntraNodeRoute["vias"][number]

type RouteSection = {
  z: number
  length: number
  points: RoutePoint[]
}

type Vector = {
  x: number
  y: number
}

type ViaAttraction = {
  target: Vector
  strengthScale: number
}

type Bounds = {
  minX: number
  maxX: number
  minY: number
  maxY: number
}

type MutableNode = {
  x: number
  y: number
  originalX: number
  originalY: number
  boundaryPadding: number
  pointIndexes: number[]
  fixed: boolean
  forceIndex: number
}

type MutableRoute = {
  route: HighDensityIntraNodeRoute
  rootConnectionName: string
  nodes: MutableNode[]
  pointNodeIndexes: Int32Array
}

type ForceElementBase = {
  routeIndex: number
  rootConnectionName: string
  node: MutableNode
  fixed: boolean
}

type PointForceElement = ForceElementBase & {
  kind: "point"
  z: number
}

type ViaForceElement = ForceElementBase & {
  kind: "via"
}

type ForceElement = PointForceElement | ViaForceElement

type SegmentObstacle = {
  rootConnectionName: string
  z: number
  startNode: MutableNode
  endNode: MutableNode
}

const DEFAULT_TARGET_TOTAL_SEGMENTS = 16
const ROUNDING_PRECISION = 1_000
const POSITION_EPSILON = 1e-6
const BOUNDARY_INSET = 1 / ROUNDING_PRECISION

const TARGET_CLEARANCE = 0.2
const CLEARANCE_FALLOFF_DISTANCE = 0.4
const POINT_SEGMENT_TARGET_CLEARANCE = 0.25
const POINT_SEGMENT_FALLOFF_DISTANCE = 0.5
const VIA_BORDER_EXTRA_CLEARANCE = 0.15
const VIA_SEGMENT_TARGET_CLEARANCE = 0.4
const VIA_SEGMENT_FALLOFF_DISTANCE = 0.5
const VIA_BORDER_TARGET_CLEARANCE =
  VIA_SEGMENT_TARGET_CLEARANCE + VIA_BORDER_EXTRA_CLEARANCE + 0.1
const VIA_BORDER_FALLOFF_DISTANCE = VIA_BORDER_TARGET_CLEARANCE + 0.05
const VIA_VIA_REPULSION_STRENGTH = 0.034
const VIA_SEGMENT_REPULSION_STRENGTH = 0.18
const POINT_SEGMENT_REPULSION_STRENGTH = 0.06
const REPULSION_TAIL_RATIO = 0.08
const REPULSION_FALLOFF = 18
const INTERSECTION_FORCE_BOOST = 3.5
const VIA_SEGMENT_INTERSECTION_FORCE_BOOST = 12
const BORDER_REPULSION_STRENGTH = 0.03
const BORDER_REPULSION_TAIL_RATIO = 0.08
const BORDER_REPULSION_FALLOFF = 20
const VIA_BORDER_REPULSION_TAIL_RATIO = 0.015
const VIA_BORDER_REPULSION_FALLOFF = 80
const VIA_CENTER_ATTRACTION_STRENGTH = 0.05
const VIA_CENTER_EDGE_ATTRACTION_BOOST = 0.08
const VIA_CENTER_EDGE_ATTRACTION_FALLOFF_DISTANCE = 1.5
const MAX_VIA_CENTER_MOVE_PER_STEP = 0.024
const CORNER_ORTHOGONAL_RELAX_DISTANCE = 0.5
const SHAPE_RESTORE_STRENGTH = 0.14
const PATH_SMOOTHING_STRENGTH = 0.22
const TIGHTENING_FORCE_STRENGTH = 0.55
const MAX_TIGHTENING_MOVE_PER_STEP = 0.02
const END_SEGMENT_ORTHOGONAL_FORCE_STRENGTH = 1.1
const MAX_END_SEGMENT_ORTHOGONAL_MOVE_PER_STEP = 0.06
const CLEARANCE_PROJECTION_RATIO = 0.9
const POINT_SEGMENT_CLEARANCE_PROJECTION_RATIO = 1.05
const VIA_SEGMENT_CLEARANCE_PROJECTION_RATIO = 1.35
const CLEARANCE_PROJECTION_PASSES = 3
const MAX_CLEARANCE_CORRECTION = 0.02
const VIA_SEGMENT_MAX_CLEARANCE_CORRECTION_MULTIPLIER = 3
const FINAL_CLEARANCE_PROJECTION_PASSES = 8
const FINAL_MAX_CLEARANCE_CORRECTION = 0.03
const STEP_SIZE = 0.85
const MAX_NODE_MOVE_PER_STEP = 0.012
const MIN_STEP_DECAY = 0.25

const roundCoordinate = (value: number) =>
  Math.round(value * ROUNDING_PRECISION) / ROUNDING_PRECISION

const clampUnitInterval = (value: number) => Math.max(0, Math.min(value, 1))

const clampValue = (value: number, minValue: number, maxValue: number) =>
  Math.max(minValue, Math.min(value, maxValue))

const copyPoint = (point: RoutePoint): RoutePoint => ({
  x: roundCoordinate(point.x),
  y: roundCoordinate(point.y),
  z: point.z,
  ...(point.insideJumperPad === undefined
    ? {}
    : { insideJumperPad: point.insideJumperPad }),
})

const isSamePosition = (left: RoutePoint, right: RoutePoint) =>
  left.x === right.x && left.y === right.y

const isSamePoint = (left: RoutePoint, right: RoutePoint) =>
  isSamePosition(left, right) && left.z === right.z

const getDistance = (left: RoutePoint, right: RoutePoint) =>
  Math.hypot(right.x - left.x, right.y - left.y)

const pushSectionPoint = (section: RouteSection, point: RoutePoint) => {
  const lastPoint = section.points.at(-1)
  if (lastPoint && isSamePoint(lastPoint, point)) return
  section.points.push(copyPoint(point))
}

const buildRouteSections = (points: RoutePoint[]): RouteSection[] => {
  const sections: RouteSection[] = []

  for (let index = 0; index < points.length - 1; index += 1) {
    const current = points[index]
    const next = points[index + 1]
    if (!current || !next) continue
    if (isSamePosition(current, next)) continue
    if (current.z !== next.z) continue

    const segmentLength = getDistance(current, next)
    if (segmentLength === 0) continue

    const lastSection = sections.at(-1)
    if (!lastSection || lastSection.z !== current.z) {
      sections.push({
        z: current.z,
        length: segmentLength,
        points: [copyPoint(current), copyPoint(next)],
      })
      continue
    }

    pushSectionPoint(lastSection, current)
    pushSectionPoint(lastSection, next)
    lastSection.length += segmentLength
  }

  return sections.filter((section) => section.points.length >= 2)
}

const allocateSegmentCounts = (
  sections: RouteSection[],
  targetSegmentCount: number,
) => {
  if (sections.length === 0) return []

  if (sections.length >= targetSegmentCount) {
    return sections.map(() => 1)
  }

  const segmentCounts = sections.map(() => 1)
  let remainingSegments = targetSegmentCount - sections.length
  if (remainingSegments <= 0) return segmentCounts

  const totalLength = sections.reduce(
    (total, section) => total + section.length,
    0,
  )

  if (totalLength === 0) {
    let index = 0
    while (remainingSegments > 0) {
      const targetIndex = index % segmentCounts.length
      segmentCounts[targetIndex] = (segmentCounts[targetIndex] ?? 0) + 1
      remainingSegments -= 1
      index += 1
    }
    return segmentCounts
  }

  const exactExtras = sections.map(
    (section) => (section.length / totalLength) * remainingSegments,
  )

  let assignedExtras = 0
  for (let index = 0; index < exactExtras.length; index += 1) {
    const extraSegmentCount = Math.floor(exactExtras[index] ?? 0)
    segmentCounts[index] = (segmentCounts[index] ?? 0) + extraSegmentCount
    assignedExtras += extraSegmentCount
  }

  const indexesByRemainder = exactExtras
    .map((value, index) => ({
      index,
      remainder: value - Math.floor(value),
      length: sections[index]?.length ?? 0,
    }))
    .sort((left, right) => {
      if (right.remainder !== left.remainder) {
        return right.remainder - left.remainder
      }
      return right.length - left.length
    })

  let leftoverSegments = remainingSegments - assignedExtras
  let remainderIndex = 0
  while (leftoverSegments > 0) {
    const targetIndex = indexesByRemainder[remainderIndex]?.index
    if (targetIndex === undefined) break
    segmentCounts[targetIndex] = (segmentCounts[targetIndex] ?? 0) + 1
    leftoverSegments -= 1
    remainderIndex += 1
  }

  return segmentCounts
}

const interpolateAlongSection = (
  section: RouteSection,
  targetDistance: number,
): RoutePoint => {
  if (targetDistance <= 0) {
    const firstPoint = section.points[0]
    return firstPoint ? copyPoint(firstPoint) : { x: 0, y: 0, z: section.z }
  }

  let traversedDistance = 0
  for (let index = 0; index < section.points.length - 1; index += 1) {
    const current = section.points[index]
    const next = section.points[index + 1]
    if (!current || !next) continue

    const segmentLength = getDistance(current, next)
    if (segmentLength === 0) continue

    const nextTraversedDistance = traversedDistance + segmentLength
    if (
      targetDistance <= nextTraversedDistance ||
      index === section.points.length - 2
    ) {
      const offset = clampUnitInterval(
        (targetDistance - traversedDistance) / segmentLength,
      )
      return {
        x: roundCoordinate(current.x + (next.x - current.x) * offset),
        y: roundCoordinate(current.y + (next.y - current.y) * offset),
        z: section.z,
      }
    }

    traversedDistance = nextTraversedDistance
  }

  const lastPoint = section.points.at(-1)
  return lastPoint ? copyPoint(lastPoint) : { x: 0, y: 0, z: section.z }
}

const sampleSectionPoints = (section: RouteSection, segmentCount: number) => {
  if (segmentCount <= 1) {
    const firstPoint = section.points[0]
    const lastPoint = section.points.at(-1)
    if (!firstPoint || !lastPoint) return []
    return [copyPoint(firstPoint), copyPoint(lastPoint)]
  }

  const sampledPoints: RoutePoint[] = []
  for (let index = 0; index <= segmentCount; index += 1) {
    sampledPoints.push(
      interpolateAlongSection(section, (section.length * index) / segmentCount),
    )
  }
  return sampledPoints
}

const appendPoint = (points: RoutePoint[], point: RoutePoint) => {
  const lastPoint = points.at(-1)
  if (lastPoint && isSamePoint(lastPoint, point)) return
  points.push(copyPoint(point))
}

const appendVia = (vias: ViaPoint[], point: RoutePoint) => {
  const nextVia = {
    x: roundCoordinate(point.x),
    y: roundCoordinate(point.y),
  }
  const lastVia = vias.at(-1)
  if (lastVia && lastVia.x === nextVia.x && lastVia.y === nextVia.y) return
  vias.push(nextVia)
}

export const deriveViasFromRoutePoints = (points: RoutePoint[]) => {
  const vias: ViaPoint[] = []
  for (let index = 0; index < points.length - 1; index += 1) {
    const current = points[index]
    const next = points[index + 1]
    if (!current || !next) continue
    if (current.z === next.z) continue
    if (
      Math.abs(current.x - next.x) > POSITION_EPSILON ||
      Math.abs(current.y - next.y) > POSITION_EPSILON
    ) {
      continue
    }
    appendVia(vias, current)
  }
  return vias
}

export const normalizeRouteToTotalSegmentCount = (
  route: HighDensityIntraNodeRoute,
  targetTotalSegments = DEFAULT_TARGET_TOTAL_SEGMENTS,
): HighDensityIntraNodeRoute => {
  if (route.route.length < 2 || targetTotalSegments <= 0) {
    return {
      ...route,
      route: route.route.map(copyPoint),
      vias: deriveViasFromRoutePoints(route.route),
    }
  }

  const sections = buildRouteSections(route.route)
  if (sections.length === 0) {
    return {
      ...route,
      route: route.route.map(copyPoint),
      vias: deriveViasFromRoutePoints(route.route),
    }
  }

  const viaCount = deriveViasFromRoutePoints(route.route).length
  const targetTraceSegments = Math.max(
    sections.length,
    targetTotalSegments - viaCount,
  )
  const segmentCounts = allocateSegmentCounts(sections, targetTraceSegments)
  const sampledSections = sections.map((section, index) =>
    sampleSectionPoints(section, segmentCounts[index] ?? 1),
  )

  const normalizedPoints: RoutePoint[] = []
  const normalizedVias: ViaPoint[] = []

  for (let index = 0; index < sampledSections.length; index += 1) {
    const sectionPoints = sampledSections[index]
    if (!sectionPoints || sectionPoints.length === 0) continue

    if (index === 0) {
      for (const point of sectionPoints) appendPoint(normalizedPoints, point)
      continue
    }

    const firstPoint = sectionPoints[0]
    const lastPoint = normalizedPoints.at(-1)
    if (!firstPoint || !lastPoint) continue

    if (!isSamePosition(lastPoint, firstPoint)) {
      appendPoint(normalizedPoints, {
        x: firstPoint.x,
        y: firstPoint.y,
        z: lastPoint.z,
      })
    }

    if (lastPoint.z !== firstPoint.z) {
      appendVia(normalizedVias, firstPoint)
      appendPoint(normalizedPoints, {
        x: firstPoint.x,
        y: firstPoint.y,
        z: firstPoint.z,
      })
    }

    for (const point of sectionPoints.slice(1)) {
      appendPoint(normalizedPoints, point)
    }
  }

  if (normalizedPoints.length > 0) {
    normalizedPoints[0] = copyPoint(route.route[0]!)
    normalizedPoints[normalizedPoints.length - 1] = copyPoint(
      route.route[route.route.length - 1]!,
    )
  }

  return {
    ...route,
    route: normalizedPoints,
    vias: normalizedVias,
  }
}

export const normalizeRoutesToTotalSegmentCount = (
  routes: HighDensityIntraNodeRoute[],
  targetTotalSegments = DEFAULT_TARGET_TOTAL_SEGMENTS,
) =>
  routes.map((route) =>
    normalizeRouteToTotalSegmentCount(route, targetTotalSegments),
  )

const addVector = (left: Vector, right: Vector): Vector => ({
  x: left.x + right.x,
  y: left.y + right.y,
})

const subtractVector = (left: Vector, right: Vector): Vector => ({
  x: left.x - right.x,
  y: left.y - right.y,
})

const scaleVector = (vector: Vector, scale: number): Vector => ({
  x: vector.x * scale,
  y: vector.y * scale,
})

const dotVector = (left: Vector, right: Vector) =>
  left.x * right.x + left.y * right.y

const lerpVector = (start: Vector, end: Vector, t: number): Vector => ({
  x: start.x + (end.x - start.x) * t,
  y: start.y + (end.y - start.y) * t,
})

const getVectorMagnitude = (vector: Vector) => Math.hypot(vector.x, vector.y)

const clampVectorMagnitude = (vector: Vector, maxMagnitude: number) => {
  const magnitude = getVectorMagnitude(vector)
  if (magnitude <= maxMagnitude || magnitude <= POSITION_EPSILON) return vector
  return scaleVector(vector, maxMagnitude / magnitude)
}

const isOutsideExpandedBounds = (
  pointX: number,
  pointY: number,
  minX: number,
  maxX: number,
  minY: number,
  maxY: number,
  expansion: number,
) =>
  pointX < minX - expansion ||
  pointX > maxX + expansion ||
  pointY < minY - expansion ||
  pointY > maxY + expansion

const getSampleBounds = (sample: NodeWithPortPoints): Bounds => ({
  minX: sample.center.x - sample.width / 2,
  maxX: sample.center.x + sample.width / 2,
  minY: sample.center.y - sample.height / 2,
  maxY: sample.center.y + sample.height / 2,
})

const getNearestCornerDistance = (
  bounds: Bounds,
  pointX: number,
  pointY: number,
) =>
  Math.min(
    Math.hypot(pointX - bounds.minX, pointY - bounds.minY),
    Math.hypot(pointX - bounds.minX, pointY - bounds.maxY),
    Math.hypot(pointX - bounds.maxX, pointY - bounds.minY),
    Math.hypot(pointX - bounds.maxX, pointY - bounds.maxY),
  )

const getCornerOrthogonalRelaxation = (
  endpoint: MutableNode,
  bounds: Bounds,
) => {
  const nearestCornerDistance = getNearestCornerDistance(
    bounds,
    endpoint.originalX,
    endpoint.originalY,
  )
  return clampUnitInterval(
    nearestCornerDistance / CORNER_ORTHOGONAL_RELAX_DISTANCE,
  )
}

const clampNodeToBounds = (node: MutableNode, bounds: Bounds) => {
  const inset = node.boundaryPadding > 0 ? BOUNDARY_INSET : 0
  const minX = bounds.minX + node.boundaryPadding + inset
  const maxX = bounds.maxX - node.boundaryPadding - inset
  const minY = bounds.minY + node.boundaryPadding + inset
  const maxY = bounds.maxY - node.boundaryPadding - inset
  node.x = clampValue(node.x, minX, maxX)
  node.y = clampValue(node.y, minY, maxY)
}

const clampMutableRoutesToBounds = (
  mutableRoutes: MutableRoute[],
  bounds: Bounds,
) => {
  for (const mutableRoute of mutableRoutes) {
    for (const node of mutableRoute.nodes) {
      clampNodeToBounds(node, bounds)
    }
  }
}

const getEndpointOrthogonalLockAxis = (
  endpoint: MutableNode,
  adjacentNode: MutableNode,
  bounds: Bounds,
): "x" | "y" => {
  const verticalEdgeDistance = Math.min(
    Math.abs(endpoint.originalX - bounds.minX),
    Math.abs(bounds.maxX - endpoint.originalX),
  )
  const horizontalEdgeDistance = Math.min(
    Math.abs(endpoint.originalY - bounds.minY),
    Math.abs(bounds.maxY - endpoint.originalY),
  )

  if (
    Math.abs(verticalEdgeDistance - horizontalEdgeDistance) <= POSITION_EPSILON
  ) {
    const deltaX = Math.abs(adjacentNode.x - endpoint.x)
    const deltaY = Math.abs(adjacentNode.y - endpoint.y)
    return deltaX >= deltaY ? "y" : "x"
  }

  return verticalEdgeDistance < horizontalEdgeDistance ? "y" : "x"
}

const getEndpointOrthogonalMove = (
  endpoint: MutableNode,
  adjacentNode: MutableNode,
  bounds: Bounds,
  decay: number,
) => {
  const cornerRelaxation = getCornerOrthogonalRelaxation(endpoint, bounds)
  if (cornerRelaxation <= POSITION_EPSILON) {
    return { x: 0, y: 0 }
  }

  const orthogonalLockAxis = getEndpointOrthogonalLockAxis(
    endpoint,
    adjacentNode,
    bounds,
  )

  if (orthogonalLockAxis === "x") {
    return clampVectorMagnitude(
      {
        x:
          (endpoint.x - adjacentNode.x) *
          END_SEGMENT_ORTHOGONAL_FORCE_STRENGTH *
          cornerRelaxation *
          decay,
        y: 0,
      },
      MAX_END_SEGMENT_ORTHOGONAL_MOVE_PER_STEP * cornerRelaxation * decay,
    )
  }

  return clampVectorMagnitude(
    {
      x: 0,
      y:
        (endpoint.y - adjacentNode.y) *
        END_SEGMENT_ORTHOGONAL_FORCE_STRENGTH *
        cornerRelaxation *
        decay,
    },
    MAX_END_SEGMENT_ORTHOGONAL_MOVE_PER_STEP * cornerRelaxation * decay,
  )
}

const getClearanceForceMagnitude = (
  distance: number,
  strength: number,
  tailRatio: number,
  falloff: number,
  intersectionBoost = INTERSECTION_FORCE_BOOST,
  targetClearance = TARGET_CLEARANCE,
  falloffDistance = CLEARANCE_FALLOFF_DISTANCE,
) => {
  const clampedDistance = Math.max(distance, 0)
  if (clampedDistance >= falloffDistance) return 0

  const normalizedDistance = clampedDistance / targetClearance
  if (normalizedDistance < 1) {
    const penetration = 1 - normalizedDistance
    return strength * penetration ** 3 * (1 + penetration * intersectionBoost)
  }

  const tailSpan = Math.max(falloffDistance - targetClearance, POSITION_EPSILON)
  const tailProgress = (clampedDistance - targetClearance) / tailSpan
  const tailMagnitude = strength * tailRatio * Math.exp(-tailProgress * falloff)
  return tailMagnitude < 1e-5 ? 0 : tailMagnitude
}

const getElementTargetClearance = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_SEGMENT_TARGET_CLEARANCE
    : POINT_SEGMENT_TARGET_CLEARANCE

const getElementFalloffDistance = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_SEGMENT_FALLOFF_DISTANCE
    : POINT_SEGMENT_FALLOFF_DISTANCE

const getBorderTargetClearance = (element: ForceElement) =>
  element.kind === "via" ? VIA_BORDER_TARGET_CLEARANCE : TARGET_CLEARANCE

const getBorderFalloffDistance = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_BORDER_FALLOFF_DISTANCE
    : CLEARANCE_FALLOFF_DISTANCE

const getBorderTailRatio = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_BORDER_REPULSION_TAIL_RATIO
    : BORDER_REPULSION_TAIL_RATIO

const getBorderRepulsionFalloff = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_BORDER_REPULSION_FALLOFF
    : BORDER_REPULSION_FALLOFF

const getElementIntersectionBoost = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_SEGMENT_INTERSECTION_FORCE_BOOST
    : INTERSECTION_FORCE_BOOST

const getPointSegmentRepulsionStrength = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_SEGMENT_REPULSION_STRENGTH
    : POINT_SEGMENT_REPULSION_STRENGTH

const getProjectionRatio = (element: ForceElement) =>
  element.kind === "via"
    ? VIA_SEGMENT_CLEARANCE_PROJECTION_RATIO
    : POINT_SEGMENT_CLEARANCE_PROJECTION_RATIO

const getMaxCorrectionForElement = (
  element: ForceElement,
  maxCorrection: number,
) =>
  element.kind === "via"
    ? maxCorrection * VIA_SEGMENT_MAX_CLEARANCE_CORRECTION_MULTIPLIER
    : maxCorrection

const buildMutableRoutes = (routes: HighDensityIntraNodeRoute[]) => {
  let nextForceIndex = 0
  const mutableRoutes = routes.map((route) => {
    const nodes: MutableNode[] = []
    const pointNodeIndexes = new Int32Array(route.route.length)
    pointNodeIndexes.fill(-1)

    for (let index = 0; index < route.route.length; index += 1) {
      const point = route.route[index]
      if (!point) continue

      const previousPoint = route.route[index - 1]
      const lastNode = nodes.at(-1)
      const lastNodeIndex = nodes.length - 1

      if (
        lastNode &&
        previousPoint &&
        previousPoint.x === point.x &&
        previousPoint.y === point.y
      ) {
        lastNode.boundaryPadding = Math.max(
          lastNode.boundaryPadding,
          route.viaDiameter / 2,
        )
        lastNode.pointIndexes.push(index)
        pointNodeIndexes[index] = lastNodeIndex
        continue
      }

      nodes.push({
        x: point.x,
        y: point.y,
        originalX: point.x,
        originalY: point.y,
        boundaryPadding: 0,
        pointIndexes: [index],
        fixed: index === 0 || index === route.route.length - 1,
        forceIndex: nextForceIndex,
      })
      pointNodeIndexes[index] = nodes.length - 1
      nextForceIndex += 1
    }

    return {
      route,
      rootConnectionName: route.rootConnectionName ?? route.connectionName,
      nodes,
      pointNodeIndexes,
    }
  })

  return { mutableRoutes, totalNodeCount: nextForceIndex }
}

const buildForceElements = (routes: MutableRoute[]) => {
  const elements: ForceElement[] = []

  for (let routeIndex = 0; routeIndex < routes.length; routeIndex += 1) {
    const mutableRoute = routes[routeIndex]
    if (!mutableRoute) continue

    for (
      let nodeIndex = 0;
      nodeIndex < mutableRoute.nodes.length;
      nodeIndex++
    ) {
      const node = mutableRoute.nodes[nodeIndex]
      const routePointIndex = node?.pointIndexes[0]
      const routePoint =
        routePointIndex === undefined
          ? undefined
          : mutableRoute.route.route[routePointIndex]
      if (!node || !routePoint) continue

      if (node.pointIndexes.length > 1) {
        elements.push({
          kind: "via",
          routeIndex,
          rootConnectionName: mutableRoute.rootConnectionName,
          node,
          fixed: node.fixed,
        })
        continue
      }

      elements.push({
        kind: "point",
        routeIndex,
        rootConnectionName: mutableRoute.rootConnectionName,
        node,
        z: routePoint.z,
        fixed: node.fixed,
      })
    }
  }

  return elements
}

const buildSegmentObstacles = (routes: MutableRoute[]) => {
  const segments: SegmentObstacle[] = []

  for (let routeIndex = 0; routeIndex < routes.length; routeIndex += 1) {
    const mutableRoute = routes[routeIndex]
    if (!mutableRoute) continue

    for (
      let nodeIndex = 0;
      nodeIndex < mutableRoute.nodes.length - 1;
      nodeIndex += 1
    ) {
      const startNode = mutableRoute.nodes[nodeIndex]
      const endNode = mutableRoute.nodes[nodeIndex + 1]
      const routePointIndex =
        startNode?.pointIndexes[startNode.pointIndexes.length - 1]
      const routePoint =
        routePointIndex === undefined
          ? undefined
          : mutableRoute.route.route[routePointIndex]

      if (!startNode || !endNode || !routePoint) continue
      segments.push({
        rootConnectionName: mutableRoute.rootConnectionName,
        z: routePoint.z,
        startNode,
        endNode,
      })
    }
  }

  return segments
}

const addForceToNode = (
  nodeForces: Float64Array,
  forceIndex: number,
  forceX: number,
  forceY: number,
) => {
  const forceOffset = forceIndex * 2
  nodeForces[forceOffset] = (nodeForces[forceOffset] ?? 0) + forceX
  nodeForces[forceOffset + 1] = (nodeForces[forceOffset + 1] ?? 0) + forceY
}

const applyForceToElement = (
  element: ForceElement,
  forceX: number,
  forceY: number,
  nodeForces: Float64Array,
) => {
  if (element.fixed) return
  addForceToNode(nodeForces, element.node.forceIndex, forceX, forceY)
}

const distributeForceToSegmentPoints = (
  segment: SegmentObstacle,
  forceX: number,
  forceY: number,
  nodeForces: Float64Array,
  segmentT = 0.5,
) => {
  const { startNode, endNode } = segment
  const startWeight = 1 - clampUnitInterval(segmentT)
  const endWeight = clampUnitInterval(segmentT)
  const movableStartWeight = startNode.fixed ? 0 : startWeight
  const movableEndWeight = endNode.fixed ? 0 : endWeight
  const movableWeightTotal = movableStartWeight + movableEndWeight
  if (movableWeightTotal <= POSITION_EPSILON) return

  if (!startNode.fixed && movableStartWeight > 0) {
    const scale = movableStartWeight / movableWeightTotal
    addForceToNode(
      nodeForces,
      startNode.forceIndex,
      forceX * scale,
      forceY * scale,
    )
  }

  if (!endNode.fixed && movableEndWeight > 0) {
    const scale = movableEndWeight / movableWeightTotal
    addForceToNode(
      nodeForces,
      endNode.forceIndex,
      forceX * scale,
      forceY * scale,
    )
  }
}

const getBorderForce = (
  bounds: Bounds,
  element: ForceElement,
  elementX: number,
  elementY: number,
  stepDecay: number,
): Vector => {
  if (element.fixed) return { x: 0, y: 0 }

  const { minX, maxX, minY, maxY } = bounds
  const targetClearance = getBorderTargetClearance(element)
  const falloffDistance = getBorderFalloffDistance(element)
  const tailRatio = getBorderTailRatio(element)
  const borderRepulsionFalloff = getBorderRepulsionFalloff(element)
  const intersectionBoost = getElementIntersectionBoost(element)

  return {
    x:
      getClearanceForceMagnitude(
        elementX - minX,
        BORDER_REPULSION_STRENGTH,
        tailRatio,
        borderRepulsionFalloff,
        intersectionBoost,
        targetClearance,
        falloffDistance,
      ) *
        stepDecay -
      getClearanceForceMagnitude(
        maxX - elementX,
        BORDER_REPULSION_STRENGTH,
        tailRatio,
        borderRepulsionFalloff,
        intersectionBoost,
        targetClearance,
        falloffDistance,
      ) *
        stepDecay,
    y:
      getClearanceForceMagnitude(
        elementY - minY,
        BORDER_REPULSION_STRENGTH,
        tailRatio,
        borderRepulsionFalloff,
        intersectionBoost,
        targetClearance,
        falloffDistance,
      ) *
        stepDecay -
      getClearanceForceMagnitude(
        maxY - elementY,
        BORDER_REPULSION_STRENGTH,
        tailRatio,
        borderRepulsionFalloff,
        intersectionBoost,
        targetClearance,
        falloffDistance,
      ) *
        stepDecay,
  }
}

const getNearestBorderDistance = (
  bounds: Bounds,
  pointX: number,
  pointY: number,
) =>
  Math.min(
    pointX - bounds.minX,
    bounds.maxX - pointX,
    pointY - bounds.minY,
    bounds.maxY - pointY,
  )

const getViaAttractionTarget = (
  sample: NodeWithPortPoints,
  bounds: Bounds,
): ViaAttraction => {
  const centerX = (bounds.minX + bounds.maxX) * 0.5
  const centerY = (bounds.minY + bounds.maxY) * 0.5

  if (sample.portPoints.length === 0) {
    return {
      target: {
        x: centerX,
        y: centerY,
      },
      strengthScale: 1,
    }
  }

  const portCentroid = sample.portPoints.reduce(
    (accumulator, portPoint) => ({
      x: accumulator.x + portPoint.x,
      y: accumulator.y + portPoint.y,
    }),
    { x: 0, y: 0 },
  )
  const inversePortCount = 1 / sample.portPoints.length
  const portCenterX = portCentroid.x * inversePortCount
  const portCenterY = portCentroid.y * inversePortCount
  const halfWidth = Math.max(
    (bounds.maxX - bounds.minX) * 0.5,
    POSITION_EPSILON,
  )
  const halfHeight = Math.max(
    (bounds.maxY - bounds.minY) * 0.5,
    POSITION_EPSILON,
  )
  const skewMagnitude = clampUnitInterval(
    Math.hypot(
      (portCenterX - centerX) / halfWidth,
      (portCenterY - centerY) / halfHeight,
    ),
  )

  return {
    target: {
      x: clampValue(
        bounds.minX + bounds.maxX - portCenterX,
        bounds.minX + BOUNDARY_INSET,
        bounds.maxX - BOUNDARY_INSET,
      ),
      y: clampValue(
        bounds.minY + bounds.maxY - portCenterY,
        bounds.minY + BOUNDARY_INSET,
        bounds.maxY - BOUNDARY_INSET,
      ),
    },
    strengthScale: 1 + skewMagnitude * 1.5,
  }
}

const getViaCenterForce = (
  bounds: Bounds,
  viaAttraction: ViaAttraction,
  element: ForceElement,
  elementX: number,
  elementY: number,
  stepDecay: number,
): Vector => {
  if (element.fixed || element.kind !== "via") return { x: 0, y: 0 }

  const nearestBorderDistance = getNearestBorderDistance(
    bounds,
    elementX,
    elementY,
  )
  const edgePressure =
    1 -
    clampUnitInterval(
      nearestBorderDistance / VIA_CENTER_EDGE_ATTRACTION_FALLOFF_DISTANCE,
    )
  const attractionStrength =
    (VIA_CENTER_ATTRACTION_STRENGTH +
      edgePressure * VIA_CENTER_EDGE_ATTRACTION_BOOST) *
    viaAttraction.strengthScale

  return {
    x: (viaAttraction.target.x - elementX) * attractionStrength * stepDecay,
    y: (viaAttraction.target.y - elementY) * attractionStrength * stepDecay,
  }
}

const getViaCenterMove = (
  bounds: Bounds,
  viaAttraction: ViaAttraction,
  node: MutableNode,
  stepDecay: number,
): Vector => {
  if (node.fixed || node.pointIndexes.length <= 1) return { x: 0, y: 0 }

  const nearestBorderDistance = getNearestBorderDistance(bounds, node.x, node.y)
  const edgePressure =
    1 -
    clampUnitInterval(
      nearestBorderDistance / VIA_CENTER_EDGE_ATTRACTION_FALLOFF_DISTANCE,
    )
  const attractionStrength =
    (VIA_CENTER_ATTRACTION_STRENGTH +
      edgePressure * VIA_CENTER_EDGE_ATTRACTION_BOOST) *
    viaAttraction.strengthScale

  return clampVectorMagnitude(
    {
      x: (viaAttraction.target.x - node.x) * attractionStrength * stepDecay,
      y: (viaAttraction.target.y - node.y) * attractionStrength * stepDecay,
    },
    MAX_VIA_CENTER_MOVE_PER_STEP *
      (1 + edgePressure) *
      viaAttraction.strengthScale *
      stepDecay,
  )
}

const materializeRoutes = (mutableRoutes: MutableRoute[]) =>
  mutableRoutes.map(({ route, nodes, pointNodeIndexes }) => {
    const nextRoutePoints = route.route.map((point, pointIndex) => {
      const ownerNodeIndex = pointNodeIndexes[pointIndex] ?? -1
      const ownerNode = ownerNodeIndex >= 0 ? nodes[ownerNodeIndex] : undefined
      return ownerNode
        ? {
            ...point,
            x: roundCoordinate(ownerNode.x),
            y: roundCoordinate(ownerNode.y),
          }
        : point
    })

    return {
      ...route,
      route: nextRoutePoints,
      vias: deriveViasFromRoutePoints(nextRoutePoints),
    }
  })

const resolveClearanceConstraints = (
  bounds: Bounds,
  mutableRoutes: MutableRoute[],
  forceElements: ForceElement[],
  segments: SegmentObstacle[],
  nodeCorrections: Float64Array,
  passCount = CLEARANCE_PROJECTION_PASSES,
  maxCorrection = MAX_CLEARANCE_CORRECTION,
) => {
  for (let passIndex = 0; passIndex < passCount; passIndex += 1) {
    nodeCorrections.fill(0)

    for (let leftIndex = 0; leftIndex < forceElements.length; leftIndex += 1) {
      const leftElement = forceElements[leftIndex]
      if (!leftElement || leftElement.kind !== "via") continue
      const leftNode = leftElement.node

      for (
        let rightIndex = leftIndex + 1;
        rightIndex < forceElements.length;
        rightIndex++
      ) {
        const rightElement = forceElements[rightIndex]
        if (!rightElement || rightElement.kind !== "via") continue
        if (
          leftElement.rootConnectionName === rightElement.rootConnectionName
        ) {
          continue
        }
        const rightNode = rightElement.node
        const separationX = leftNode.x - rightNode.x
        const separationY = leftNode.y - rightNode.y
        if (
          Math.abs(separationX) >= TARGET_CLEARANCE ||
          Math.abs(separationY) >= TARGET_CLEARANCE
        ) {
          continue
        }
        const distance = Math.hypot(separationX, separationY)
        const penetration = TARGET_CLEARANCE - distance
        if (penetration <= 0) continue

        const fallbackSeed =
          passIndex * 1_009 + leftIndex * 97 + rightIndex * 13
        let directionX = 0
        let directionY = 0

        if (distance > POSITION_EPSILON) {
          const inverseDistance = 1 / distance
          directionX = separationX * inverseDistance
          directionY = separationY * inverseDistance
        } else {
          const angle = fallbackSeed * 1.618_033_988_75
          directionX = Math.cos(angle)
          directionY = Math.sin(angle)
        }

        const magnitude = Math.min(
          maxCorrection,
          penetration * CLEARANCE_PROJECTION_RATIO,
        )
        const leftCorrectionX = directionX * magnitude
        const leftCorrectionY = directionY * magnitude

        applyForceToElement(
          leftElement,
          leftCorrectionX,
          leftCorrectionY,
          nodeCorrections,
        )
        applyForceToElement(
          rightElement,
          -leftCorrectionX,
          -leftCorrectionY,
          nodeCorrections,
        )
      }
    }

    for (
      let elementIndex = 0;
      elementIndex < forceElements.length;
      elementIndex += 1
    ) {
      const element = forceElements[elementIndex]
      if (!element) continue
      const elementNode = element.node

      for (
        let segmentIndex = 0;
        segmentIndex < segments.length;
        segmentIndex += 1
      ) {
        const segment = segments[segmentIndex]
        if (!segment) continue
        if (element.rootConnectionName === segment.rootConnectionName) {
          continue
        }
        if (element.kind === "point" && element.z !== segment.z) continue

        const { startNode, endNode } = segment
        const targetClearance = getElementTargetClearance(element)
        const minSegmentX = Math.min(startNode.x, endNode.x)
        const maxSegmentX = Math.max(startNode.x, endNode.x)
        const minSegmentY = Math.min(startNode.y, endNode.y)
        const maxSegmentY = Math.max(startNode.y, endNode.y)
        if (
          isOutsideExpandedBounds(
            elementNode.x,
            elementNode.y,
            minSegmentX,
            maxSegmentX,
            minSegmentY,
            maxSegmentY,
            targetClearance,
          )
        ) {
          continue
        }

        const segmentX = endNode.x - startNode.x
        const segmentY = endNode.y - startNode.y
        const segmentLengthSquared = segmentX * segmentX + segmentY * segmentY
        if (segmentLengthSquared <= POSITION_EPSILON) continue

        const toPointX = elementNode.x - startNode.x
        const toPointY = elementNode.y - startNode.y
        const segmentT = clampUnitInterval(
          (toPointX * segmentX + toPointY * segmentY) / segmentLengthSquared,
        )
        const closestPointX = startNode.x + segmentX * segmentT
        const closestPointY = startNode.y + segmentY * segmentT
        const separationX = elementNode.x - closestPointX
        const separationY = elementNode.y - closestPointY
        const distance = Math.hypot(separationX, separationY)
        const penetration = targetClearance - distance
        if (penetration <= 0) continue

        const fallbackSeed =
          passIndex * 1_009 + elementIndex * 97 + segmentIndex * 13
        let directionX = 0
        let directionY = 0

        if (distance > POSITION_EPSILON) {
          const inverseDistance = 1 / distance
          directionX = separationX * inverseDistance
          directionY = separationY * inverseDistance
        } else {
          const normalX = -segmentY
          const normalY = segmentX
          const normalMagnitude = Math.hypot(normalX, normalY)
          if (normalMagnitude > POSITION_EPSILON) {
            const directionScale =
              (fallbackSeed % 2 === 0 ? 1 : -1) / normalMagnitude
            directionX = normalX * directionScale
            directionY = normalY * directionScale
          } else {
            const angle = fallbackSeed * 1.618_033_988_75
            directionX = Math.cos(angle)
            directionY = Math.sin(angle)
          }
        }

        const magnitude = Math.min(
          getMaxCorrectionForElement(element, maxCorrection),
          penetration * getProjectionRatio(element),
        )
        const pointCorrectionX = directionX * magnitude
        const pointCorrectionY = directionY * magnitude

        applyForceToElement(
          element,
          pointCorrectionX,
          pointCorrectionY,
          nodeCorrections,
        )
        distributeForceToSegmentPoints(
          segment,
          -pointCorrectionX,
          -pointCorrectionY,
          nodeCorrections,
          segmentT,
        )
      }
    }

    for (
      let routeIndex = 0;
      routeIndex < mutableRoutes.length;
      routeIndex += 1
    ) {
      const mutableRoute = mutableRoutes[routeIndex]
      if (!mutableRoute) continue

      for (
        let nodeIndex = 0;
        nodeIndex < mutableRoute.nodes.length;
        nodeIndex += 1
      ) {
        const node = mutableRoute.nodes[nodeIndex]
        if (!node || node.fixed) continue
        const correctionOffset = node.forceIndex * 2
        let correctionX = nodeCorrections[correctionOffset] ?? 0
        let correctionY = nodeCorrections[correctionOffset + 1] ?? 0
        const correctionMagnitude = Math.hypot(correctionX, correctionY)
        if (
          correctionMagnitude > maxCorrection &&
          correctionMagnitude > POSITION_EPSILON
        ) {
          const correctionScale = maxCorrection / correctionMagnitude
          correctionX *= correctionScale
          correctionY *= correctionScale
        }
        node.x += correctionX
        node.y += correctionY
      }
    }

    clampMutableRoutesToBounds(mutableRoutes, bounds)
  }
}

export const runForceDirectedRouteReflow = (
  sample: NodeWithPortPoints,
  routes: HighDensityIntraNodeRoute[],
  totalSteps: number,
) => {
  if (totalSteps <= 0 || routes.length === 0) {
    return routes.map((route) => ({
      ...route,
      route: route.route.map(copyPoint),
      vias: deriveViasFromRoutePoints(route.route),
    }))
  }

  const bounds = getSampleBounds(sample)
  const viaAttractionTarget = getViaAttractionTarget(sample, bounds)
  const { mutableRoutes, totalNodeCount } = buildMutableRoutes(routes)
  const forceElements = buildForceElements(mutableRoutes)
  const segments = buildSegmentObstacles(mutableRoutes)
  const nodeForces = new Float64Array(totalNodeCount * 2)
  const nodeCorrections = new Float64Array(totalNodeCount * 2)

  clampMutableRoutesToBounds(mutableRoutes, bounds)

  for (let stepIndex = 0; stepIndex < totalSteps; stepIndex += 1) {
    const progress =
      totalSteps <= 1 ? 0 : stepIndex / Math.max(totalSteps - 1, 1)
    const stepDecay = MIN_STEP_DECAY + (1 - progress) * (1 - MIN_STEP_DECAY)
    const tighteningDecay = 1 - progress
    nodeForces.fill(0)

    for (let leftIndex = 0; leftIndex < forceElements.length; leftIndex += 1) {
      const leftElement = forceElements[leftIndex]
      if (!leftElement || leftElement.kind !== "via") continue
      const leftNode = leftElement.node

      for (
        let rightIndex = leftIndex + 1;
        rightIndex < forceElements.length;
        rightIndex += 1
      ) {
        const rightElement = forceElements[rightIndex]
        if (!rightElement || rightElement.kind !== "via") continue
        if (
          leftElement.rootConnectionName === rightElement.rootConnectionName
        ) {
          continue
        }
        const rightNode = rightElement.node
        const separationX = leftNode.x - rightNode.x
        const separationY = leftNode.y - rightNode.y
        if (
          Math.abs(separationX) >= CLEARANCE_FALLOFF_DISTANCE ||
          Math.abs(separationY) >= CLEARANCE_FALLOFF_DISTANCE
        ) {
          continue
        }
        const distance = Math.hypot(separationX, separationY)
        const fallbackSeed = leftIndex * 97 + rightIndex * 13
        let directionX = 0
        let directionY = 0

        if (distance > POSITION_EPSILON) {
          const inverseDistance = 1 / distance
          directionX = separationX * inverseDistance
          directionY = separationY * inverseDistance
        } else {
          const angle = fallbackSeed * 1.618_033_988_75
          directionX = Math.cos(angle)
          directionY = Math.sin(angle)
        }

        const magnitude =
          getClearanceForceMagnitude(
            distance,
            VIA_VIA_REPULSION_STRENGTH,
            REPULSION_TAIL_RATIO,
            REPULSION_FALLOFF,
          ) * stepDecay
        if (magnitude <= 0) continue

        const leftForceX = directionX * magnitude
        const leftForceY = directionY * magnitude
        applyForceToElement(leftElement, leftForceX, leftForceY, nodeForces)
        applyForceToElement(rightElement, -leftForceX, -leftForceY, nodeForces)
      }
    }

    for (
      let elementIndex = 0;
      elementIndex < forceElements.length;
      elementIndex += 1
    ) {
      const element = forceElements[elementIndex]
      if (!element) continue
      const elementNode = element.node

      for (
        let segmentIndex = 0;
        segmentIndex < segments.length;
        segmentIndex += 1
      ) {
        const segment = segments[segmentIndex]
        if (!segment) continue
        if (element.rootConnectionName === segment.rootConnectionName) {
          continue
        }
        if (element.kind === "point" && element.z !== segment.z) continue

        const { startNode, endNode } = segment
        const falloffDistance = getElementFalloffDistance(element)
        const minSegmentX = Math.min(startNode.x, endNode.x)
        const maxSegmentX = Math.max(startNode.x, endNode.x)
        const minSegmentY = Math.min(startNode.y, endNode.y)
        const maxSegmentY = Math.max(startNode.y, endNode.y)
        if (
          isOutsideExpandedBounds(
            elementNode.x,
            elementNode.y,
            minSegmentX,
            maxSegmentX,
            minSegmentY,
            maxSegmentY,
            falloffDistance,
          )
        ) {
          continue
        }

        const segmentX = endNode.x - startNode.x
        const segmentY = endNode.y - startNode.y
        const segmentLengthSquared = segmentX * segmentX + segmentY * segmentY
        if (segmentLengthSquared <= POSITION_EPSILON) continue

        const toPointX = elementNode.x - startNode.x
        const toPointY = elementNode.y - startNode.y
        const segmentT = clampUnitInterval(
          (toPointX * segmentX + toPointY * segmentY) / segmentLengthSquared,
        )
        const closestPointX = startNode.x + segmentX * segmentT
        const closestPointY = startNode.y + segmentY * segmentT
        const separationX = elementNode.x - closestPointX
        const separationY = elementNode.y - closestPointY
        const distance = Math.hypot(separationX, separationY)
        const fallbackSeed = elementIndex * 97 + segmentIndex * 13
        let directionX = 0
        let directionY = 0

        if (distance > POSITION_EPSILON) {
          const inverseDistance = 1 / distance
          directionX = separationX * inverseDistance
          directionY = separationY * inverseDistance
        } else {
          const normalX = -segmentY
          const normalY = segmentX
          const normalMagnitude = Math.hypot(normalX, normalY)
          if (normalMagnitude > POSITION_EPSILON) {
            const directionScale =
              (fallbackSeed % 2 === 0 ? 1 : -1) / normalMagnitude
            directionX = normalX * directionScale
            directionY = normalY * directionScale
          } else {
            const angle = fallbackSeed * 1.618_033_988_75
            directionX = Math.cos(angle)
            directionY = Math.sin(angle)
          }
        }

        const magnitude =
          getClearanceForceMagnitude(
            distance,
            getPointSegmentRepulsionStrength(element),
            REPULSION_TAIL_RATIO,
            REPULSION_FALLOFF,
            getElementIntersectionBoost(element),
            getElementTargetClearance(element),
            falloffDistance,
          ) * stepDecay
        if (magnitude <= 0) continue

        const pointForceX = directionX * magnitude
        const pointForceY = directionY * magnitude
        applyForceToElement(element, pointForceX, pointForceY, nodeForces)
        distributeForceToSegmentPoints(
          segment,
          -pointForceX,
          -pointForceY,
          nodeForces,
          segmentT,
        )
      }
    }

    for (
      let elementIndex = 0;
      elementIndex < forceElements.length;
      elementIndex += 1
    ) {
      const element = forceElements[elementIndex]
      if (!element) continue
      const elementNode = element.node
      const borderForce = getBorderForce(
        bounds,
        element,
        elementNode.x,
        elementNode.y,
        stepDecay,
      )
      applyForceToElement(element, borderForce.x, borderForce.y, nodeForces)

      const viaCenterForce = getViaCenterForce(
        bounds,
        viaAttractionTarget,
        element,
        elementNode.x,
        elementNode.y,
        stepDecay,
      )
      applyForceToElement(
        element,
        viaCenterForce.x,
        viaCenterForce.y,
        nodeForces,
      )
    }

    for (
      let routeIndex = 0;
      routeIndex < mutableRoutes.length;
      routeIndex += 1
    ) {
      const mutableRoute = mutableRoutes[routeIndex]
      if (!mutableRoute) continue
      const lastMovableNodeIndex = mutableRoute.nodes.length - 2

      for (
        let nodeIndex = 0;
        nodeIndex < mutableRoute.nodes.length;
        nodeIndex += 1
      ) {
        const node = mutableRoute.nodes[nodeIndex]
        if (!node || node.fixed) continue
        const forceOffset = node.forceIndex * 2
        let nextForceX =
          (nodeForces[forceOffset] ?? 0) +
          (node.originalX - node.x) * SHAPE_RESTORE_STRENGTH
        let nextForceY =
          (nodeForces[forceOffset + 1] ?? 0) +
          (node.originalY - node.y) * SHAPE_RESTORE_STRENGTH
        let tighteningMoveX = 0
        let tighteningMoveY = 0
        let orthogonalMoveX = 0
        let orthogonalMoveY = 0
        let viaCenterMoveX = 0
        let viaCenterMoveY = 0

        const previousNode = mutableRoute.nodes[nodeIndex - 1]
        const nextNode = mutableRoute.nodes[nodeIndex + 1]
        if (previousNode || nextNode) {
          let totalReferenceX = 0
          let totalReferenceY = 0
          let referenceCount = 0

          if (previousNode) {
            totalReferenceX += previousNode.x
            totalReferenceY += previousNode.y
            referenceCount += 1
          }

          if (nextNode) {
            totalReferenceX += nextNode.x
            totalReferenceY += nextNode.y
            referenceCount += 1
          }

          if (referenceCount > 0) {
            const inverseReferenceCount = 1 / referenceCount
            nextForceX +=
              (totalReferenceX * inverseReferenceCount - node.x) *
              PATH_SMOOTHING_STRENGTH
            nextForceY +=
              (totalReferenceY * inverseReferenceCount - node.y) *
              PATH_SMOOTHING_STRENGTH
          }
        }

        if (previousNode && nextNode && tighteningDecay > 0) {
          const segmentVector = subtractVector(nextNode, previousNode)
          const segmentLengthSquared = dotVector(segmentVector, segmentVector)
          if (segmentLengthSquared > POSITION_EPSILON) {
            const projectionT = clampUnitInterval(
              dotVector(subtractVector(node, previousNode), segmentVector) /
                segmentLengthSquared,
            )
            const tighteningTarget = lerpVector(
              previousNode,
              nextNode,
              projectionT,
            )
            const tighteningMove = clampVectorMagnitude(
              scaleVector(
                subtractVector(tighteningTarget, node),
                TIGHTENING_FORCE_STRENGTH * tighteningDecay,
              ),
              MAX_TIGHTENING_MOVE_PER_STEP * tighteningDecay,
            )
            tighteningMoveX = tighteningMove.x
            tighteningMoveY = tighteningMove.y
          }
        }

        if (tighteningDecay > 0) {
          if (nodeIndex === 1 && previousNode?.fixed) {
            const orthogonalMove = getEndpointOrthogonalMove(
              previousNode,
              node,
              bounds,
              tighteningDecay,
            )
            orthogonalMoveX += orthogonalMove.x
            orthogonalMoveY += orthogonalMove.y
          }

          if (nodeIndex === lastMovableNodeIndex && nextNode?.fixed) {
            const orthogonalMove = getEndpointOrthogonalMove(
              nextNode,
              node,
              bounds,
              tighteningDecay,
            )
            orthogonalMoveX += orthogonalMove.x
            orthogonalMoveY += orthogonalMove.y
          }
        }

        if (node.pointIndexes.length > 1) {
          const viaCenterMove = getViaCenterMove(
            bounds,
            viaAttractionTarget,
            node,
            stepDecay,
          )
          viaCenterMoveX = viaCenterMove.x
          viaCenterMoveY = viaCenterMove.y
        }

        let movementX = nextForceX * STEP_SIZE * stepDecay
        let movementY = nextForceY * STEP_SIZE * stepDecay
        const movementMagnitude = Math.hypot(movementX, movementY)
        const maxMovementMagnitude = MAX_NODE_MOVE_PER_STEP * stepDecay
        if (
          movementMagnitude > maxMovementMagnitude &&
          movementMagnitude > POSITION_EPSILON
        ) {
          const movementScale = maxMovementMagnitude / movementMagnitude
          movementX *= movementScale
          movementY *= movementScale
        }

        node.x += movementX + tighteningMoveX + orthogonalMoveX + viaCenterMoveX
        node.y += movementY + tighteningMoveY + orthogonalMoveY + viaCenterMoveY
      }
    }

    clampMutableRoutesToBounds(mutableRoutes, bounds)
    resolveClearanceConstraints(
      bounds,
      mutableRoutes,
      forceElements,
      segments,
      nodeCorrections,
    )
  }

  resolveClearanceConstraints(
    bounds,
    mutableRoutes,
    forceElements,
    segments,
    nodeCorrections,
    FINAL_CLEARANCE_PROJECTION_PASSES,
    FINAL_MAX_CLEARANCE_CORRECTION,
  )

  return materializeRoutes(mutableRoutes)
}
