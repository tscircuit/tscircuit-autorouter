import type { ConnectivityMap } from "circuit-json-to-connectivity-map"
import { GraphicsObject } from "graphics-debug"
import { HighDensityRouteSpatialIndex } from "../../data-structures/HighDensityRouteSpatialIndex"
import { ObstacleSpatialHashIndex } from "../../data-structures/ObstacleTree"
import type { HighDensityRoute } from "../../types/high-density-types"
import { calculate45DegreePaths } from "../../utils/calculate45DegreePaths"
import { getVectorLength } from "../../utils/getVectorLength"
import { doesSegmentCrossPolygonBoundary } from "../../utils/polygonContainment"
import { BaseSolver } from "../BaseSolver"
import { breakRouteIntoSections } from "./break-route-into-sections"
import { canEndpointConnectOnLayer } from "./can-endpoint-connect-on-layer"
import { canSectionMoveToLayer } from "./can-section-move-to-layer"
import { createObstacleDetourPathValidator } from "./create-obstacle-detour-path-validator"
import type { RouteSection } from "./route-section"

type RoutePoint = HighDensityRoute["route"][number]

type ViaPairShortcut = {
  path: RoutePoint[]
  previousPointIndex: number
  nextPointIndex: number
  savedLength: number
  validationFirstSegmentIndex?: number
}

type ObstacleDetourPath = {
  path: RoutePoint[]
  length: number
  longestSegmentIndex: number
}

type ObstacleDetourContext = {
  targetZ: number
  traceCorners: Array<{ x: number; y: number }>
  corridorXs: Set<number>
  corridorYs: Set<number>
}

type MultilayerSectionCollapse = {
  targetZ: number
  mergeWith: "previous" | "next"
}

export class SingleRouteUselessViaRemovalSolver extends BaseSolver {
  override getSolverName(): string {
    return "SingleRouteUselessViaRemovalSolver"
  }

  obstacleSHI: ObstacleSpatialHashIndex
  hdRouteSHI: HighDensityRouteSpatialIndex
  unsimplifiedRoute: HighDensityRoute
  connMap: ConnectivityMap
  outline?: Array<{ x: number; y: number }>
  terminalLayerIndicesByPcbPortId?: ReadonlyMap<string, ReadonlySet<number>>

  routeSections: Array<RouteSection>

  currentSectionIndex: number
  private readonly sameNetRouteCache = new WeakMap<HighDensityRoute, boolean>()
  private detourContexts = new WeakMap<
    RoutePoint,
    WeakMap<RoutePoint, ObstacleDetourContext>
  >()

  TRACE_THICKNESS = 0.15
  OBSTACLE_MARGIN = 0.1
  GEOMETRY_SHORTCUT_TRACE_MARGIN = 0.1
  GEOMETRY_SHORTCUT_OBSTACLE_MARGIN = 0.15
  MAX_GEOMETRY_SHORTCUT_ADDED_LENGTH = 4
  ENABLE_GEOMETRY_SHORTCUTS = true
  ENABLE_OBSTACLE_DETOUR_SHORTCUTS = false
  ENABLE_ROUTED_TRACE_DETOURS = false
  PRESERVE_ROUTE_ENDPOINTS = false

  geometryShortcutsApplied = 0
  multilayerSectionsCollapsed = 0
  obstacleDetourCandidatesValidated = 0

  constructor(params: {
    obstacleSHI: ObstacleSpatialHashIndex
    hdRouteSHI: HighDensityRouteSpatialIndex
    unsimplifiedRoute: HighDensityRoute
    connMap: ConnectivityMap
    outline?: Array<{ x: number; y: number }>
    geometryShortcutTraceMargin?: number
    geometryShortcutObstacleMargin?: number
    enableGeometryShortcuts?: boolean
    enableObstacleDetourShortcuts?: boolean
    enableRoutedTraceDetours?: boolean
    preserveRouteEndpoints?: boolean
    terminalLayerIndicesByPcbPortId?: ReadonlyMap<string, ReadonlySet<number>>
  }) {
    super()
    this.currentSectionIndex = 0 // Start at 0 to check first section for MLCP via removal
    this.obstacleSHI = params.obstacleSHI
    this.hdRouteSHI = params.hdRouteSHI
    this.unsimplifiedRoute = params.unsimplifiedRoute
    this.connMap = params.connMap
    this.outline = params.outline
    this.terminalLayerIndicesByPcbPortId =
      params.terminalLayerIndicesByPcbPortId
    this.GEOMETRY_SHORTCUT_TRACE_MARGIN =
      params.geometryShortcutTraceMargin ?? this.GEOMETRY_SHORTCUT_TRACE_MARGIN
    this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN =
      params.geometryShortcutObstacleMargin ??
      this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN
    this.ENABLE_GEOMETRY_SHORTCUTS = params.enableGeometryShortcuts ?? true
    this.ENABLE_OBSTACLE_DETOUR_SHORTCUTS =
      params.enableObstacleDetourShortcuts ?? false
    this.ENABLE_ROUTED_TRACE_DETOURS = params.enableRoutedTraceDetours ?? false
    this.PRESERVE_ROUTE_ENDPOINTS = params.preserveRouteEndpoints ?? false

    this.routeSections = breakRouteIntoSections(this.unsimplifiedRoute)
  }

  private getPathLength(points: RoutePoint[]): number {
    let length = 0
    for (let index = 1; index < points.length; index++) {
      length += getVectorLength(
        points[index].x - points[index - 1].x,
        points[index].y - points[index - 1].y,
      )
    }
    return length
  }

  private normalizeShortcutPath(
    path: Array<{ x: number; y: number }>,
    start: RoutePoint,
    end: RoutePoint,
  ): RoutePoint[] {
    const uniquePoints = path.filter((point, index) => {
      const previousPoint = path[index - 1]
      return (
        !previousPoint ||
        point.x !== previousPoint.x ||
        point.y !== previousPoint.y
      )
    })

    return uniquePoints.map((point, index): RoutePoint => {
      if (index === 0) return { ...start }
      if (index === uniquePoints.length - 1) return { ...end }
      return { x: point.x, y: point.y, z: start.z }
    })
  }

  private shortcutCrossesOutline(path: RoutePoint[]): boolean {
    if (!this.outline || this.outline.length < 3) return false

    for (let index = 1; index < path.length; index++) {
      if (
        doesSegmentCrossPolygonBoundary({
          start: path[index - 1],
          end: path[index],
          polygon: this.outline,
        })
      ) {
        return true
      }
    }
    return false
  }

  private isRouteOnSameNet(route: HighDensityRoute): boolean {
    const cached = this.sameNetRouteCache.get(route)
    if (cached !== undefined) return cached
    const routeIds = [
      this.unsimplifiedRoute.connectionName,
      this.unsimplifiedRoute.rootConnectionName,
    ].filter((id): id is string => id !== undefined)
    const otherIds = [route.connectionName, route.rootConnectionName].filter(
      (id): id is string => id !== undefined,
    )
    const isSameNet = routeIds.some((id) =>
      otherIds.some(
        (other) => id === other || this.connMap.areIdsConnected(id, other),
      ),
    )
    this.sameNetRouteCache.set(route, isSameNet)
    return isSameNet
  }

  private getObstacleDetourContext(
    start: RoutePoint,
    end: RoutePoint,
    targetZ: number,
  ): ObstacleDetourContext {
    const cached = this.ENABLE_ROUTED_TRACE_DETOURS
      ? this.detourContexts.get(start)?.get(end)
      : undefined
    if (cached?.targetZ === targetZ) return cached
    const traceThickness =
      this.unsimplifiedRoute.traceThickness ?? this.TRACE_THICKNESS
    const corridorMargin =
      traceThickness / 2 + this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN + 1e-6
    const searchExpansion =
      this.MAX_GEOMETRY_SHORTCUT_ADDED_LENGTH / 2 + corridorMargin
    const minX = Math.min(start.x, end.x) - searchExpansion
    const maxX = Math.max(start.x, end.x) + searchExpansion
    const minY = Math.min(start.y, end.y) - searchExpansion
    const maxY = Math.max(start.y, end.y) + searchExpansion
    const obstacles = this.obstacleSHI
      .search({ minX, minY, maxX, maxY })
      .filter((obstacle) => obstacle.__zLayers?.includes(targetZ))
    const blockingRoutes = this.ENABLE_ROUTED_TRACE_DETOURS
      ? this.hdRouteSHI.getConflictingRoutesForSegment(
          { ...start, z: targetZ },
          { ...end, z: targetZ },
          traceThickness / 2 + this.GEOMETRY_SHORTCUT_TRACE_MARGIN,
          (route): boolean => this.isRouteOnSameNet(route),
        )
      : []

    const traceCorners: Array<{ x: number; y: number }> = []
    const corridorXs = new Set<number>()
    const corridorYs = new Set<number>()
    for (const obstacle of obstacles) {
      corridorXs.add(obstacle.center.x - obstacle.width / 2 - corridorMargin)
      corridorXs.add(obstacle.center.x + obstacle.width / 2 + corridorMargin)
      corridorYs.add(obstacle.center.y - obstacle.height / 2 - corridorMargin)
      corridorYs.add(obstacle.center.y + obstacle.height / 2 + corridorMargin)
    }

    // Routed copper can block the direct same-layer shortcut even when no
    // pad blocks it. Try the copper's clearance boundaries as detour corridors.
    // Keep the search local and validate these candidates with the same index
    // and outline checks as obstacle detours.
    for (const { conflictingRoute } of blockingRoutes) {
      const points = conflictingRoute.route.filter(
        (point) =>
          point.z === targetZ &&
          point.x >= minX &&
          point.x <= maxX &&
          point.y >= minY &&
          point.y <= maxY,
      )
      if (points.length === 0) continue
      const margin =
        traceThickness / 2 +
        Math.max(
          conflictingRoute.traceThickness / 2,
          conflictingRoute.viaDiameter / 2,
        ) +
        this.GEOMETRY_SHORTCUT_TRACE_MARGIN +
        1e-6
      corridorXs.add(Math.min(...points.map((point) => point.x)) - margin)
      corridorXs.add(Math.max(...points.map((point) => point.x)) + margin)
      corridorYs.add(Math.min(...points.map((point) => point.y)) - margin)
      corridorYs.add(Math.max(...points.map((point) => point.y)) + margin)
      {
        const x1 = Math.min(...points.map((point) => point.x)) - margin
        const x2 = Math.max(...points.map((point) => point.x)) + margin
        const y1 = Math.min(...points.map((point) => point.y)) - margin
        const y2 = Math.max(...points.map((point) => point.y)) + margin
        traceCorners.push(
          { x: x1, y: y1 },
          { x: x1, y: y2 },
          { x: x2, y: y1 },
          { x: x2, y: y2 },
        )
      }
    }

    const context = { targetZ, traceCorners, corridorXs, corridorYs }
    if (this.ENABLE_ROUTED_TRACE_DETOURS) {
      const endContexts = this.detourContexts.get(start) ?? new WeakMap()
      endContexts.set(end, context)
      this.detourContexts.set(start, endContexts)
    }
    return context
  }

  private getObstacleDetourPaths(
    start: RoutePoint,
    end: RoutePoint,
    targetZ: number,
    maxPathLength: number,
    traceCornersOnly = false,
    validateLongestSegment?: ReturnType<
      typeof createObstacleDetourPathValidator
    >,
  ): ObstacleDetourPath[] {
    const { traceCorners, corridorXs, corridorYs } =
      this.getObstacleDetourContext(start, end, targetZ)
    const paths: ObstacleDetourPath[] = []
    const pathKeys = new Set<string>()
    const addPath = (points: Array<{ x: number; y: number }>) => {
      let pathLength = 0
      for (let index = 1; index < points.length; index++) {
        pathLength += getVectorLength(
          points[index].x - points[index - 1].x,
          points[index].y - points[index - 1].y,
        )
      }
      if (pathLength > maxPathLength) return

      if (validateLongestSegment) {
        let longestIndex = 0
        let longestLengthSquared = -1
        for (let index = 0; index < points.length - 1; index++) {
          const dx = points[index + 1].x - points[index].x
          const dy = points[index + 1].y - points[index].y
          const lengthSquared = dx * dx + dy * dy
          if (lengthSquared > longestLengthSquared) {
            longestIndex = index
            longestLengthSquared = lengthSquared
          }
        }
        if (
          !validateLongestSegment(
            [
              { ...points[longestIndex], z: start.z },
              { ...points[longestIndex + 1], z: start.z },
            ],
            0,
          )
        )
          return
      }
      const path = this.normalizeShortcutPath(points, start, end)
      let longestSegmentIndex = 0
      let longestSegmentLengthSquared = -1
      for (let index = 0; index < path.length - 1; index++) {
        const dx = path[index + 1].x - path[index].x
        const dy = path[index + 1].y - path[index].y
        const lengthSquared = dx * dx + dy * dy
        if (lengthSquared > longestSegmentLengthSquared) {
          longestSegmentIndex = index
          longestSegmentLengthSquared = lengthSquared
        }
      }
      const key = path.map((point) => `${point.x}:${point.y}`).join("|")
      if (pathKeys.has(key)) return
      pathKeys.add(key)
      paths.push({ path, length: pathLength, longestSegmentIndex })
    }
    if (traceCornersOnly) {
      for (const corner of traceCorners) {
        for (const firstPath of calculate45DegreePaths(start, corner)) {
          for (const secondPath of calculate45DegreePaths(corner, end)) {
            addPath([...firstPath, ...secondPath.slice(1)])
          }
        }
      }
      return paths
    }
    for (const corridorY of corridorYs) {
      addPath([
        start,
        { x: start.x, y: corridorY },
        { x: end.x, y: corridorY },
        end,
      ])
    }
    for (const corridorX of corridorXs) {
      addPath([
        start,
        { x: corridorX, y: start.y },
        { x: corridorX, y: end.y },
        end,
      ])
    }
    return paths
  }

  private getDirectGeometryShortcut(
    previousSection: RouteSection,
    currentSection: RouteSection,
    nextSection: RouteSection,
  ): ViaPairShortcut | null {
    let bestShortcut: ViaPairShortcut | null = null
    const validatePath = createObstacleDetourPathValidator({
      targetZ: previousSection.z,
      route: this.unsimplifiedRoute,
      hdRouteSHI: this.hdRouteSHI,
      obstacleSHI: this.obstacleSHI,
      connMap: this.connMap,
      defaultTraceThickness: this.TRACE_THICKNESS,
      obstacleMargin: this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN,
      traceMargin: this.GEOMETRY_SHORTCUT_TRACE_MARGIN,
      useNumericSegmentKeys: true,
    })
    for (
      let previousPointIndex = 0;
      previousPointIndex < previousSection.points.length;
      previousPointIndex++
    ) {
      const start = previousSection.points[previousPointIndex]
      for (
        let nextPointIndex = 0;
        nextPointIndex < nextSection.points.length;
        nextPointIndex++
      ) {
        const end = nextSection.points[nextPointIndex]
        const replacedPoints = [
          ...previousSection.points.slice(previousPointIndex),
          ...currentSection.points,
          ...nextSection.points.slice(0, nextPointIndex + 1),
        ]
        if (
          replacedPoints.some(
            (point) => point.insideJumperPad || point.toNextSegmentType,
          )
        ) {
          continue
        }

        for (const possiblePath of calculate45DegreePaths(start, end)) {
          const path = this.normalizeShortcutPath(possiblePath, start, end)
          const savedLength =
            this.getPathLength(replacedPoints) - this.getPathLength(path)
          if (savedLength < -1e-6) continue

          const pathIsClear = validatePath(path, 0)
          if (!pathIsClear || this.shortcutCrossesOutline(path)) continue

          if (!bestShortcut || savedLength > bestShortcut.savedLength) {
            bestShortcut = {
              path,
              previousPointIndex,
              nextPointIndex,
              savedLength,
            }
          }
        }
      }
    }
    return bestShortcut
  }

  private getObstacleDetourShortcut(
    previousSection: RouteSection,
    currentSection: RouteSection,
    nextSection: RouteSection,
    traceCornersOnly = false,
  ): ViaPairShortcut | null {
    const transitionIndex = previousSection.points.length - 1
    const anchorPairs: Array<[number, number]> = []
    // Keep one anchor at a layer transition so candidate growth is P + N,
    // rather than the quadratic P * N direct-shortcut search above.
    for (
      let previousIndex = 0;
      previousIndex <= transitionIndex;
      previousIndex++
    ) {
      anchorPairs.push([previousIndex, 0])
    }
    for (
      let nextIndex = 1;
      nextIndex < nextSection.points.length;
      nextIndex++
    ) {
      anchorPairs.push([transitionIndex, nextIndex])
    }

    const earlyValidator = this.ENABLE_ROUTED_TRACE_DETOURS
      ? createObstacleDetourPathValidator({
          targetZ: previousSection.z,
          route: this.unsimplifiedRoute,
          hdRouteSHI: this.hdRouteSHI,
          obstacleSHI: this.obstacleSHI,
          connMap: this.connMap,
          defaultTraceThickness: this.TRACE_THICKNESS,
          obstacleMargin: this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN,
          traceMargin: this.GEOMETRY_SHORTCUT_TRACE_MARGIN,
          useNumericSegmentKeys: true,
        })
      : undefined
    const candidateShortcuts: ViaPairShortcut[] = []
    for (const [previousPointIndex, nextPointIndex] of anchorPairs) {
      const start = previousSection.points[previousPointIndex]
      const end = nextSection.points[nextPointIndex]
      const replacedPoints = [
        ...previousSection.points.slice(previousPointIndex),
        ...currentSection.points,
        ...nextSection.points.slice(0, nextPointIndex + 1),
      ]
      if (
        replacedPoints.some(
          (point) => point.insideJumperPad || point.toNextSegmentType,
        )
      ) {
        continue
      }
      const replacedLength = this.getPathLength(replacedPoints)

      for (const {
        path,
        length: pathLength,
        longestSegmentIndex,
      } of this.getObstacleDetourPaths(
        start,
        end,
        previousSection.z,
        replacedLength + this.MAX_GEOMETRY_SHORTCUT_ADDED_LENGTH + 1e-6,
        traceCornersOnly,
        earlyValidator,
      )) {
        const savedLength = replacedLength - pathLength
        if (savedLength < -this.MAX_GEOMETRY_SHORTCUT_ADDED_LENGTH - 1e-6) {
          continue
        }

        candidateShortcuts.push({
          path,
          previousPointIndex,
          nextPointIndex,
          savedLength,
          validationFirstSegmentIndex: longestSegmentIndex,
        })
      }
    }
    // Rank cheap geometry first so the first fully valid path is the same
    // maximum-saved-length shortcut as the exhaustive scan.
    candidateShortcuts.sort((a, b) => b.savedLength - a.savedLength)

    let candidatesValidated = 0
    // String keys are faster to initialize for small searches. Large exhaustive
    // searches switch to numeric IDs to avoid rebuilding coordinate strings for
    // thousands of candidates that repeatedly share corridor segments.
    const shouldUseNumericSegmentKeys = candidateShortcuts.length >= 256
    const validateObstacleDetourPath =
      earlyValidator ??
      createObstacleDetourPathValidator({
        targetZ: previousSection.z,
        route: this.unsimplifiedRoute,
        hdRouteSHI: this.hdRouteSHI,
        obstacleSHI: this.obstacleSHI,
        connMap: this.connMap,
        defaultTraceThickness: this.TRACE_THICKNESS,
        obstacleMargin: this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN,
        traceMargin: this.GEOMETRY_SHORTCUT_TRACE_MARGIN,
        useNumericSegmentKeys: shouldUseNumericSegmentKeys,
      })
    for (const shortcut of candidateShortcuts) {
      candidatesValidated++
      const { path } = shortcut
      const pathIsClear = validateObstacleDetourPath(
        path,
        shortcut.validationFirstSegmentIndex ?? 0,
      )
      if (!pathIsClear) continue
      // Most candidates collide. Only run the comparatively expensive polygon
      // boundary scan for candidates that pass the spatial-index checks.
      if (this.shortcutCrossesOutline(path)) continue

      this.obstacleDetourCandidatesValidated += candidatesValidated
      this.stats.obstacleDetourCandidatesValidated =
        this.obstacleDetourCandidatesValidated
      return shortcut
    }
    this.obstacleDetourCandidatesValidated += candidatesValidated
    this.stats.obstacleDetourCandidatesValidated =
      this.obstacleDetourCandidatesValidated
    return null
  }

  private findGeometryShortcut(
    previousSection: RouteSection,
    currentSection: RouteSection,
    nextSection: RouteSection,
  ): ViaPairShortcut | null {
    // Corridor and corner searches share unchanged geometry for this section.
    // Discard it before the next section, whose route/index may have changed.
    this.detourContexts = new WeakMap()
    if (this.unsimplifiedRoute.jumpers?.length) return null

    if (this.ENABLE_GEOMETRY_SHORTCUTS) {
      const directShortcut = this.getDirectGeometryShortcut(
        previousSection,
        currentSection,
        nextSection,
      )
      if (directShortcut) return directShortcut
    }
    if (!this.ENABLE_OBSTACLE_DETOUR_SHORTCUTS) return null
    const corridorShortcut = this.getObstacleDetourShortcut(
      previousSection,
      currentSection,
      nextSection,
    )
    if (corridorShortcut || !this.ENABLE_ROUTED_TRACE_DETOURS) {
      return corridorShortcut
    }
    // Generate the extra corner paths only after cheaper corridors fail.
    return this.getObstacleDetourShortcut(
      previousSection,
      currentSection,
      nextSection,
      true,
    )
  }

  private applyGeometryShortcut(shortcut: ViaPairShortcut): void {
    const previousSection = this.routeSections[this.currentSectionIndex - 1]
    const nextSection = this.routeSections[this.currentSectionIndex + 1]
    const combinedPoints = [
      ...previousSection.points.slice(0, shortcut.previousPointIndex),
      ...shortcut.path,
      ...nextSection.points.slice(shortcut.nextPointIndex + 1),
    ].filter((point, index, points) => {
      const previousPoint = points[index - 1]
      return (
        !previousPoint ||
        point.x !== previousPoint.x ||
        point.y !== previousPoint.y ||
        point.z !== previousPoint.z
      )
    })

    this.routeSections.splice(this.currentSectionIndex - 1, 3, {
      startIndex: previousSection.startIndex,
      endIndex: nextSection.endIndex,
      z: previousSection.z,
      points: combinedPoints,
    })
    this.geometryShortcutsApplied++
    this.stats.geometryShortcutsApplied = this.geometryShortcutsApplied
    this.stats.viasRemovedByGeometryShortcuts =
      this.geometryShortcutsApplied * 2
    this.currentSectionIndex = Math.max(0, this.currentSectionIndex - 1)
  }

  private findMultilayerSectionCollapse(
    previousSection: RouteSection,
    currentSection: RouteSection,
    nextSection: RouteSection,
  ): MultilayerSectionCollapse | null {
    if (
      previousSection.z === nextSection.z ||
      this.unsimplifiedRoute.jumpers?.length
    ) {
      return null
    }

    const previousTransitionPoint =
      previousSection.points[previousSection.points.length - 1]
    if (
      previousTransitionPoint?.insideJumperPad ||
      previousTransitionPoint?.toNextSegmentType ||
      currentSection.points.some(
        (point) => point.insideJumperPad || point.toNextSegmentType,
      )
    ) {
      return null
    }

    const candidates: MultilayerSectionCollapse[] = [
      { targetZ: previousSection.z, mergeWith: "previous" },
      { targetZ: nextSection.z, mergeWith: "next" },
    ]
    for (const candidate of candidates) {
      if (
        candidate.targetZ !== currentSection.z &&
        canSectionMoveToLayer({
          currentSection,
          targetZ: candidate.targetZ,
          route: this.unsimplifiedRoute,
          hdRouteSHI: this.hdRouteSHI,
          obstacleSHI: this.obstacleSHI,
          connMap: this.connMap,
          defaultTraceThickness: this.TRACE_THICKNESS,
          obstacleMargin: this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN,
          traceMargin: this.GEOMETRY_SHORTCUT_TRACE_MARGIN,
        })
      ) {
        return candidate
      }
    }

    return null
  }

  private applyMultilayerSectionCollapse(
    collapse: MultilayerSectionCollapse,
  ): void {
    const previousSection = this.routeSections[this.currentSectionIndex - 1]
    const currentSection = this.routeSections[this.currentSectionIndex]
    const nextSection = this.routeSections[this.currentSectionIndex + 1]
    const movedPoints = currentSection.points.map((point) => ({
      ...point,
      z: collapse.targetZ,
    }))
    const removeConsecutiveDuplicates = (points: RoutePoint[]) =>
      points.filter((point, index) => {
        const previousPoint = points[index - 1]
        return (
          !previousPoint ||
          point.x !== previousPoint.x ||
          point.y !== previousPoint.y ||
          point.z !== previousPoint.z
        )
      })

    if (collapse.mergeWith === "previous") {
      this.routeSections.splice(this.currentSectionIndex - 1, 2, {
        startIndex: previousSection.startIndex,
        endIndex: currentSection.endIndex,
        z: collapse.targetZ,
        points: removeConsecutiveDuplicates([
          ...previousSection.points,
          ...movedPoints,
        ]),
      })
    } else {
      this.routeSections.splice(this.currentSectionIndex, 2, {
        startIndex: currentSection.startIndex,
        endIndex: nextSection.endIndex,
        z: collapse.targetZ,
        points: removeConsecutiveDuplicates([
          ...movedPoints,
          ...nextSection.points,
        ]),
      })
    }

    this.multilayerSectionsCollapsed++
    this.stats.multilayerSectionsCollapsed = this.multilayerSectionsCollapsed
    this.stats.viasRemovedByMultilayerSectionCollapses =
      this.multilayerSectionsCollapsed
    this.currentSectionIndex = Math.max(0, this.currentSectionIndex - 1)
  }

  _step() {
    if (this.currentSectionIndex >= this.routeSections.length) {
      this.solved = true
      return
    }

    // Handle first section (endpoint 1) - can be moved if it's a multi-layer connection point
    if (this.currentSectionIndex === 0 && this.routeSections.length > 1) {
      const firstSection = this.routeSections[0]
      const secondSection = this.routeSections[1]

      if (
        !this.PRESERVE_ROUTE_ENDPOINTS &&
        firstSection.z !== secondSection.z
      ) {
        // Try moving first section to match second section (for MLCP endpoints)
        const targetZ = secondSection.z
        // Check that the endpoint obstacle supports the target layer
        const firstPoint = firstSection.points[0]
        const endpointSupportsLayer = canEndpointConnectOnLayer({
          endpointX: firstPoint.x,
          endpointY: firstPoint.y,
          targetZ,
          endpointPcbPortId: this.unsimplifiedRoute.startPcbPortId,
          terminalLayerIndicesByPcbPortId: this.terminalLayerIndicesByPcbPortId,
          obstacleSHI: this.obstacleSHI,
          route: this.unsimplifiedRoute,
          connMap: this.connMap,
        })
        if (
          endpointSupportsLayer &&
          canSectionMoveToLayer({
            currentSection: firstSection,
            targetZ,
            route: this.unsimplifiedRoute,
            hdRouteSHI: this.hdRouteSHI,
            obstacleSHI: this.obstacleSHI,
            connMap: this.connMap,
            defaultTraceThickness: this.TRACE_THICKNESS,
            obstacleMargin: this.OBSTACLE_MARGIN,
          })
        ) {
          firstSection.z = targetZ
          firstSection.points = firstSection.points.map((p) => ({
            ...p,
            z: targetZ,
          }))
          this.currentSectionIndex = 2 // Skip to after the now-merged sections
          return
        }
      }
      this.currentSectionIndex++
      return
    }

    // Handle last section (endpoint 2) - can be moved if it's a multi-layer connection point
    if (this.currentSectionIndex === this.routeSections.length - 1) {
      // Only attempt via removal if there are at least 2 sections
      if (!this.PRESERVE_ROUTE_ENDPOINTS && this.routeSections.length >= 2) {
        const lastSection = this.routeSections[this.routeSections.length - 1]
        const secondLastSection =
          this.routeSections[this.routeSections.length - 2]

        if (lastSection.z !== secondLastSection.z) {
          // Try moving last section to match second-last section (for MLCP endpoints)
          const targetZ = secondLastSection.z
          // Check that the endpoint obstacle supports the target layer
          const lastPoint = lastSection.points[lastSection.points.length - 1]
          const endpointSupportsLayer = canEndpointConnectOnLayer({
            endpointX: lastPoint.x,
            endpointY: lastPoint.y,
            targetZ,
            endpointPcbPortId: this.unsimplifiedRoute.endPcbPortId,
            terminalLayerIndicesByPcbPortId:
              this.terminalLayerIndicesByPcbPortId,
            obstacleSHI: this.obstacleSHI,
            route: this.unsimplifiedRoute,
            connMap: this.connMap,
          })
          if (
            endpointSupportsLayer &&
            canSectionMoveToLayer({
              currentSection: lastSection,
              targetZ,
              route: this.unsimplifiedRoute,
              hdRouteSHI: this.hdRouteSHI,
              obstacleSHI: this.obstacleSHI,
              connMap: this.connMap,
              defaultTraceThickness: this.TRACE_THICKNESS,
              obstacleMargin: this.OBSTACLE_MARGIN,
            })
          ) {
            lastSection.z = targetZ
            lastSection.points = lastSection.points.map((p) => ({
              ...p,
              z: targetZ,
            }))
          }
        }
      }
      this.solved = true
      return
    }

    // Handle middle sections (original logic)
    const prevSection = this.routeSections[this.currentSectionIndex - 1]
    const currentSection = this.routeSections[this.currentSectionIndex]
    const nextSection = this.routeSections[this.currentSectionIndex + 1]

    if (prevSection.z !== nextSection.z) {
      const multilayerCollapse = this.findMultilayerSectionCollapse(
        prevSection,
        currentSection,
        nextSection,
      )
      if (multilayerCollapse) {
        this.applyMultilayerSectionCollapse(multilayerCollapse)
        return
      }

      this.currentSectionIndex++
      return
    }

    const targetZ = prevSection.z

    if (
      canSectionMoveToLayer({
        currentSection,
        targetZ,
        route: this.unsimplifiedRoute,
        hdRouteSHI: this.hdRouteSHI,
        obstacleSHI: this.obstacleSHI,
        connMap: this.connMap,
        defaultTraceThickness: this.TRACE_THICKNESS,
        obstacleMargin: this.OBSTACLE_MARGIN,
      })
    ) {
      currentSection.z = targetZ
      currentSection.points = currentSection.points.map((p) => ({
        ...p,
        z: targetZ,
      }))
      this.currentSectionIndex += 2
      return
    }

    const geometryShortcut = this.findGeometryShortcut(
      prevSection,
      currentSection,
      nextSection,
    )
    if (geometryShortcut) {
      this.applyGeometryShortcut(geometryShortcut)
      return
    }

    this.currentSectionIndex++
    return
  }

  getConstructorParams() {
    return {
      obstacleSHI: this.obstacleSHI,
      hdRouteSHI: this.hdRouteSHI,
      unsimplifiedRoute: this.unsimplifiedRoute,
      connMap: this.connMap,
      outline: this.outline,
      geometryShortcutTraceMargin: this.GEOMETRY_SHORTCUT_TRACE_MARGIN,
      geometryShortcutObstacleMargin: this.GEOMETRY_SHORTCUT_OBSTACLE_MARGIN,
      enableGeometryShortcuts: this.ENABLE_GEOMETRY_SHORTCUTS,
      enableObstacleDetourShortcuts: this.ENABLE_OBSTACLE_DETOUR_SHORTCUTS,
      enableRoutedTraceDetours: this.ENABLE_ROUTED_TRACE_DETOURS,
      preserveRouteEndpoints: this.PRESERVE_ROUTE_ENDPOINTS,
      terminalLayerIndicesByPcbPortId: this.terminalLayerIndicesByPcbPortId,
    }
  }

  getOptimizedHdRoute(): HighDensityRoute {
    // TODO reconstruct the route from segments, we will need to recompute the
    // vias
    const route = this.routeSections.flatMap((section) => section.points)
    const vias: HighDensityRoute["vias"] = []
    for (let i = 0; i < route.length - 1; i++) {
      if (route[i].z !== route[i + 1].z) {
        vias.push({
          x: route[i].x,
          y: route[i].y,
        })
      }
    }
    return {
      connectionName: this.unsimplifiedRoute.connectionName,
      rootConnectionName: this.unsimplifiedRoute.rootConnectionName,
      startPcbPortId: this.unsimplifiedRoute.startPcbPortId,
      endPcbPortId: this.unsimplifiedRoute.endPcbPortId,
      route,
      traceThickness: this.unsimplifiedRoute.traceThickness,
      vias,
      viaDiameter: this.unsimplifiedRoute.viaDiameter,
      // Preserve jumpers from original route
      jumpers: this.unsimplifiedRoute.jumpers,
    }
  }
  visualize(): GraphicsObject {
    const graphics: GraphicsObject &
      Pick<Required<GraphicsObject>, "points" | "lines" | "rects" | "circles"> =
      {
        circles: [],
        lines: [],
        points: [],
        rects: [],
        coordinateSystem: "cartesian",
        title: "Single Route Useless Via Removal Solver",
      }

    // Draw the sections, draw the active section in orange

    for (let i = 0; i < this.routeSections.length; i++) {
      const section = this.routeSections[i]
      graphics.lines.push({
        points: section.points,
        strokeWidth: this.TRACE_THICKNESS,
        strokeColor:
          i === this.currentSectionIndex
            ? "orange"
            : section.z === 0
              ? "red"
              : "blue",
      })
    }

    return graphics
  }
}
