import type { SerializedHyperGraph } from "@tscircuit/hypergraph"
import { BaseSolver } from "@tscircuit/solver-utils"
import { loadSerializedHyperGraph } from "./compat/loadSerializedHyperGraph"
import {
  TinyHyperGraphSolver,
  type TinyHyperGraphProblem,
  type TinyHyperGraphSolverOptions,
  type TinyHyperGraphTopology,
} from "./core"
import type { PortId, RouteId } from "./types"

type SerializedPort = SerializedHyperGraph["ports"][number]
type SerializedRegion = SerializedHyperGraph["regions"][number]

export const DUPLICATE_PORT_PROXIMITY = 0.05

export interface DuplicateCongestedPortSolverOptions {
  duplicatePortProximity?: number
  routeSolveOptions?: TinyHyperGraphSolverOptions
  /** Ignore serialized port penalties while estimating shared-port use. */
  useSerializedPortPenalties?: boolean
}

export interface DuplicatedPortSummary {
  sourcePortId: string
  duplicatePortIds: string[]
  useCount: number
}

export interface DuplicateCongestedPortSolverReport {
  portUseCounts: Record<string, number>
  duplicatedPorts: DuplicatedPortSummary[]
}

interface Point {
  x: number
  y: number
}

const EPSILON = 1e-9
// The shared-face port producer accepts this much CAD boundary rounding.
const SHARED_FACE_EPSILON = 0.0001

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === "object" && value !== null

const cloneSerializableValue = <T>(value: T): T => {
  if (Array.isArray(value)) {
    return value.map((item) => cloneSerializableValue(item)) as T
  }

  if (isRecord(value)) {
    return Object.fromEntries(
      Object.entries(value).map(([key, item]) => [
        key,
        cloneSerializableValue(item),
      ]),
    ) as T
  }

  return value
}

const toObjectRecord = (value: unknown): Record<string, unknown> => {
  if (isRecord(value)) return { ...value }
  if (value === undefined) return {}
  return { value }
}

const getNumber = (value: unknown, fallback = 0) =>
  typeof value === "number" && Number.isFinite(value) ? value : fallback

const getPortPoint = (port: SerializedPort): Point => ({
  x: getNumber(port.d?.x),
  y: getNumber(port.d?.y),
})

const getBoundaryKey = (
  port: Pick<SerializedPort, "region1Id" | "region2Id">,
) => [port.region1Id, port.region2Id].sort().join("\u0000")

const groupPortsByBoundary = (ports: SerializedPort[]) => {
  const portsByBoundary = new Map<string, SerializedPort[]>()

  for (const port of ports) {
    const boundaryKey = getBoundaryKey(port)
    const boundaryPorts = portsByBoundary.get(boundaryKey)
    if (boundaryPorts) {
      boundaryPorts.push(port)
    } else {
      portsByBoundary.set(boundaryKey, [port])
    }
  }

  return portsByBoundary
}

const getDistance = (a: Point, b: Point) => Math.hypot(a.x - b.x, a.y - b.y)

const normalize = (point: Point): Point | undefined => {
  const length = Math.hypot(point.x, point.y)
  if (length <= EPSILON) return undefined
  return {
    x: point.x / length,
    y: point.y / length,
  }
}

const getRegionBounds = (
  region: SerializedRegion | undefined,
): {
  minX: number
  maxX: number
  minY: number
  maxY: number
} => {
  const bounds = region?.d?.bounds
  if (
    isRecord(bounds) &&
    typeof bounds.minX === "number" &&
    typeof bounds.maxX === "number" &&
    typeof bounds.minY === "number" &&
    typeof bounds.maxY === "number"
  ) {
    return {
      minX: bounds.minX,
      maxX: bounds.maxX,
      minY: bounds.minY,
      maxY: bounds.maxY,
    }
  }

  const center = region?.d?.center
  const width = getNumber(region?.d?.width)
  const height = getNumber(region?.d?.height)
  if (isRecord(center)) {
    const x = getNumber(center.x)
    const y = getNumber(center.y)
    return {
      minX: x - width / 2,
      maxX: x + width / 2,
      minY: y - height / 2,
      maxY: y + height / 2,
    }
  }

  return {
    minX: 0,
    maxX: 0,
    minY: 0,
    maxY: 0,
  }
}

const getRegionCenter = (region: SerializedRegion | undefined): Point => {
  const center = region?.d?.center
  if (isRecord(center)) {
    return {
      x: getNumber(center.x),
      y: getNumber(center.y),
    }
  }

  const bounds = getRegionBounds(region)
  return {
    x: (bounds.minX + bounds.maxX) / 2,
    y: (bounds.minY + bounds.maxY) / 2,
  }
}

const findNearestPortOnSameBoundary = (
  sourcePort: SerializedPort,
  boundaryPorts: SerializedPort[],
): SerializedPort | undefined => {
  const sourcePoint = getPortPoint(sourcePort)
  let nearestPort: SerializedPort | undefined
  let nearestDistance = Number.POSITIVE_INFINITY

  for (const port of boundaryPorts) {
    if (port.portId === sourcePort.portId) continue

    const distance = getDistance(sourcePoint, getPortPoint(port))
    if (distance <= EPSILON || distance >= nearestDistance) continue

    nearestPort = port
    nearestDistance = distance
  }

  return nearestPort
}

const getFallbackBoundaryDirection = (
  sourcePort: SerializedPort,
  regionById: Map<string, SerializedRegion>,
): Point => {
  const region1Center = getRegionCenter(regionById.get(sourcePort.region1Id))
  const region2Center = getRegionCenter(regionById.get(sourcePort.region2Id))
  const perpendicular = normalize({
    x: -(region2Center.y - region1Center.y),
    y: region2Center.x - region1Center.x,
  })

  return perpendicular ?? { x: 1, y: 0 }
}

const getDuplicateDirection = (
  sourcePort: SerializedPort,
  nearestBoundaryPort: SerializedPort | undefined,
  regionById: Map<string, SerializedRegion>,
): Point => {
  const sourcePoint = getPortPoint(sourcePort)

  if (nearestBoundaryPort) {
    const nearestPoint = getPortPoint(nearestBoundaryPort)
    const awayFromNearest = normalize({
      x: sourcePoint.x - nearestPoint.x,
      y: sourcePoint.y - nearestPoint.y,
    })
    if (awayFromNearest) return awayFromNearest
  }

  return getFallbackBoundaryDirection(sourcePort, regionById)
}

const getDuplicatePlacement = (
  sourcePort: SerializedPort,
  direction: Point,
  proximity: number,
  regionById: Map<string, SerializedRegion>,
): { direction: Point; proximity: number } => {
  const a = getRegionBounds(regionById.get(sourcePort.region1Id))
  const b = getRegionBounds(regionById.get(sourcePort.region2Id))
  const minX = Math.max(a.minX, b.minX), maxX = Math.min(a.maxX, b.maxX)
  const minY = Math.max(a.minY, b.minY), maxY = Math.min(a.maxY, b.maxY)
  const point = getPortPoint(sourcePort)
  const xRange = maxX - minX, yRange = maxY - minY
  const vertical = xRange < yRange && Math.abs(xRange) <= SHARED_FACE_EPSILON &&
    yRange > EPSILON && Math.abs(point.x - (minX + maxX) / 2) <= SHARED_FACE_EPSILON &&
    point.y >= minY - EPSILON && point.y <= maxY + EPSILON
  const horizontal = !vertical && Math.abs(yRange) <= SHARED_FACE_EPSILON &&
    xRange > EPSILON && Math.abs(point.y - (minY + maxY) / 2) <= SHARED_FACE_EPSILON &&
    point.x >= minX - EPSILON && point.x <= maxX + EPSILON
  if (!vertical && !horizontal) return { direction, proximity }

  // Duplicates must stay on the actual shared face, including unequal cells
  // whose center-to-center perpendicular is not tangent to that face.
  const low = vertical ? minY : minX, high = vertical ? maxY : maxX
  const coordinate = vertical ? point.y : point.x
  let sign = (vertical ? direction.y : direction.x) < 0 ? -1 : 1
  let available = sign > 0 ? high - coordinate : coordinate - low
  if (available <= EPSILON) {
    sign = -sign
    available = sign > 0 ? high - coordinate : coordinate - low
  }
  return {
    direction: vertical ? { x: 0, y: sign } : { x: sign, y: 0 },
    proximity: Math.min(proximity, Math.max(0, available)),
  }
}

const createDuplicatePortId = (
  sourcePortId: string,
  duplicateIndex: number,
  usedPortIds: Set<string>,
): string => {
  const basePortId = `${sourcePortId}::dup${duplicateIndex}`
  if (!usedPortIds.has(basePortId)) {
    usedPortIds.add(basePortId)
    return basePortId
  }

  for (let collisionIndex = 2; ; collisionIndex++) {
    const portId = `${basePortId}-${collisionIndex}`
    if (!usedPortIds.has(portId)) {
      usedPortIds.add(portId)
      return portId
    }
  }
}

const insertDuplicatePortIdsAfterSource = (
  pointIds: string[],
  sourcePortId: string,
  duplicatePortIds: string[],
) => {
  const insertionIndex = pointIds.indexOf(sourcePortId)
  if (insertionIndex === -1) {
    pointIds.push(...duplicatePortIds)
    return
  }

  pointIds.splice(insertionIndex + 1, 0, ...duplicatePortIds)
}

const getSerializedPortId = (
  topology: TinyHyperGraphTopology,
  portId: PortId,
): string => {
  const metadata = topology.portMetadata?.[portId]
  if (isRecord(metadata)) {
    if (typeof metadata.serializedPortId === "string") {
      return metadata.serializedPortId
    }

    if (typeof metadata.portId === "string") {
      return metadata.portId
    }
  }

  return `port-${portId}`
}

const createSingleRouteProblem = (
  problem: TinyHyperGraphProblem,
  routeId: RouteId,
): TinyHyperGraphProblem => ({
  routeCount: 1,
  portSectionMask: problem.portSectionMask,
  routeMetadata:
    problem.routeMetadata === undefined
      ? undefined
      : [problem.routeMetadata[routeId]],
  routeStartPort: Int32Array.from([problem.routeStartPort[routeId]]),
  routeEndPort: Int32Array.from([problem.routeEndPort[routeId]]),
  routeNet: Int32Array.from([problem.routeNet[routeId]]),
  regionNetId: problem.regionNetId,
  portPenalty: problem.portPenalty,
})

const getUsedPortIdsForSolvedRoute = (
  solver: TinyHyperGraphSolver,
): Set<PortId> => {
  const usedPortIds = new Set<PortId>()

  for (const regionSegments of solver.state.regionSegments) {
    for (const [, fromPortId, toPortId] of regionSegments) {
      usedPortIds.add(fromPortId)
      usedPortIds.add(toPortId)
    }
  }

  if (usedPortIds.size === 0 && solver.problem.routeCount === 1) {
    usedPortIds.add(solver.problem.routeStartPort[0])
    usedPortIds.add(solver.problem.routeEndPort[0])
  }

  return usedPortIds
}

export class DuplicateCongestedPortSolver extends BaseSolver {
  revisedSerializedHyperGraph?: SerializedHyperGraph
  report: DuplicateCongestedPortSolverReport = {
    portUseCounts: {},
    duplicatedPorts: [],
  }

  constructor(
    public serializedHyperGraph: SerializedHyperGraph,
    public options: DuplicateCongestedPortSolverOptions = {},
  ) {
    super()
  }

  private getDuplicatePortProximity() {
    return this.options.duplicatePortProximity ?? DUPLICATE_PORT_PROXIMITY
  }

  private getIndividualRouteSolveOptions(): TinyHyperGraphSolverOptions {
    return {
      RIP_THRESHOLD_RAMP_ATTEMPTS: 0,
      STATIC_REACHABILITY_PRECHECK: false,
      ...this.options.routeSolveOptions,
    }
  }

  private getPortUseCounts(): Map<string, number> {
    const { topology, problem } = loadSerializedHyperGraph(
      this.serializedHyperGraph,
    )
    if (this.options.useSerializedPortPenalties === false) {
      problem.portPenalty = undefined
    }
    const portUseCounts = new Map<string, number>()
    let routeSolver: TinyHyperGraphSolver | undefined

    for (let routeId = 0; routeId < problem.routeCount; routeId++) {
      const routeProblem = createSingleRouteProblem(problem, routeId)
      if (routeSolver) {
        routeSolver.resetForProblem(routeProblem)
      } else {
        routeSolver = new TinyHyperGraphSolver(
          topology,
          routeProblem,
          this.getIndividualRouteSolveOptions(),
        )
      }
      routeSolver.solve()

      if (!routeSolver.solved || routeSolver.failed) {
        throw new Error(
          `Route ${routeId} could not be solved independently: ${
            routeSolver.error ?? "unknown error"
          }`,
        )
      }

      for (const portId of getUsedPortIdsForSolvedRoute(routeSolver)) {
        const serializedPortId = getSerializedPortId(topology, portId)
        portUseCounts.set(
          serializedPortId,
          (portUseCounts.get(serializedPortId) ?? 0) + 1,
        )
      }
    }

    return portUseCounts
  }

  protected duplicateCongestedPorts(
    portUseCounts: Map<string, number>,
  ): SerializedHyperGraph {
    const duplicatePortProximity = this.getDuplicatePortProximity()
    if (!(duplicatePortProximity > 0)) {
      throw new Error("duplicatePortProximity must be greater than zero")
    }

    const { solvedRoutes: _solvedRoutes, ...restHyperGraph } =
      this.serializedHyperGraph
    const regions: SerializedRegion[] = this.serializedHyperGraph.regions.map(
      (region) => ({
        ...region,
        pointIds: [...region.pointIds],
        d: cloneSerializableValue(region.d),
      }),
    )
    const ports: SerializedPort[] = this.serializedHyperGraph.ports.map(
      (port) => ({
        ...port,
        d: cloneSerializableValue(port.d),
      }),
    )
    const regionById = new Map(
      regions.map((region) => [region.regionId, region]),
    )
    const sourcePortById = new Map(
      ports.map((port) => [port.portId, port] as const),
    )
    const portsByBoundary = groupPortsByBoundary(
      this.serializedHyperGraph.ports,
    )
    const usedPortIds = new Set(ports.map((port) => port.portId))
    const duplicatedPorts: DuplicatedPortSummary[] = []

    for (const [sourcePortId, useCount] of [...portUseCounts.entries()].sort(
      ([leftPortId], [rightPortId]) => leftPortId.localeCompare(rightPortId),
    )) {
      if (useCount <= 1) continue

      const sourcePort = sourcePortById.get(sourcePortId)
      if (!sourcePort) continue

      const duplicateCount = useCount - 1
      const boundaryPorts = portsByBoundary.get(getBoundaryKey(sourcePort))
      if (!boundaryPorts) {
        throw new Error(`No boundary ports found for "${sourcePortId}"`)
      }
      const nearestBoundaryPort = findNearestPortOnSameBoundary(
        sourcePort,
        boundaryPorts,
      )
      const duplicateDirection = getDuplicateDirection(
        sourcePort,
        nearestBoundaryPort,
        regionById,
      )
      const placement = getDuplicatePlacement(sourcePort, duplicateDirection, duplicatePortProximity, regionById)
      const sourcePoint = getPortPoint(sourcePort)
      const duplicatePortIds: string[] = []

      for (
        let duplicateIndex = 1;
        duplicateIndex <= duplicateCount;
        duplicateIndex++
      ) {
        const duplicatePortId = createDuplicatePortId(
          sourcePortId,
          duplicateIndex,
          usedPortIds,
        )
        const offset =
          (placement.proximity * duplicateIndex) / (duplicateCount + 1)
        const duplicatedPortData = toObjectRecord(
          cloneSerializableValue(sourcePort.d),
        )
        duplicatedPortData.x = sourcePoint.x + placement.direction.x * offset
        duplicatedPortData.y = sourcePoint.y + placement.direction.y * offset
        duplicatedPortData.duplicatedFromPortId = sourcePortId
        duplicatedPortData.duplicateIndex = duplicateIndex
        duplicatedPortData.duplicatePortUseCount = useCount
        duplicatedPortData.duplicatePortProximity = duplicatePortProximity
        duplicatedPortData.repairReason = "congested-port"

        ports.push({
          ...sourcePort,
          portId: duplicatePortId,
          d: duplicatedPortData,
        })
        duplicatePortIds.push(duplicatePortId)
      }

      for (const regionId of [sourcePort.region1Id, sourcePort.region2Id]) {
        const region = regionById.get(regionId)
        if (!region) continue
        insertDuplicatePortIdsAfterSource(
          region.pointIds,
          sourcePortId,
          duplicatePortIds,
        )
      }

      duplicatedPorts.push({
        sourcePortId,
        duplicatePortIds,
        useCount,
      })
    }

    this.report = {
      portUseCounts: Object.fromEntries([...portUseCounts.entries()].sort()),
      duplicatedPorts,
    }

    return {
      ...restHyperGraph,
      regions,
      ports,
      connections:
        this.serializedHyperGraph.connections === undefined
          ? undefined
          : cloneSerializableValue(this.serializedHyperGraph.connections),
    }
  }

  override _setup() {
    try {
      const portUseCounts = this.getPortUseCounts()
      this.revisedSerializedHyperGraph =
        this.duplicateCongestedPorts(portUseCounts)
      this.stats = {
        ...this.stats,
        duplicateSourcePortCount: this.report.duplicatedPorts.length,
        duplicatedPortCount: this.report.duplicatedPorts.reduce(
          (sum, duplicatedPort) => sum + duplicatedPort.duplicatePortIds.length,
          0,
        ),
      }
      this.solved = true
    } catch (error) {
      this.failed = true
      this.error = error instanceof Error ? error.message : String(error)
    }
  }

  override _step() {
    if (!this.failed) {
      this.solved = true
    }
  }

  override getOutput(): SerializedHyperGraph {
    if (!this.revisedSerializedHyperGraph || this.failed) {
      throw new Error(
        "DuplicateCongestedPortSolver does not have a repaired topology output",
      )
    }

    return this.revisedSerializedHyperGraph
  }
}
