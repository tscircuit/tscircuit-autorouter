import { BaseSolver } from "@tscircuit/solver-utils"
import { isPortPhysicallyReservedForDifferentNet, validatePortReservations } from "./port-reservations"
import { hasConflictingPortOwner, validatePortConflicts } from "./port-conflicts"
import type { GraphicsObject } from "graphics-debug"
import { convertToSerializedHyperGraph } from "./compat/convertToSerializedHyperGraph"
import {
  computeRegionCost,
  DEFAULT_MIN_VIA_PAD_DIAMETER,
  isKnownSingleLayerMask,
} from "./computeRegionCost"
import {
  type MutableIntersectionCount,
  setNewIntersectionCounts,
} from "./countNewIntersections"
import {
  applyInitialAssignments,
  type TinyHyperGraphInitialAssignment,
} from "./initialAssignments"
import { MinHeap } from "./MinHeap"
import { IndexedCandidateHeap } from "./indexed-candidate-heap"
import { shuffle } from "./shuffle"
import type { StaticallyUnroutableRouteSummary } from "./static-reachability"
import {
  createStaticallyUnroutableRouteSummary,
  getStaticallyUnroutableRoutes,
  getStaticReachabilityError,
} from "./static-reachability"
import type {
  HopId,
  NetId,
  PortId,
  RegionId,
  RegionIntersectionCache,
  RouteId,
} from "./types"
import { range } from "./utils"
import { visualizeTinyGraph } from "./visualizeTinyGraph"

export type { StaticallyUnroutableRouteSummary } from "./static-reachability"
export type { TinyHyperGraphInitialAssignment } from "./initialAssignments"

const GREEDY_FINAL_ROUTE_MAX_ITERATIONS = 50e3

export const createEmptyRegionIntersectionCache =
  (): RegionIntersectionCache => ({
    netIds: new Int32Array(0),
    lesserAngles: new Int32Array(0),
    greaterAngles: new Int32Array(0),
    layerMasks: new Int32Array(0),
    existingCrossingLayerIntersections: 0,
    existingSameLayerIntersections: 0,
    existingEntryExitLayerChanges: 0,
    existingRegionCost: 0,
    existingSegmentCount: 0,
  })

const cloneRegionSegments = (
  regionSegments: Array<[RouteId, PortId, PortId][]>,
): Array<[RouteId, PortId, PortId][]> =>
  regionSegments.map((segments) =>
    segments.map(
      ([routeId, fromPortId, toPortId]) =>
        [routeId, fromPortId, toPortId] as [RouteId, PortId, PortId],
    ),
  )

const cloneRegionIntersectionCache = (
  regionIntersectionCache: RegionIntersectionCache,
): RegionIntersectionCache => ({
  netIds: new Int32Array(regionIntersectionCache.netIds),
  lesserAngles: new Int32Array(regionIntersectionCache.lesserAngles),
  greaterAngles: new Int32Array(regionIntersectionCache.greaterAngles),
  layerMasks: new Int32Array(regionIntersectionCache.layerMasks),
  existingCrossingLayerIntersections:
    regionIntersectionCache.existingCrossingLayerIntersections,
  existingSameLayerIntersections:
    regionIntersectionCache.existingSameLayerIntersections,
  existingEntryExitLayerChanges:
    regionIntersectionCache.existingEntryExitLayerChanges,
  existingRegionCost: regionIntersectionCache.existingRegionCost,
  existingSegmentCount: regionIntersectionCache.existingSegmentCount,
})

const cloneSolvedStateSnapshot = (
  snapshot: SolvedStateSnapshot,
): SolvedStateSnapshot => ({
  portAssignment: new Int32Array(snapshot.portAssignment),
  regionSegments: cloneRegionSegments(snapshot.regionSegments),
  regionIntersectionCaches: snapshot.regionIntersectionCaches.map(
    cloneRegionIntersectionCache,
  ),
  regionCongestionCost: new Float64Array(snapshot.regionCongestionCost),
  ripCount: snapshot.ripCount,
})

export interface TinyHyperGraphTopology {
  portCount: number
  regionCount: number

  /** regionIncidentPorts[regionId] = list of port ids incident to the region */
  regionIncidentPorts: PortId[][]

  /** incidentPortRegion[portId] = list of region ids incident to the port */
  incidentPortRegion: RegionId[][]

  regionWidth: Float64Array
  regionHeight: Float64Array
  regionCenterX: Float64Array
  regionCenterY: Float64Array
  /**
   * regionAvailableZMask[regionId] is a bitmask of the routed layers available
   * within the region. A zero mask means "unknown", which preserves legacy cost
   * behavior for manually-constructed topologies that do not provide this data.
   */
  regionAvailableZMask?: Int32Array

  /** regionMetadata[regionId] = metadata for the region */
  regionMetadata?: any[]

  /** portAngleForRegion1[portId] = CCW angle of the port on incidentPortRegion[portId][0], where 0 is the right side and 9000 is the top */
  portAngleForRegion1: Int32Array
  /** portAngleForRegion2[portId] = CCW angle of the port on incidentPortRegion[portId][1] */
  portAngleForRegion2?: Int32Array
  portX: Float64Array
  portY: Float64Array
  portZ: Int32Array

  portMetadata?: any[]
}

export interface TinyHyperGraphProblem {
  routeCount: number

  /**
   * portSectionMask[portId] = true if port in section
   * Only ports within a section can be explored to solve the problem
   **/
  portSectionMask: Int8Array // boolean[], length: portCount

  /** routeMetadata[routeId] = metadata for the route */
  routeMetadata?: any[]

  /** routeStartRegion[routeId] = list of port ids at the start of the route */
  routeStartPort: Int32Array // PortId[]
  routeEndPort: Int32Array // PortId[]

  // routeNet[routeId] = net id of the route
  routeNet: Int32Array // NetId[]
  /** regionNetId[regionId] = reserved net id for the region, -1 means freely traversable */
  regionNetId: Int32Array

  /** portPenalty[portId] = extra cost paid when a route traverses the port */
  portPenalty?: Float64Array

  /** Fixed before construction: -1 unrestricted, -2 blocked, otherwise only that net. */
  portReservationNetId?: Int32Array

  /** Immutable symmetric CSR shared by section clones; each row is strictly ascending. */
  portConflictOffsets?: Int32Array
  portConflictPortIds?: Int32Array

  /**
   * Existing serialized region assignments, converted to numeric ids.
   *
   * These are regular route-owned assignments: they seed the initial routing
   * state and may be ripped and rerouted by the normal solver machinery.
   */
  initialAssignments?: TinyHyperGraphInitialAssignment[]
}

export interface TinyHyperGraphProblemSetup {
  // portHCostToEndOfRoute[portId * routeCount + routeId] = distance from port to end of route
  portHCostToEndOfRoute?: Float64Array
  portEndpointNetIds: Array<Set<NetId> | undefined>
  /** -1 for no endpoint, -2 for endpoints from multiple nets, otherwise the sole endpoint net. */
  portEndpointReservationNetId: Int32Array
}

export interface TinyHyperGraphSolution {
  /** solvedRoutePathSegments[routeId] = list of segments, each segment is an ordered list of port ids in the route */
  solvedRoutePathSegments: Array<[PortId, PortId][]>
  /**
   * solvedRoutePathRegionIds[routeId][segmentIndex] = explicit region id for
   * solvedRoutePathSegments[routeId][segmentIndex], when known from serialized
   * route data. This preserves exact routed regions for replay instead of
   * inferring from the port pair.
   */
  solvedRoutePathRegionIds?: Array<Array<RegionId | undefined>>
}

export interface RegionCostSummary {
  maxRegionCost: number
  totalRegionCost: number
}

interface SolvedStateSnapshot {
  portAssignment: Int32Array
  regionSegments: Array<[RouteId, PortId, PortId][]>
  regionIntersectionCaches: RegionIntersectionCache[]
  regionCongestionCost: Float64Array
  ripCount: number
}

export interface NeverSuccessfullyRoutedRouteSummary {
  routeId: RouteId
  connectionId: string
  attempts: number
  startPortId: PortId
  endPortId: PortId
  startRegionId?: string
  endRegionId?: string
  pointIds: string[]
}

export interface Candidate {
  hopId?: HopId
  prevRegionId?: RegionId
  portId: PortId
  nextRegionId: RegionId

  prevCandidate?: Candidate

  f: number
  g: number
  h: number
}

export interface TinyHyperGraphCandidateQueue {
  readonly length: number
  toArray(): Candidate[]
  clear(): void
  queue(candidate: Candidate): void
  dequeue(): Candidate | undefined
  isClosedHop?(portId: PortId, nextRegionId: RegionId): boolean
  isClosedHopId?(hopId: HopId): boolean
}

export interface TinyHyperGraphWorkingState {
  // portAssignment[portId] = NetId, -1 means unassigned
  portAssignment: Int32Array

  // regionSegments[regionId] = Array<Route Assignment and Two Ports>
  regionSegments: Array<[RouteId, PortId, PortId][]>

  // regionIntersectionCache[regionId] = DynamicAnglePairArrays
  regionIntersectionCaches: RegionIntersectionCache[]

  currentRouteNetId: NetId | undefined
  currentRouteId: RouteId | undefined

  unroutedRoutes: RouteId[]

  candidateQueue: TinyHyperGraphCandidateQueue
  candidateBestCostByHopId: Float64Array | Map<HopId, number>
  candidateBestCostGenerationByHopId: Uint32Array | Map<HopId, number>
  candidateBestCostGeneration: number

  goalPortId: PortId

  ripCount: number

  /** regionCongestionCost[regionId] = congestion cost */
  regionCongestionCost: Float64Array
}

export interface TinyHyperGraphSolverOptions {
  minViaPadDiameter?: number
  DISTANCE_TO_COST?: number
  RIP_THRESHOLD_START?: number
  RIP_THRESHOLD_END?: number
  RIP_THRESHOLD_RAMP_ATTEMPTS?: number
  RIP_CONGESTION_REGION_COST_FACTOR?: number
  /** Opt-in quadratic penalty for concentrating traces in low-capacity regions. */
  TRACE_DENSITY_COST_FACTOR?: number
  USE_LAZY_ROUTE_HEURISTIC?: boolean
  USE_SPARSE_CANDIDATE_STORAGE?: boolean
  /**
   * Retain ordered regional occurrences after observing their native hop closed,
   * and reuse successful static neighbor checks during the owned search epoch.
   * The caller owns ordinary topology/problem/state and plain native queued
   * candidates for the entire queue epoch. Key mappings and metadata remain
   * fixed between steps, and IndexedCandidateHeap methods retain their standard
   * key and closure behavior. No external candidate injection or mutation of
   * queued references is allowed. Pure scoring overrides are allowed when they
   * preserve this contract.
   * This flag does not detect custom methods: leave it disabled for observable
   * key/closure hooks or mutation during expansion. Standard native builtins are
   * required. Read-only observation is allowed. Clear, queue replacement, goal
   * changes, best-cost resets and neighbor-array replacement invalidate retained
   * metadata. Other queue implementations use the original search.
   */
  OWNED_REGIONAL_HOP_FRONTIER?: boolean
  MAX_ITERATIONS?: number
  VERBOSE?: boolean
  STATIC_REACHABILITY_PRECHECK?: boolean
  STATIC_REACHABILITY_PRECHECK_MAX_HOPS?: number
  ACCEPT_BEST_SOLUTION_ON_TIMEOUT?: boolean
  GREEDY_FINAL_ROUTE_ITERS?: number
  /** Preserve route prefixes/suffixes and reopen only a bounded hot span. */
  PARTIAL_RIP_ENABLED?: boolean
  /** Minimum route count required to enable partial-rip optimization. */
  PARTIAL_RIP_MIN_ROUTE_COUNT?: number
  /** Maximum route count allowed to use partial-rip optimization. */
  PARTIAL_RIP_MAX_ROUTE_COUNT?: number
  /** Maximum old-route distance reopened on either side of a hot segment. */
  PARTIAL_RIP_MAX_DISTANCE?: number
  /** Larger partial-rip window used when the initial solution is near target. */
  PARTIAL_RIP_QUALITY_MAX_DISTANCE?: number
  /** Maximum completed partial-rip rounds before restoring the best state. */
  PARTIAL_RIP_MAX_ATTEMPTS?: number
  /** Whole-graph reseeds allowed before subsequent hot-region partial rips. */
  PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS?: number
  /**
   * Minimum route count before route complexity may break region-cost ties
   * inside the configured quality envelope.
   */
  PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT?: number
  /** Stop after improving the initial max region cost by this fraction. */
  PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO?: number
  /** Max region-cost growth allowed while preferring a simpler route state. */
  PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO?: number
  /** Maximum total region-cost growth allowed for an early-stop candidate. */
  PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO?: number
  /** Search from both active route ends instead of only the start end. */
  OUTSIDE_IN_ROUTING?: boolean
  /** Maximum geometric distance explored by either outside-in frontier. */
  OUTSIDE_IN_MAX_DISTANCE?: number
}

export interface TinyHyperGraphSolverOptionTarget {
  minViaPadDiameter: number
  DISTANCE_TO_COST: number
  RIP_THRESHOLD_START: number
  RIP_THRESHOLD_END: number
  RIP_THRESHOLD_RAMP_ATTEMPTS: number
  RIP_CONGESTION_REGION_COST_FACTOR: number
  TRACE_DENSITY_COST_FACTOR?: number
  USE_LAZY_ROUTE_HEURISTIC?: boolean
  USE_SPARSE_CANDIDATE_STORAGE?: boolean
  OWNED_REGIONAL_HOP_FRONTIER?: boolean
  MAX_ITERATIONS: number
  VERBOSE: boolean
  STATIC_REACHABILITY_PRECHECK: boolean
  STATIC_REACHABILITY_PRECHECK_MAX_HOPS: number
  ACCEPT_BEST_SOLUTION_ON_TIMEOUT: boolean
  GREEDY_FINAL_ROUTE_ITERS: number
  PARTIAL_RIP_ENABLED?: boolean
  PARTIAL_RIP_MIN_ROUTE_COUNT?: number
  PARTIAL_RIP_MAX_ROUTE_COUNT?: number
  PARTIAL_RIP_MAX_DISTANCE?: number
  PARTIAL_RIP_QUALITY_MAX_DISTANCE?: number
  PARTIAL_RIP_MAX_ATTEMPTS?: number
  PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS?: number
  PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT?: number
  PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO?: number
  PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO?: number
  PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO?: number
  OUTSIDE_IN_ROUTING?: boolean
  OUTSIDE_IN_MAX_DISTANCE?: number
}

export const applyTinyHyperGraphSolverOptions = (
  solver: TinyHyperGraphSolverOptionTarget,
  options?: TinyHyperGraphSolverOptions,
) => {
  if (!options) {
    return
  }

  if (options.minViaPadDiameter !== undefined) {
    solver.minViaPadDiameter = options.minViaPadDiameter
  }
  if (options.DISTANCE_TO_COST !== undefined) {
    solver.DISTANCE_TO_COST = options.DISTANCE_TO_COST
  }
  if (options.RIP_THRESHOLD_START !== undefined) {
    solver.RIP_THRESHOLD_START = options.RIP_THRESHOLD_START
  }
  if (options.RIP_THRESHOLD_END !== undefined) {
    solver.RIP_THRESHOLD_END = options.RIP_THRESHOLD_END
  }
  if (options.RIP_THRESHOLD_RAMP_ATTEMPTS !== undefined) {
    solver.RIP_THRESHOLD_RAMP_ATTEMPTS = options.RIP_THRESHOLD_RAMP_ATTEMPTS
  }
  if (options.RIP_CONGESTION_REGION_COST_FACTOR !== undefined) {
    solver.RIP_CONGESTION_REGION_COST_FACTOR =
      options.RIP_CONGESTION_REGION_COST_FACTOR
  }
  if (options.TRACE_DENSITY_COST_FACTOR !== undefined) {
    solver.TRACE_DENSITY_COST_FACTOR = Math.max(
      0,
      options.TRACE_DENSITY_COST_FACTOR,
    )
  }
  if (options.USE_LAZY_ROUTE_HEURISTIC !== undefined) {
    solver.USE_LAZY_ROUTE_HEURISTIC = options.USE_LAZY_ROUTE_HEURISTIC
  }
  if (options.USE_SPARSE_CANDIDATE_STORAGE !== undefined) {
    solver.USE_SPARSE_CANDIDATE_STORAGE = options.USE_SPARSE_CANDIDATE_STORAGE
  }
  if (options.OWNED_REGIONAL_HOP_FRONTIER !== undefined) {
    solver.OWNED_REGIONAL_HOP_FRONTIER = options.OWNED_REGIONAL_HOP_FRONTIER
  }
  if (options.MAX_ITERATIONS !== undefined) {
    solver.MAX_ITERATIONS = options.MAX_ITERATIONS
  }
  if (options.VERBOSE !== undefined) {
    solver.VERBOSE = options.VERBOSE
  }
  if (options.STATIC_REACHABILITY_PRECHECK !== undefined) {
    solver.STATIC_REACHABILITY_PRECHECK = options.STATIC_REACHABILITY_PRECHECK
  }
  if (options.STATIC_REACHABILITY_PRECHECK_MAX_HOPS !== undefined) {
    solver.STATIC_REACHABILITY_PRECHECK_MAX_HOPS =
      options.STATIC_REACHABILITY_PRECHECK_MAX_HOPS
  }
  if (options.ACCEPT_BEST_SOLUTION_ON_TIMEOUT !== undefined) {
    solver.ACCEPT_BEST_SOLUTION_ON_TIMEOUT =
      options.ACCEPT_BEST_SOLUTION_ON_TIMEOUT
  }
  if (options.GREEDY_FINAL_ROUTE_ITERS !== undefined) {
    solver.GREEDY_FINAL_ROUTE_ITERS = options.GREEDY_FINAL_ROUTE_ITERS
  }
  if (options.PARTIAL_RIP_ENABLED !== undefined) {
    solver.PARTIAL_RIP_ENABLED = options.PARTIAL_RIP_ENABLED
  }
  if (options.PARTIAL_RIP_MIN_ROUTE_COUNT !== undefined) {
    solver.PARTIAL_RIP_MIN_ROUTE_COUNT = options.PARTIAL_RIP_MIN_ROUTE_COUNT
  }
  if (options.PARTIAL_RIP_MAX_ROUTE_COUNT !== undefined) {
    solver.PARTIAL_RIP_MAX_ROUTE_COUNT = options.PARTIAL_RIP_MAX_ROUTE_COUNT
  }
  if (options.PARTIAL_RIP_MAX_DISTANCE !== undefined) {
    solver.PARTIAL_RIP_MAX_DISTANCE = options.PARTIAL_RIP_MAX_DISTANCE
  }
  if (options.PARTIAL_RIP_QUALITY_MAX_DISTANCE !== undefined) {
    solver.PARTIAL_RIP_QUALITY_MAX_DISTANCE =
      options.PARTIAL_RIP_QUALITY_MAX_DISTANCE
  }
  if (options.PARTIAL_RIP_MAX_ATTEMPTS !== undefined) {
    solver.PARTIAL_RIP_MAX_ATTEMPTS = options.PARTIAL_RIP_MAX_ATTEMPTS
  }
  if (options.PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS !== undefined) {
    solver.PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS =
      options.PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS
  }
  if (options.PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT !== undefined) {
    solver.PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT =
      options.PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT
  }
  if (options.PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO !== undefined) {
    solver.PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO =
      options.PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO
  }
  if (options.PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO !== undefined) {
    solver.PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO =
      options.PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO
  }
  if (options.PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO !== undefined) {
    solver.PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO =
      options.PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO
  }
  if (options.OUTSIDE_IN_ROUTING !== undefined) {
    solver.OUTSIDE_IN_ROUTING = options.OUTSIDE_IN_ROUTING
  }
  if (options.OUTSIDE_IN_MAX_DISTANCE !== undefined) {
    solver.OUTSIDE_IN_MAX_DISTANCE = options.OUTSIDE_IN_MAX_DISTANCE
  }
}

export const getTinyHyperGraphSolverOptions = (
  solver: TinyHyperGraphSolverOptionTarget,
): TinyHyperGraphSolverOptions => ({
  minViaPadDiameter: solver.minViaPadDiameter,
  DISTANCE_TO_COST: solver.DISTANCE_TO_COST,
  RIP_THRESHOLD_START: solver.RIP_THRESHOLD_START,
  RIP_THRESHOLD_END: solver.RIP_THRESHOLD_END,
  RIP_THRESHOLD_RAMP_ATTEMPTS: solver.RIP_THRESHOLD_RAMP_ATTEMPTS,
  RIP_CONGESTION_REGION_COST_FACTOR: solver.RIP_CONGESTION_REGION_COST_FACTOR,
  TRACE_DENSITY_COST_FACTOR: solver.TRACE_DENSITY_COST_FACTOR,
  USE_LAZY_ROUTE_HEURISTIC: solver.USE_LAZY_ROUTE_HEURISTIC,
  USE_SPARSE_CANDIDATE_STORAGE: solver.USE_SPARSE_CANDIDATE_STORAGE,
  OWNED_REGIONAL_HOP_FRONTIER: solver.OWNED_REGIONAL_HOP_FRONTIER,
  MAX_ITERATIONS: solver.MAX_ITERATIONS,
  VERBOSE: solver.VERBOSE,
  STATIC_REACHABILITY_PRECHECK: solver.STATIC_REACHABILITY_PRECHECK,
  STATIC_REACHABILITY_PRECHECK_MAX_HOPS:
    solver.STATIC_REACHABILITY_PRECHECK_MAX_HOPS,
  ACCEPT_BEST_SOLUTION_ON_TIMEOUT: solver.ACCEPT_BEST_SOLUTION_ON_TIMEOUT,
  GREEDY_FINAL_ROUTE_ITERS: solver.GREEDY_FINAL_ROUTE_ITERS,
  PARTIAL_RIP_ENABLED: solver.PARTIAL_RIP_ENABLED,
  PARTIAL_RIP_MIN_ROUTE_COUNT: solver.PARTIAL_RIP_MIN_ROUTE_COUNT,
  PARTIAL_RIP_MAX_ROUTE_COUNT: solver.PARTIAL_RIP_MAX_ROUTE_COUNT,
  PARTIAL_RIP_MAX_DISTANCE: solver.PARTIAL_RIP_MAX_DISTANCE,
  PARTIAL_RIP_QUALITY_MAX_DISTANCE: solver.PARTIAL_RIP_QUALITY_MAX_DISTANCE,
  PARTIAL_RIP_MAX_ATTEMPTS: solver.PARTIAL_RIP_MAX_ATTEMPTS,
  PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS:
    solver.PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS,
  PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT:
    solver.PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT,
  PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO:
    solver.PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO,
  PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO:
    solver.PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO,
  PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO:
    solver.PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO,
  OUTSIDE_IN_ROUTING: solver.OUTSIDE_IN_ROUTING,
  OUTSIDE_IN_MAX_DISTANCE: solver.OUTSIDE_IN_MAX_DISTANCE,
})

const compareCandidatesByF = (left: Candidate, right: Candidate) =>
  left.f - right.f

type SegmentGeometryScratch = MutableIntersectionCount

type RegionalHopFrontier = {
  neighbors: PortId[]
  next: Int32Array
  prepared: Uint8Array
  nextRegionIds: Float64Array
  hopIds: Float64Array
  head: number
}

export class TinyHyperGraphSolver extends BaseSolver {
  state: TinyHyperGraphWorkingState
  /** Number of incident-region slots reserved for each port. */
  protected readonly candidateHopSlotStride: number
  protected readonly candidateHopCapacity: number
  /** Flat common-case lookup avoids walking nested topology arrays per hop. */
  protected readonly candidateFirstRegionByPortId: Int32Array
  protected readonly candidateSecondRegionByPortId: Int32Array
  /** Rare fallback for callers that construct a non-incident directed hop. */
  private candidateOverflowBestCost?: Map<HopId, number>
  private regionalHopFrontierQueue?: TinyHyperGraphCandidateQueue
  private regionalHopFrontierEpoch?: object
  private regionalHopFrontierGoalPortId?: PortId
  private regionalHopFrontierRouteId?: RouteId
  private regionalHopFrontierNetId?: NetId
  private regionalHopFrontierBestCostGeneration?: number
  private regionalHopFrontiers = new Map<RegionId, RegionalHopFrontier>()
  private _problemSetup?: TinyHyperGraphProblemSetup
  private readonly hCostByPortId: Float64Array
  private readonly hCostRouteIdByPortId: Int32Array
  private hCostEndRouteId: RouteId | undefined
  private hCostEndX = 0
  private hCostEndY = 0
  protected routeAttemptCountByRouteId: Uint32Array
  protected routeSuccessCountByRouteId: Uint32Array
  protected bestSolvedStateSnapshot?: SolvedStateSnapshot
  protected bestSolvedStateSummary?: RegionCostSummary
  private hasLoggedNeverSuccessfullyRoutedRoutes = false
  private staticallyUnroutableRoutes: StaticallyUnroutableRouteSummary[] = []
  private segmentGeometryScratch: SegmentGeometryScratch = {
    netId: 0,
    lesserAngle: 0,
    greaterAngle: 0,
    layerMask: 0,
    entryExitLayerChanges: 0,
    sameLayerIntersectionCount: 0,
    crossingLayerIntersectionCount: 0,
  }
  protected ADD_SEGMENT_DISTANCE_TO_G = false
  protected costAwareFinalReripBudget = 0

  DISTANCE_TO_COST = 0.05 // 50mm = 1 cost unit (1 cost unit ~ 100% chance of failure)
  minViaPadDiameter = DEFAULT_MIN_VIA_PAD_DIAMETER

  RIP_THRESHOLD_START = 0.05
  RIP_THRESHOLD_END = 0.8
  RIP_THRESHOLD_RAMP_ATTEMPTS = 50

  RIP_CONGESTION_REGION_COST_FACTOR = 0.1
  TRACE_DENSITY_COST_FACTOR = 0
  USE_LAZY_ROUTE_HEURISTIC = true
  USE_SPARSE_CANDIDATE_STORAGE = false
  OWNED_REGIONAL_HOP_FRONTIER = false

  override MAX_ITERATIONS = 1e6
  VERBOSE = false
  STATIC_REACHABILITY_PRECHECK = true
  STATIC_REACHABILITY_PRECHECK_MAX_HOPS = 16
  ACCEPT_BEST_SOLUTION_ON_TIMEOUT = true
  GREEDY_FINAL_ROUTE_ITERS = 4
  PARTIAL_RIP_ENABLED = false
  PARTIAL_RIP_MIN_ROUTE_COUNT = 0
  PARTIAL_RIP_MAX_ROUTE_COUNT = Number.POSITIVE_INFINITY
  PARTIAL_RIP_MAX_DISTANCE = 12
  PARTIAL_RIP_QUALITY_MAX_DISTANCE?: number
  PARTIAL_RIP_MAX_ATTEMPTS = Number.POSITIVE_INFINITY
  PARTIAL_RIP_WARMUP_FULL_RIP_ATTEMPTS = 0
  PARTIAL_RIP_COMPLEXITY_SELECTION_MIN_ROUTE_COUNT = Number.POSITIVE_INFINITY
  PARTIAL_RIP_TARGET_MAX_COST_IMPROVEMENT_RATIO = 0
  PARTIAL_RIP_MAX_REGION_COST_GROWTH_RATIO = 0.2
  PARTIAL_RIP_MAX_TOTAL_COST_GROWTH_RATIO = 0.1
  OUTSIDE_IN_ROUTING = false
  OUTSIDE_IN_MAX_DISTANCE = 24

  constructor(
    public topology: TinyHyperGraphTopology,
    public problem: TinyHyperGraphProblem,
    options?: TinyHyperGraphSolverOptions,
  ) {
    super()
    validatePortReservations(problem.portReservationNetId, topology.portCount)
    validatePortConflicts(problem.portConflictOffsets, problem.portConflictPortIds, topology.portCount)
    applyTinyHyperGraphSolverOptions(this, options)
    let candidateHopSlotStride = 1
    const candidateFirstRegionByPortId = new Int32Array(
      topology.portCount,
    ).fill(-1)
    const candidateSecondRegionByPortId = new Int32Array(
      topology.portCount,
    ).fill(-1)
    for (let portId = 0; portId < topology.portCount; portId++) {
      const incidentRegionIds = topology.incidentPortRegion[portId] ?? []
      if (incidentRegionIds.length > candidateHopSlotStride) {
        candidateHopSlotStride = incidentRegionIds.length
      }
      candidateFirstRegionByPortId[portId] = incidentRegionIds[0] ?? -1
      candidateSecondRegionByPortId[portId] = incidentRegionIds[1] ?? -1
    }
    this.candidateHopSlotStride = candidateHopSlotStride
    this.candidateFirstRegionByPortId = candidateFirstRegionByPortId
    this.candidateSecondRegionByPortId = candidateSecondRegionByPortId
    this.hCostByPortId = new Float64Array(topology.portCount)
    this.hCostRouteIdByPortId = new Int32Array(topology.portCount).fill(-1)
    const candidateHopCapacity = topology.portCount * candidateHopSlotStride
    this.candidateHopCapacity = candidateHopCapacity
    this.state = {
      portAssignment: new Int32Array(topology.portCount).fill(-1),
      regionSegments: Array.from({ length: topology.regionCount }, () => []),
      regionIntersectionCaches: Array.from(
        { length: topology.regionCount },
        () => createEmptyRegionIntersectionCache(),
      ),
      currentRouteId: undefined,
      currentRouteNetId: undefined,
      unroutedRoutes: range(problem.routeCount),
      candidateQueue: new MinHeap([], compareCandidatesByF),
      candidateBestCostByHopId: this.USE_SPARSE_CANDIDATE_STORAGE
        ? new Map()
        : new Float64Array(candidateHopCapacity),
      candidateBestCostGenerationByHopId: this.USE_SPARSE_CANDIDATE_STORAGE
        ? new Map()
        : new Uint32Array(candidateHopCapacity),
      candidateBestCostGeneration: 1,
      goalPortId: -1,
      ripCount: 0,
      regionCongestionCost: new Float64Array(topology.regionCount).fill(0),
    }
    this.routeAttemptCountByRouteId = new Uint32Array(problem.routeCount)
    this.routeSuccessCountByRouteId = new Uint32Array(problem.routeCount)
    const initialAssignmentStats = applyInitialAssignments({
      topology,
      problem,
      state: this.state,
      routeSuccessCountByRouteId: this.routeSuccessCountByRouteId,
      appendSegmentToRegionCache: (regionId, fromPortId, toPortId) =>
        this.appendSegmentToRegionCache(regionId, fromPortId, toPortId),
    })
    if (initialAssignmentStats) {
      this.stats = {
        ...this.stats,
        ...initialAssignmentStats,
      }
    }
  }

  /**
   * Reuse the topology-sized workspace for another independent problem on the
   * same topology. Only the base solver is supported. Solver options are
   * preserved; routing state is cleared and new initial assignments are applied.
   */
  resetForProblem(problem: TinyHyperGraphProblem): void {
    if (this.constructor !== TinyHyperGraphSolver) {
      throw new Error(
        "TinyHyperGraphSolver.resetForProblem cannot reset subclass routing state",
      )
    }
    validatePortReservations(problem.portReservationNetId, this.topology.portCount)
    validatePortConflicts(problem.portConflictOffsets, problem.portConflictPortIds, this.topology.portCount)
    this.problem = problem
    this._problemSetup = undefined
    this.hCostEndRouteId = undefined
    this.hCostRouteIdByPortId.fill(-1)
    this.state.portAssignment.fill(-1)
    for (const regionSegments of this.state.regionSegments) {
      regionSegments.length = 0
    }
    this.state.regionIntersectionCaches.fill(
      createEmptyRegionIntersectionCache(),
    )
    this.state.currentRouteId = undefined
    this.state.currentRouteNetId = undefined
    this.state.unroutedRoutes = range(problem.routeCount)
    this.state.candidateQueue.clear()
    this.state.candidateBestCostGeneration = 1
    this.state.candidateBestCostByHopId instanceof Map
      ? this.state.candidateBestCostByHopId.clear()
      : this.state.candidateBestCostByHopId.fill(0)
    this.state.candidateBestCostGenerationByHopId instanceof Map
      ? this.state.candidateBestCostGenerationByHopId.clear()
      : this.state.candidateBestCostGenerationByHopId.fill(0)
    this.state.goalPortId = -1
    this.state.ripCount = 0
    this.state.regionCongestionCost.fill(0)
    this.routeAttemptCountByRouteId = new Uint32Array(problem.routeCount)
    this.routeSuccessCountByRouteId = new Uint32Array(problem.routeCount)
    this.bestSolvedStateSnapshot = undefined
    this.bestSolvedStateSummary = undefined
    this.hasLoggedNeverSuccessfullyRoutedRoutes = false
    this.staticallyUnroutableRoutes = []
    this.candidateOverflowBestCost?.clear()
    this.solved = false
    this.failed = false
    this.iterations = 0
    this.progress = 0
    this.error = null
    this.activeSubSolver = undefined
    this.failedSubSolvers = undefined
    this.timeToSolve = undefined
    this.stats = {}
    this._setupDone = false
    const initialAssignmentStats = applyInitialAssignments({
      topology: this.topology,
      problem,
      state: this.state,
      routeSuccessCountByRouteId: this.routeSuccessCountByRouteId,
      appendSegmentToRegionCache: (regionId, fromPortId, toPortId) =>
        this.appendSegmentToRegionCache(regionId, fromPortId, toPortId),
    })
    if (initialAssignmentStats) {
      this.stats = {
        ...this.stats,
        ...initialAssignmentStats,
      }
    }
  }

  get problemSetup(): TinyHyperGraphProblemSetup {
    if (!this._problemSetup) {
      this._problemSetup = this.computeProblemSetup()
    }

    return this._problemSetup
  }

  computeProblemSetup(): TinyHyperGraphProblemSetup {
    const { topology, problem } = this
    const portHCostToEndOfRoute = this.USE_LAZY_ROUTE_HEURISTIC
      ? undefined
      : new Float64Array(topology.portCount * problem.routeCount)
    const portX = topology.portX as unknown as ArrayLike<number>
    const portY = topology.portY as unknown as ArrayLike<number>
    const portEndpointNetIds: Array<Set<NetId> | undefined> = []
    const portEndpointReservationNetId = new Int32Array(
      topology.portCount,
    ).fill(-1)
    const recordEndpointNet = (portId: PortId, netId: NetId) => {
      const endpointNetIds = portEndpointNetIds[portId] ?? new Set<NetId>()
      endpointNetIds.add(netId)
      portEndpointNetIds[portId] = endpointNetIds
      const reservedNetId = portEndpointReservationNetId[portId]!
      if (reservedNetId === -1) {
        portEndpointReservationNetId[portId] = netId
      } else if (reservedNetId !== netId) {
        portEndpointReservationNetId[portId] = -2
      }
    }

    for (let routeId = 0; routeId < problem.routeCount; routeId++) {
      const routeNetId = problem.routeNet[routeId]!
      recordEndpointNet(problem.routeStartPort[routeId]!, routeNetId)
      recordEndpointNet(problem.routeEndPort[routeId]!, routeNetId)

      if (portHCostToEndOfRoute) {
        const endPortId = problem.routeEndPort[routeId]
        const endX = portX[endPortId]
        const endY = portY[endPortId]

        for (let portId = 0; portId < topology.portCount; portId++) {
          const dx = portX[portId] - endX
          const dy = portY[portId] - endY
          portHCostToEndOfRoute[portId * problem.routeCount + routeId] =
            Math.sqrt(dx * dx + dy * dy) * this.DISTANCE_TO_COST
        }
      }
    }

    return {
      ...(portHCostToEndOfRoute ? { portHCostToEndOfRoute } : {}),
      portEndpointNetIds,
      portEndpointReservationNetId,
    }
  }

  override _setup() {
    void this.problemSetup

    if (this.STATIC_REACHABILITY_PRECHECK) {
      const staticallyUnroutableRoutes = getStaticallyUnroutableRoutes({
        topology: this.topology,
        problem: this.problem,
        problemSetup: this.problemSetup,
        portAssignment: this.state.portAssignment,
        routeIds: this.state.unroutedRoutes,
        maxPrecheckHops: Math.max(
          0,
          this.STATIC_REACHABILITY_PRECHECK_MAX_HOPS,
        ),
        getStartingNextRegionId: (routeId, startingPortId) =>
          this.getStartingNextRegionId(routeId, startingPortId),
        getRouteSummary: (routeId) => this.getRouteSummary(routeId),
      })
      this.staticallyUnroutableRoutes = staticallyUnroutableRoutes
      if (staticallyUnroutableRoutes.length > 0) {
        this.failed = true
        this.error = getStaticReachabilityError(staticallyUnroutableRoutes)
        this.stats = {
          ...this.stats,
          staticallyUnroutableRouteCount: staticallyUnroutableRoutes.length,
        }
      }
    }
  }

  override _step() {
    const { problem, topology, state } = this

    if (state.currentRouteId === undefined) {
      if (state.unroutedRoutes.length === 0) {
        this.onAllRoutesRouted()
        return
      }

      state.currentRouteId = state.unroutedRoutes.shift()
      state.currentRouteNetId = problem.routeNet[state.currentRouteId!]
      this.routeAttemptCountByRouteId[state.currentRouteId!] += 1

      this.resetCandidateBestCosts()
      const startingPortId = this.getRouteStartPortId(state.currentRouteId!)
      state.candidateQueue.clear()
      if ((problem.portReservationNetId !== undefined || problem.portConflictOffsets !== undefined) && this.isPortReservedForDifferentNet(startingPortId)) {
        this.failed = true
        this.error = `Start port ${startingPortId} is reserved for a different net`
        return
      }
      if (problem.portConflictOffsets !== undefined && this.isPortOccupiedForDifferentNet(startingPortId)) {
        throw new Error(`Start port ${startingPortId} conflicts with an existing foreign route`)
      }
      const startingNextRegionId = this.getStartingNextRegionId(
        state.currentRouteId!,
        startingPortId,
      )

      if (startingNextRegionId === undefined) {
        this.failed = true
        this.error = `Start port ${startingPortId} has no incident regions`
        return
      }

      const startingHopId = this.getHopId(startingPortId, startingNextRegionId)
      this.setCandidateBestCost(startingHopId, 0)
      state.candidateQueue.queue({
        hopId: startingHopId,
        nextRegionId: startingNextRegionId,
        portId: startingPortId,
        f: 0,
        g: 0,
        h: 0,
      })
      state.goalPortId = this.getRouteEndPortId(state.currentRouteId!)
    }

    const currentCandidate = state.candidateQueue.dequeue()

    if (!currentCandidate) {
      this.onOutOfCandidates()
      return
    }

    const currentCandidateHopId =
      currentCandidate.hopId ??
      this.getHopId(currentCandidate.portId, currentCandidate.nextRegionId)
    if (currentCandidate.g > this.getCandidateBestCost(currentCandidateHopId)) {
      return
    }

    if (this.isRegionReservedForDifferentNet(currentCandidate.nextRegionId)) {
      return
    }

    const neighbors =
      topology.regionIncidentPorts[currentCandidate.nextRegionId]

    if (this.OWNED_REGIONAL_HOP_FRONTIER) {
      const frontier = this.getRegionalHopFrontier(
        currentCandidate.nextRegionId,
        neighbors,
      )
      if (frontier) {
        this.expandRegionalHopFrontier(currentCandidate, frontier)
        return
      }
    }

    for (const neighborPortId of neighbors) {
      if (neighborPortId === state.goalPortId) {
        if (this.isPortReservedForDifferentNet(neighborPortId)) continue
        if (this.isPortOccupiedForDifferentNet(neighborPortId)) {
          continue
        }
        if (this.isHardBlockedSingleLayerHop(currentCandidate, neighborPortId)) {
          continue
        }
        this.onPathFound(currentCandidate)
        return
      }
      if (neighborPortId === currentCandidate.portId) continue
      if (problem.portSectionMask[neighborPortId] === 0) continue

      const nextRegionId =
        topology.incidentPortRegion[neighborPortId][0] ===
        currentCandidate.nextRegionId
          ? topology.incidentPortRegion[neighborPortId][1]
          : topology.incidentPortRegion[neighborPortId][0]

      if (nextRegionId === undefined) continue

      const candidateHopId = this.getHopId(neighborPortId, nextRegionId)
      const candidateHopIsClosed = state.candidateQueue.isClosedHopId
        ? state.candidateQueue.isClosedHopId(candidateHopId)
        : state.candidateQueue.isClosedHop?.(neighborPortId, nextRegionId)
      if (candidateHopIsClosed === true) {
        continue
      }
      if (this.isPortReservedForDifferentNet(neighborPortId)) continue
      if (this.isPortOccupiedForDifferentNet(neighborPortId)) {
        continue
      }
      if (this.isRegionReservedForDifferentNet(nextRegionId)) continue
      const previousBestCost = this.getCandidateBestCost(candidateHopId)
      if (currentCandidate.g >= previousBestCost) continue
      const lowerBoundWithoutDistance =
        currentCandidate.g +
        state.regionCongestionCost[currentCandidate.nextRegionId]! +
        (problem.portPenalty?.[neighborPortId] ?? 0)
      let knownSegmentDistance: number | undefined
      let lowerBoundCost = lowerBoundWithoutDistance
      if (this.ADD_SEGMENT_DISTANCE_TO_G) {
        const dx =
          topology.portX[currentCandidate.portId]! -
          topology.portX[neighborPortId]!
        const dy =
          topology.portY[currentCandidate.portId]! -
          topology.portY[neighborPortId]!
        knownSegmentDistance = Math.sqrt(dx * dx + dy * dy)
        lowerBoundCost += knownSegmentDistance * this.DISTANCE_TO_COST
      }
      if (lowerBoundCost >= previousBestCost) continue
      if (this.isHardBlockedSingleLayerHop(currentCandidate, neighborPortId)) {
        continue
      }
      const g = this.computeG(
        currentCandidate,
        neighborPortId,
        previousBestCost,
        knownSegmentDistance,
      )
      if (!Number.isFinite(g) || g >= previousBestCost) continue
      const h = this.computeH(neighborPortId)

      const newCandidate = {
        hopId: candidateHopId,
        prevRegionId: currentCandidate.nextRegionId,
        nextRegionId,
        portId: neighborPortId,
        g,
        h,
        f: g + h,
        prevCandidate: currentCandidate,
      }

      if (neighborPortId === state.goalPortId) {
        this.onPathFound(newCandidate)
        return
      }

      this.setCandidateBestCost(candidateHopId, g)
      state.candidateQueue.queue(newCandidate)
    }
  }

  private getRegionalHopFrontier(
    regionId: RegionId,
    neighbors: PortId[],
  ): RegionalHopFrontier | undefined {
    const { state } = this
    const queue = state.candidateQueue
    if (!(queue instanceof IndexedCandidateHeap)) {
      this.regionalHopFrontierQueue = undefined
      this.regionalHopFrontierEpoch = undefined
      this.regionalHopFrontiers.clear()
      return undefined
    }

    const epoch = queue.closureEpoch
    if (
      queue !== this.regionalHopFrontierQueue ||
      epoch !== this.regionalHopFrontierEpoch ||
      state.goalPortId !== this.regionalHopFrontierGoalPortId ||
      state.currentRouteId !== this.regionalHopFrontierRouteId ||
      state.currentRouteNetId !== this.regionalHopFrontierNetId ||
      state.candidateBestCostGeneration !==
        this.regionalHopFrontierBestCostGeneration
    ) {
      this.regionalHopFrontierQueue = queue
      this.regionalHopFrontierEpoch = epoch
      this.regionalHopFrontierGoalPortId = state.goalPortId
      this.regionalHopFrontierRouteId = state.currentRouteId
      this.regionalHopFrontierNetId = state.currentRouteNetId
      this.regionalHopFrontierBestCostGeneration =
        state.candidateBestCostGeneration
      this.regionalHopFrontiers.clear()
    }

    // Prepare metadata lazily in scan order so an early goal or scoring failure
    // still prevents reading later incidence, including malformed metadata.
    if (!Array.isArray(neighbors) || neighbors.length > 0x7fffffff) {
      return undefined
    }
    let frontier = this.regionalHopFrontiers.get(regionId)
    if (!frontier || frontier.neighbors !== neighbors) {
      const next = new Int32Array(neighbors.length)
      for (let index = 0; index < neighbors.length; index++) {
        next[index] = index + 1 < neighbors.length ? index + 1 : -1
      }
      frontier = {
        neighbors,
        next,
        prepared: new Uint8Array(neighbors.length),
        nextRegionIds: new Float64Array(neighbors.length),
        hopIds: new Float64Array(neighbors.length),
        head: neighbors.length > 0 ? 0 : -1,
      }
      this.regionalHopFrontiers.set(regionId, frontier)
    }
    return frontier
  }

  private expandRegionalHopFrontier(
    currentCandidate: Candidate,
    frontier: RegionalHopFrontier,
  ): void {
    const { problem, topology, state } = this
    const { neighbors, next, prepared, nextRegionIds, hopIds } = frontier
    let neighborIndex = frontier.head
    let previousNeighborIndex = -1
    while (neighborIndex !== -1) {
      const currentNeighborIndex = neighborIndex
      neighborIndex = next[currentNeighborIndex]!
      const previousIndex = previousNeighborIndex
      previousNeighborIndex = currentNeighborIndex
      const neighborPortId = neighbors[currentNeighborIndex]!
      if (neighborPortId === state.goalPortId) {
        if (this.isPortReservedForDifferentNet(neighborPortId)) continue
        if (this.isPortOccupiedForDifferentNet(neighborPortId)) {
          continue
        }
        if (this.isHardBlockedSingleLayerHop(currentCandidate, neighborPortId)) {
          continue
        }
        this.onPathFound(currentCandidate)
        return
      }
      if (neighborPortId === currentCandidate.portId) continue
      if (problem.portConflictOffsets !== undefined && this.isPortOccupiedForDifferentNet(neighborPortId)) continue
      let nextRegionId: RegionId
      let candidateHopId: HopId
      if (prepared[currentNeighborIndex]) {
        nextRegionId = nextRegionIds[currentNeighborIndex]!
        candidateHopId = hopIds[currentNeighborIndex]!
      } else {
        if (problem.portSectionMask[neighborPortId] === 0) continue
        const nextRegion =
          topology.incidentPortRegion[neighborPortId][0] ===
          currentCandidate.nextRegionId
            ? topology.incidentPortRegion[neighborPortId][1]
            : topology.incidentPortRegion[neighborPortId][0]
        if (nextRegion === undefined) continue
        nextRegionId = nextRegion
        candidateHopId = this.getHopId(neighborPortId, nextRegionId)
      }
      const candidateHopIsClosed = state.candidateQueue.isClosedHopId
        ? state.candidateQueue.isClosedHopId(candidateHopId)
        : state.candidateQueue.isClosedHop?.(neighborPortId, nextRegionId)
      if (candidateHopIsClosed === true) {
        if (previousIndex === -1) {
          frontier.head = neighborIndex
        } else {
          next[previousIndex] = neighborIndex
        }
        previousNeighborIndex = previousIndex
        continue
      }
      if (!prepared[currentNeighborIndex]) {
        if (this.isPortReservedForDifferentNet(neighborPortId)) continue
        if (this.isPortOccupiedForDifferentNet(neighborPortId)) {
          continue
        }
        if (this.isRegionReservedForDifferentNet(nextRegionId)) continue
        nextRegionIds[currentNeighborIndex] = nextRegionId
        hopIds[currentNeighborIndex] = candidateHopId
        prepared[currentNeighborIndex] = 1
      }
      const previousBestCost = this.getCandidateBestCost(candidateHopId)
      if (currentCandidate.g >= previousBestCost) continue
      const lowerBoundWithoutDistance =
        currentCandidate.g +
        state.regionCongestionCost[currentCandidate.nextRegionId]! +
        (problem.portPenalty?.[neighborPortId] ?? 0)
      let knownSegmentDistance: number | undefined
      let lowerBoundCost = lowerBoundWithoutDistance
      if (this.ADD_SEGMENT_DISTANCE_TO_G) {
        const dx =
          topology.portX[currentCandidate.portId]! -
          topology.portX[neighborPortId]!
        const dy =
          topology.portY[currentCandidate.portId]! -
          topology.portY[neighborPortId]!
        knownSegmentDistance = Math.sqrt(dx * dx + dy * dy)
        lowerBoundCost += knownSegmentDistance * this.DISTANCE_TO_COST
      }
      if (lowerBoundCost >= previousBestCost) continue
      if (this.isHardBlockedSingleLayerHop(currentCandidate, neighborPortId)) {
        continue
      }
      const g = this.computeG(
        currentCandidate,
        neighborPortId,
        previousBestCost,
        knownSegmentDistance,
      )
      if (!Number.isFinite(g) || g >= previousBestCost) continue
      const h = this.computeH(neighborPortId)

      const newCandidate = {
        hopId: candidateHopId,
        prevRegionId: currentCandidate.nextRegionId,
        nextRegionId,
        portId: neighborPortId,
        g,
        h,
        f: g + h,
        prevCandidate: currentCandidate,
      }

      if (neighborPortId === state.goalPortId) {
        this.onPathFound(newCandidate)
        return
      }

      this.setCandidateBestCost(candidateHopId, g)
      state.candidateQueue.queue(newCandidate)
    }
  }

  resetCandidateBestCosts() {
    const { state } = this

    this.candidateOverflowBestCost?.clear()

    if (state.candidateBestCostGeneration === 0xffffffff) {
      if (state.candidateBestCostByHopId instanceof Map) {
        state.candidateBestCostByHopId.clear()
      }
      if (state.candidateBestCostGenerationByHopId instanceof Map) {
        state.candidateBestCostGenerationByHopId.clear()
      } else {
        state.candidateBestCostGenerationByHopId.fill(0)
      }
      state.candidateBestCostGeneration = 1
      return
    }

    state.candidateBestCostGeneration += 1
  }

  getCandidateBestCost(hopId: HopId) {
    if (hopId < 0) {
      return (
        this.candidateOverflowBestCost?.get(hopId) ?? Number.POSITIVE_INFINITY
      )
    }

    const { state } = this
    const bestCostGeneration = state.candidateBestCostGenerationByHopId

    return (bestCostGeneration instanceof Map
      ? bestCostGeneration.get(hopId)
      : bestCostGeneration[hopId]) === state.candidateBestCostGeneration
      ? state.candidateBestCostByHopId instanceof Map
        ? state.candidateBestCostByHopId.get(hopId)!
        : state.candidateBestCostByHopId[hopId]!
      : Number.POSITIVE_INFINITY
  }

  setCandidateBestCost(hopId: HopId, bestCost: number) {
    if (hopId < 0) {
      if (!this.candidateOverflowBestCost) {
        this.candidateOverflowBestCost = new Map()
      }
      this.candidateOverflowBestCost.set(hopId, bestCost)
      return
    }

    const { state } = this

    if (state.candidateBestCostGenerationByHopId instanceof Map) {
      state.candidateBestCostGenerationByHopId.set(
        hopId,
        state.candidateBestCostGeneration,
      )
    } else {
      state.candidateBestCostGenerationByHopId[hopId] =
        state.candidateBestCostGeneration
    }

    if (state.candidateBestCostByHopId instanceof Map) {
      state.candidateBestCostByHopId.set(hopId, bestCost)
    } else {
      state.candidateBestCostByHopId[hopId] = bestCost
    }
  }

  getHopId(portId: PortId, nextRegionId: RegionId): HopId {
    const baseHopId = portId * this.candidateHopSlotStride

    if (this.candidateFirstRegionByPortId[portId] === nextRegionId) {
      return baseHopId
    }
    if (this.candidateSecondRegionByPortId[portId] === nextRegionId) {
      return baseHopId + 1
    }

    const incidentRegionIds = this.topology.incidentPortRegion[portId]
    for (let slot = 2; slot < (incidentRegionIds?.length ?? 0); slot++) {
      if (incidentRegionIds![slot] === nextRegionId) return baseHopId + slot
    }

    // Preserve support for manually constructed/non-incident hops without
    // reserving dense storage for every impossible port/region combination.
    return -(portId * this.topology.regionCount + nextRegionId) - 1
  }

  getStartingNextRegionId(
    routeId: RouteId,
    startingPortId: PortId,
  ): RegionId | undefined {
    const startingIncidentRegions =
      this.topology.incidentPortRegion[startingPortId] ?? []
    const currentRouteNetId = this.problem.routeNet[routeId]
    if (isPortPhysicallyReservedForDifferentNet(this.problem.portReservationNetId, currentRouteNetId, startingPortId)) {
      return undefined
    }
    if (hasConflictingPortOwner(this.problem.portConflictOffsets, this.problem.portConflictPortIds,
        startingPortId, currentRouteNetId, this.problemSetup.portEndpointReservationNetId)) return undefined

    return (
      startingIncidentRegions.find(
        (regionId) => this.problem.regionNetId[regionId] === -1,
      ) ??
      startingIncidentRegions.find(
        (regionId) => this.problem.regionNetId[regionId] === currentRouteNetId,
      ) ??
      startingIncidentRegions[0]
    )
  }

  protected getRouteStartPortId(routeId: RouteId): PortId {
    return this.problem.routeStartPort[routeId]!
  }

  protected getRouteEndPortId(routeId: RouteId): PortId {
    return this.problem.routeEndPort[routeId]!
  }

  isPortReservedForDifferentNet(portId: PortId): boolean {
    if (isPortPhysicallyReservedForDifferentNet(this.problem.portReservationNetId, this.state.currentRouteNetId, portId)) {
      return true
    }
    const reservedNetId =
      this.problemSetup.portEndpointReservationNetId[portId] ?? -1
    return (
      reservedNetId === -2 ||
      (reservedNetId !== -1 && reservedNetId !== this.state.currentRouteNetId) ||
      hasConflictingPortOwner(this.problem.portConflictOffsets, this.problem.portConflictPortIds,
        portId, this.state.currentRouteNetId, this.problemSetup.portEndpointReservationNetId)
    )
  }

  /** Routed copper conflicts are rippable; fixed endpoint reservations are not. */
  isPortOccupiedForDifferentNet(portId: PortId): boolean {
    const assignedNetId = this.state.portAssignment[portId]
    return (assignedNetId !== -1 && assignedNetId !== this.state.currentRouteNetId) ||
      hasConflictingPortOwner(this.problem.portConflictOffsets, this.problem.portConflictPortIds,
        portId, this.state.currentRouteNetId, this.state.portAssignment)
  }

  isRegionReservedForDifferentNet(regionId: RegionId): boolean {
    const reservedNetId = this.problem.regionNetId[regionId]
    return (
      reservedNetId !== -1 && reservedNetId !== this.state.currentRouteNetId
    )
  }

  isKnownSingleLayerRegion(regionId: RegionId): boolean {
    const regionAvailableZMask =
      this.topology.regionAvailableZMask?.[regionId] ?? 0
    return isKnownSingleLayerMask(regionAvailableZMask)
  }

  private isHardBlockedSingleLayerHop(
    currentCandidate: Candidate,
    neighborPortId: PortId,
  ): boolean {
    const regionId = currentCandidate.nextRegionId
    if (!this.isKnownSingleLayerRegion(regionId)) return false
    const cache = this.state.regionIntersectionCaches[regionId]
    if (cache.existingSegmentCount === 0) return false
    const geometry = this.populateBaseSegmentGeometryScratch(
      regionId,
      currentCandidate.portId,
      neighborPortId,
    )
    setNewIntersectionCounts(cache, geometry)
    return geometry.sameLayerIntersectionCount > 0
  }

  protected computeRegionCostForRegion(
    regionId: RegionId,
    numSameLayerIntersections: number,
    numCrossLayerIntersections: number,
    numEntryExitChanges: number,
    traceCount: number,
  ): number {
    return computeRegionCost(
      this.topology.regionWidth[regionId],
      this.topology.regionHeight[regionId],
      numSameLayerIntersections,
      numCrossLayerIntersections,
      numEntryExitChanges,
      traceCount,
      this.topology.regionAvailableZMask?.[regionId] ?? 0,
      this.minViaPadDiameter,
      this.TRACE_DENSITY_COST_FACTOR,
    )
  }

  populateSegmentGeometryScratch(
    regionId: RegionId,
    port1Id: PortId,
    port2Id: PortId,
  ): SegmentGeometryScratch {
    return this.populateBaseSegmentGeometryScratch(regionId, port1Id, port2Id)
  }

  private populateBaseSegmentGeometryScratch(
    regionId: RegionId,
    port1Id: PortId,
    port2Id: PortId,
  ): SegmentGeometryScratch {
    const { state, topology } = this
    const scratch = this.segmentGeometryScratch
    const angle1 =
      this.candidateFirstRegionByPortId[port1Id] === regionId ||
      this.candidateSecondRegionByPortId[port1Id] !== regionId
        ? topology.portAngleForRegion1[port1Id]
        : (topology.portAngleForRegion2?.[port1Id] ??
          topology.portAngleForRegion1[port1Id])
    const angle2 =
      this.candidateFirstRegionByPortId[port2Id] === regionId ||
      this.candidateSecondRegionByPortId[port2Id] !== regionId
        ? topology.portAngleForRegion1[port2Id]
        : (topology.portAngleForRegion2?.[port2Id] ??
          topology.portAngleForRegion1[port2Id])
    const z1 = topology.portZ[port1Id]
    const z2 = topology.portZ[port2Id]
    scratch.lesserAngle = angle1 < angle2 ? angle1 : angle2
    scratch.greaterAngle = angle1 < angle2 ? angle2 : angle1
    scratch.layerMask = (1 << z1) | (1 << z2)
    scratch.entryExitLayerChanges = z1 !== z2 ? 1 : 0
    scratch.netId = state.currentRouteNetId!

    return scratch
  }

  appendSegmentToRegionCache(
    regionId: RegionId,
    port1Id: PortId,
    port2Id: PortId,
  ) {
    const { state } = this
    const regionCache = state.regionIntersectionCaches[regionId]
    const segmentGeometry = this.populateSegmentGeometryScratch(
      regionId,
      port1Id,
      port2Id,
    )
    setNewIntersectionCounts(regionCache, segmentGeometry)
    const newSameLayerIntersections = segmentGeometry.sameLayerIntersectionCount
    const newCrossLayerIntersections =
      segmentGeometry.crossingLayerIntersectionCount
    const newEntryExitLayerChanges = segmentGeometry.entryExitLayerChanges
    const nextLength = regionCache.netIds.length + 1

    const netIds = new Int32Array(nextLength)
    netIds.set(regionCache.netIds)
    netIds[nextLength - 1] = state.currentRouteNetId!

    const lesserAngles = new Int32Array(nextLength)
    lesserAngles.set(regionCache.lesserAngles)
    lesserAngles[nextLength - 1] = segmentGeometry.lesserAngle

    const greaterAngles = new Int32Array(nextLength)
    greaterAngles.set(regionCache.greaterAngles)
    greaterAngles[nextLength - 1] = segmentGeometry.greaterAngle

    const layerMasks = new Int32Array(nextLength)
    layerMasks.set(regionCache.layerMasks)
    layerMasks[nextLength - 1] = segmentGeometry.layerMask

    const existingSameLayerIntersections =
      regionCache.existingSameLayerIntersections + newSameLayerIntersections
    const existingCrossingLayerIntersections =
      regionCache.existingCrossingLayerIntersections +
      newCrossLayerIntersections
    const existingEntryExitLayerChanges =
      regionCache.existingEntryExitLayerChanges + newEntryExitLayerChanges
    const existingSegmentCount = lesserAngles.length

    state.regionIntersectionCaches[regionId] = {
      netIds,
      lesserAngles,
      greaterAngles,
      layerMasks,
      existingSameLayerIntersections,
      existingCrossingLayerIntersections,
      existingEntryExitLayerChanges,
      existingSegmentCount,
      existingRegionCost: this.computeRegionCostForRegion(
        regionId,
        existingSameLayerIntersections,
        existingCrossingLayerIntersections,
        existingEntryExitLayerChanges,
        existingSegmentCount,
      ),
    }
  }

  getSolvedPathSegments(finalCandidate: Candidate): Array<{
    regionId: RegionId
    fromPortId: PortId
    toPortId: PortId
  }> {
    const { state } = this
    const candidatePath: Candidate[] = []
    let cursor: Candidate | undefined = finalCandidate

    while (cursor) {
      candidatePath.unshift(cursor)
      cursor = cursor.prevCandidate
    }

    const solvedSegments: Array<{
      regionId: RegionId
      fromPortId: PortId
      toPortId: PortId
    }> = []

    for (let i = 1; i < candidatePath.length; i++) {
      solvedSegments.push({
        regionId: candidatePath[i - 1].nextRegionId,
        fromPortId: candidatePath[i - 1].portId,
        toPortId: candidatePath[i].portId,
      })
    }

    const lastCandidate = candidatePath[candidatePath.length - 1]
    if (lastCandidate && lastCandidate.portId !== state.goalPortId) {
      solvedSegments.push({
        regionId: lastCandidate.nextRegionId,
        fromPortId: lastCandidate.portId,
        toPortId: state.goalPortId,
      })
    }

    return solvedSegments
  }

  resetRoutingStateForRerip() {
    const { topology, problem, state } = this

    state.portAssignment.fill(-1)
    state.regionSegments = Array.from(
      { length: topology.regionCount },
      () => [],
    )
    state.regionIntersectionCaches = Array.from(
      { length: topology.regionCount },
      () => createEmptyRegionIntersectionCache(),
    )
    state.currentRouteNetId = undefined
    state.currentRouteId = undefined
    state.unroutedRoutes = shuffle(range(problem.routeCount), state.ripCount)
    state.candidateQueue.clear()
    this.resetCandidateBestCosts()
    state.goalPortId = -1
  }

  protected getMaxRegionCost() {
    const { topology, state } = this
    let maxRegionCost = 0

    for (let regionId = 0; regionId < topology.regionCount; regionId++) {
      const regionCost =
        state.regionIntersectionCaches[regionId]?.existingRegionCost ?? 0
      maxRegionCost = Math.max(maxRegionCost, regionCost)
    }

    return maxRegionCost
  }

  protected getRouteMetadata(routeId: RouteId):
    | {
        connectionId?: unknown
        startRegionId?: unknown
        endRegionId?: unknown
        simpleRouteConnection?: {
          pointsToConnect?: Array<{
            pointId?: unknown
          }>
        }
      }
    | undefined {
    return this.problem.routeMetadata?.[routeId] as
      | {
          connectionId?: unknown
          startRegionId?: unknown
          endRegionId?: unknown
          simpleRouteConnection?: {
            pointsToConnect?: Array<{
              pointId?: unknown
            }>
          }
        }
      | undefined
  }

  protected getRouteConnectionId(routeId: RouteId) {
    const connectionId = this.getRouteMetadata(routeId)?.connectionId
    return typeof connectionId === "string" ? connectionId : `route-${routeId}`
  }

  protected getRouteSummary(
    routeId: RouteId,
  ): StaticallyUnroutableRouteSummary {
    return createStaticallyUnroutableRouteSummary({
      problem: this.problem,
      routeId,
      getRouteMetadata: (currentRouteId) =>
        this.getRouteMetadata(currentRouteId),
      getRouteConnectionId: (currentRouteId) =>
        this.getRouteConnectionId(currentRouteId),
    })
  }

  getAdditionalRegionLabel(_regionId: RegionId): string | undefined {
    return undefined
  }

  getNeverSuccessfullyRoutedRoutes(): NeverSuccessfullyRoutedRouteSummary[] {
    const neverSuccessfullyRoutedRoutes: NeverSuccessfullyRoutedRouteSummary[] =
      []

    for (let routeId = 0; routeId < this.problem.routeCount; routeId++) {
      const attempts = this.routeAttemptCountByRouteId[routeId]!
      if (attempts === 0 || this.routeSuccessCountByRouteId[routeId]! > 0) {
        continue
      }

      neverSuccessfullyRoutedRoutes.push({
        ...this.getRouteSummary(routeId),
        attempts,
      })
    }

    return neverSuccessfullyRoutedRoutes
  }

  getStaticallyUnroutableRoutes(): StaticallyUnroutableRouteSummary[] {
    return this.staticallyUnroutableRoutes
  }

  protected logNeverSuccessfullyRoutedRoutes() {
    if (!this.VERBOSE || this.hasLoggedNeverSuccessfullyRoutedRoutes) {
      return
    }

    const neverSuccessfullyRoutedRoutes =
      this.getNeverSuccessfullyRoutedRoutes()
    this.hasLoggedNeverSuccessfullyRoutedRoutes = true

    if (neverSuccessfullyRoutedRoutes.length === 0) {
      return
    }

    console.log(
      [
        "[TinyHyperGraphSolver:never-routed-summary]",
        `count=${neverSuccessfullyRoutedRoutes.length}`,
      ].join(" "),
    )

    for (const neverSuccessfullyRoutedRoute of neverSuccessfullyRoutedRoutes) {
      const pointPath =
        neverSuccessfullyRoutedRoute.pointIds.length >= 2
          ? `${neverSuccessfullyRoutedRoute.pointIds[0]}->${neverSuccessfullyRoutedRoute.pointIds[1]}`
          : "unknown"

      console.log(
        [
          "[TinyHyperGraphSolver:never-routed]",
          `routeId=${neverSuccessfullyRoutedRoute.routeId}`,
          `connectionId=${neverSuccessfullyRoutedRoute.connectionId}`,
          `attempts=${neverSuccessfullyRoutedRoute.attempts}`,
          `pointPath=${pointPath}`,
          `startRegionId=${neverSuccessfullyRoutedRoute.startRegionId ?? "unknown"}`,
          `endRegionId=${neverSuccessfullyRoutedRoute.endRegionId ?? "unknown"}`,
        ].join(" "),
      )
    }
  }

  protected logRipEvent(
    reason: "hot_regions" | "out_of_candidates",
    maxRegionCostBeforeRip: number,
    extraFields: Record<string, string | number> = {},
  ) {
    if (!this.VERBOSE) {
      return
    }

    console.log(
      [
        "[TinyHyperGraphSolver:rip]",
        `ripCount=${this.state.ripCount}`,
        `maxRegionCostBeforeRip=${maxRegionCostBeforeRip.toFixed(3)}`,
        `reason=${reason}`,
        ...Object.entries(extraFields).map(
          ([key, value]) =>
            `${key}=${
              typeof value === "number"
                ? Number.isInteger(value)
                  ? String(value)
                  : value.toFixed(3)
                : value
            }`,
        ),
      ].join(" "),
    )
  }

  protected compareRegionCostSummaries(
    left: RegionCostSummary,
    right: RegionCostSummary,
  ) {
    if (left.maxRegionCost !== right.maxRegionCost) {
      return left.maxRegionCost - right.maxRegionCost
    }

    return left.totalRegionCost - right.totalRegionCost
  }

  protected captureBestSolvedState(summary: RegionCostSummary) {
    if (
      this.bestSolvedStateSummary &&
      this.compareRegionCostSummaries(summary, this.bestSolvedStateSummary) >= 0
    ) {
      return
    }

    this.replaceBestSolvedState(summary)
  }

  protected replaceBestSolvedState(summary: RegionCostSummary) {
    this.bestSolvedStateSummary = summary
    this.bestSolvedStateSnapshot = cloneSolvedStateSnapshot({
      portAssignment: this.state.portAssignment,
      regionSegments: this.state.regionSegments,
      regionIntersectionCaches: this.state.regionIntersectionCaches,
      regionCongestionCost: this.state.regionCongestionCost,
      ripCount: this.state.ripCount,
    })
  }

  protected restoreBestSolvedState() {
    if (!this.bestSolvedStateSnapshot) {
      return
    }

    const snapshot = cloneSolvedStateSnapshot(this.bestSolvedStateSnapshot)
    this.state.portAssignment = snapshot.portAssignment
    this.state.regionSegments = snapshot.regionSegments
    this.state.regionIntersectionCaches = snapshot.regionIntersectionCaches
    this.state.regionCongestionCost = snapshot.regionCongestionCost
    this.state.ripCount = snapshot.ripCount
    this.state.currentRouteId = undefined
    this.state.currentRouteNetId = undefined
    this.state.unroutedRoutes = []
    this.state.candidateQueue.clear()
    this.resetCandidateBestCosts()
    this.state.goalPortId = -1
  }

  protected getRemainingRouteIdsForGreedyFinalRoute(): RouteId[] {
    const routeIds = new Set<RouteId>(this.state.unroutedRoutes)

    if (this.state.currentRouteId !== undefined) {
      routeIds.add(this.state.currentRouteId)
    }

    return [...routeIds]
  }

  protected applySnapshotToGreedyFinalRouteSolver(
    solver: TinyHyperGraphSolver,
    snapshot: SolvedStateSnapshot,
    routeIds: RouteId[],
  ) {
    const clonedSnapshot = cloneSolvedStateSnapshot(snapshot)

    solver.state.portAssignment = clonedSnapshot.portAssignment
    solver.state.regionSegments = clonedSnapshot.regionSegments
    solver.state.regionIntersectionCaches =
      clonedSnapshot.regionIntersectionCaches
    solver.state.regionCongestionCost = clonedSnapshot.regionCongestionCost
    solver.state.ripCount = 0
    solver.state.currentRouteId = undefined
    solver.state.currentRouteNetId = undefined
    solver.state.unroutedRoutes = [...routeIds]
    solver.state.candidateQueue.clear()
    solver.resetCandidateBestCosts()
    solver.state.goalPortId = -1
  }

  protected summarizeSolvedState(
    solver: TinyHyperGraphSolver,
  ): RegionCostSummary {
    let maxRegionCost = 0
    let totalRegionCost = 0

    for (const regionIntersectionCache of solver.state
      .regionIntersectionCaches) {
      const regionCost = regionIntersectionCache.existingRegionCost
      maxRegionCost = Math.max(maxRegionCost, regionCost)
      totalRegionCost += regionCost
    }

    return {
      maxRegionCost,
      totalRegionCost,
    }
  }

  protected createGreedyFinalRouteSolver(
    options: TinyHyperGraphSolverOptions,
    _attempt: number,
  ): TinyHyperGraphSolver {
    return new GreedyFinalRouteSolver(this.topology, this.problem, options)
  }

  protected tryGreedyFinalRouteAcceptance(): boolean {
    const greedyFinalRouteIters = Math.max(
      0,
      Math.floor(this.GREEDY_FINAL_ROUTE_ITERS),
    )
    if (greedyFinalRouteIters === 0) {
      return false
    }

    let remainingRouteIds = this.getRemainingRouteIdsForGreedyFinalRoute()
    if (remainingRouteIds.length === 0) {
      return false
    }

    let startingSnapshot = cloneSolvedStateSnapshot({
      portAssignment: this.state.portAssignment,
      regionSegments: this.state.regionSegments,
      regionIntersectionCaches: this.state.regionIntersectionCaches,
      regionCongestionCost: this.state.regionCongestionCost,
      ripCount: this.state.ripCount,
    })

    let greedyFinalRouteMaxIterations = GREEDY_FINAL_ROUTE_MAX_ITERATIONS
    // Do not reset the rerip budget by opening a new cost-aware search after
    // the parent has already repeatedly rearranged the graph. Preserve the
    // existing greedy shuffle seeds when the extra candidate is skipped.
    for (
      let greedyFinalRouteIter =
        this.state.ripCount < this.costAwareFinalReripBudget ? -1 : 0;
      greedyFinalRouteIter < greedyFinalRouteIters;
      greedyFinalRouteIter++
    ) {
      const routeIds =
        greedyFinalRouteIter <= 0
          ? remainingRouteIds
          : shuffle(
              remainingRouteIds,
              this.state.ripCount + greedyFinalRouteIter,
            )
      const greedySolver = this.createGreedyFinalRouteSolver(
        {
          ...getTinyHyperGraphSolverOptions(this),
          ACCEPT_BEST_SOLUTION_ON_TIMEOUT: false,
          GREEDY_FINAL_ROUTE_ITERS: 0,
          MAX_ITERATIONS: GREEDY_FINAL_ROUTE_MAX_ITERATIONS,
          RIP_THRESHOLD_RAMP_ATTEMPTS: 0,
          STATIC_REACHABILITY_PRECHECK: false,
          OUTSIDE_IN_ROUTING: false,
          PARTIAL_RIP_ENABLED: false,
        },
        greedyFinalRouteIter,
      )
      greedyFinalRouteMaxIterations = greedySolver.MAX_ITERATIONS

      this.applySnapshotToGreedyFinalRouteSolver(
        greedySolver,
        startingSnapshot,
        routeIds,
      )
      greedySolver.solve()

      if (!greedySolver.solved || greedySolver.failed) {
        const candidateRemainingRouteIds =
          greedySolver.getRemainingRouteIdsForGreedyFinalRoute()
        if (candidateRemainingRouteIds.length < remainingRouteIds.length) {
          // Keep completed work when an attempt ends. Later passes only need
          // the remaining requests, including any reripped routes.
          startingSnapshot = cloneSolvedStateSnapshot({
            portAssignment: greedySolver.state.portAssignment,
            regionSegments: greedySolver.state.regionSegments,
            regionIntersectionCaches: greedySolver.state.regionIntersectionCaches,
            regionCongestionCost: greedySolver.state.regionCongestionCost,
            ripCount: greedySolver.state.ripCount,
          })
          remainingRouteIds = candidateRemainingRouteIds
        }
        continue
      }

      this.bestSolvedStateSnapshot = cloneSolvedStateSnapshot({
        portAssignment: greedySolver.state.portAssignment,
        regionSegments: greedySolver.state.regionSegments,
        regionIntersectionCaches: greedySolver.state.regionIntersectionCaches,
        regionCongestionCost: greedySolver.state.regionCongestionCost,
        ripCount: greedySolver.state.ripCount,
      })
      this.bestSolvedStateSummary = this.summarizeSolvedState(greedySolver)
      this.restoreBestSolvedState()
      this.stats = {
        ...this.stats,
        acceptedGreedyFinalRouteOnTimeout: true,
        greedyFinalRouteIter: Math.max(0, greedyFinalRouteIter),
        finalRoutingStrategy:
          greedyFinalRouteIter < 0 ? "congestion-aware" : "greedy",
        greedyFinalRouteRemainingRouteCount: remainingRouteIds.length,
        greedyFinalRouteMaxIterations,
        neverSuccessfullyRoutedRouteCount: 0,
        maxRegionCost: this.bestSolvedStateSummary.maxRegionCost,
        totalRegionCost: this.bestSolvedStateSummary.totalRegionCost,
        bestMaxRegionCost: this.bestSolvedStateSummary.maxRegionCost,
        bestTotalRegionCost: this.bestSolvedStateSummary.totalRegionCost,
      }
      this.solved = true
      this.failed = false
      this.error = null
      return true
    }

    this.stats = {
      ...this.stats,
      greedyFinalRouteAttemptCount: greedyFinalRouteIters,
      greedyFinalRouteRemainingRouteCount: remainingRouteIds.length,
      greedyFinalRouteMaxIterations,
    }

    return false
  }

  onAllRoutesRouted() {
    const { topology, state } = this
    const ripThresholdProgress =
      this.RIP_THRESHOLD_RAMP_ATTEMPTS <= 0
        ? 1
        : Math.min(1, state.ripCount / this.RIP_THRESHOLD_RAMP_ATTEMPTS)
    const currentRipThreshold =
      this.RIP_THRESHOLD_START +
      (this.RIP_THRESHOLD_END - this.RIP_THRESHOLD_START) * ripThresholdProgress

    const regionIdsOverCostThreshold: RegionId[] = []
    const regionCosts = new Float64Array(topology.regionCount)
    let maxRegionCost = 0
    let totalRegionCost = 0

    for (let regionId = 0; regionId < topology.regionCount; regionId++) {
      const regionCost =
        state.regionIntersectionCaches[regionId]?.existingRegionCost ?? 0
      regionCosts[regionId] = regionCost
      maxRegionCost = Math.max(maxRegionCost, regionCost)
      totalRegionCost += regionCost

      if (regionCost > currentRipThreshold) {
        regionIdsOverCostThreshold.push(regionId)
      }
    }

    const summary = { maxRegionCost, totalRegionCost }
    const shouldFinish =
      regionIdsOverCostThreshold.length === 0 ||
      state.ripCount >= this.RIP_THRESHOLD_RAMP_ATTEMPTS
    if (shouldFinish) {
      if (
        !this.bestSolvedStateSummary ||
        this.compareRegionCostSummaries(summary, this.bestSolvedStateSummary) <
          0
      ) {
        this.bestSolvedStateSummary = summary
      }
    } else {
      this.captureBestSolvedState(summary)
    }

    this.stats = {
      ...this.stats,
      currentRipThreshold,
      hotRegionCount: regionIdsOverCostThreshold.length,
      maxRegionCost,
      totalRegionCost,
      bestMaxRegionCost: this.bestSolvedStateSummary?.maxRegionCost,
      bestTotalRegionCost: this.bestSolvedStateSummary?.totalRegionCost,
      ripCount: state.ripCount,
    }

    if (shouldFinish) {
      this.solved = true
      return
    }

    for (let regionId = 0; regionId < topology.regionCount; regionId++) {
      state.regionCongestionCost[regionId] +=
        regionCosts[regionId] * this.RIP_CONGESTION_REGION_COST_FACTOR
    }

    state.ripCount += 1
    this.resetRoutingStateForRerip()
    this.stats = {
      ...this.stats,
      ripCount: state.ripCount,
      maxRegionCostBeforeRip: maxRegionCost,
      reripRegionCount: regionIdsOverCostThreshold.length,
    }
    this.logRipEvent("hot_regions", maxRegionCost, {
      hotRegionCount: regionIdsOverCostThreshold.length,
      currentRipThreshold,
    })
  }

  onOutOfCandidates() {
    const { topology, state } = this
    const currentRouteId = state.currentRouteId
    const maxRegionCostBeforeRip = this.getMaxRegionCost()

    for (let regionId = 0; regionId < topology.regionCount; regionId++) {
      const regionCost =
        state.regionIntersectionCaches[regionId]?.existingRegionCost ?? 0
      state.regionCongestionCost[regionId] +=
        regionCost * this.RIP_CONGESTION_REGION_COST_FACTOR
    }

    state.ripCount += 1
    this.resetRoutingStateForRerip()
    this.stats = {
      ...this.stats,
      ripCount: state.ripCount,
      maxRegionCost: maxRegionCostBeforeRip,
      maxRegionCostBeforeRip,
      reripReason: "out_of_candidates",
    }
    this.logRipEvent("out_of_candidates", maxRegionCostBeforeRip, {
      ...(currentRouteId === undefined
        ? {}
        : {
            routeId: currentRouteId,
            connectionId: this.getRouteConnectionId(currentRouteId),
          }),
    })
  }

  onPathFound(finalCandidate: Candidate) {
    const { state } = this
    const currentRouteId = state.currentRouteId

    if (currentRouteId === undefined) return
    const solvedSegments = this.getSolvedPathSegments(finalCandidate)
    if (this.problem.portConflictOffsets !== undefined) {
      for (const { fromPortId, toPortId } of solvedSegments) {
        for (const portId of [fromPortId, toPortId]) {
          if (this.isPortReservedForDifferentNet(portId) || this.isPortOccupiedForDifferentNet(portId)) {
            throw new Error(`Committed path port ${portId} conflicts with foreign physical copper`)
          }
        }
      }
    }
    this.routeSuccessCountByRouteId[currentRouteId] += 1

    for (const { regionId, fromPortId, toPortId } of solvedSegments) {
      state.regionSegments[regionId].push([
        currentRouteId,
        fromPortId,
        toPortId,
      ])
      state.portAssignment[fromPortId] = state.currentRouteNetId!
      state.portAssignment[toPortId] = state.currentRouteNetId!
      this.appendSegmentToRegionCache(regionId, fromPortId, toPortId)
    }

    state.candidateQueue.clear()
    state.currentRouteNetId = undefined
    state.currentRouteId = undefined
  }

  computeG(
    currentCandidate: Candidate,
    neighborPortId: PortId,
    maximumCost = Number.POSITIVE_INFINITY,
    knownSegmentDistance?: number,
  ): number {
    const { state, topology } = this

    if (this.problem.portConflictOffsets !== undefined &&
        (this.isPortReservedForDifferentNet(neighborPortId) || this.isPortOccupiedForDifferentNet(neighborPortId))) {
      return Number.POSITIVE_INFINITY
    }

    const nextRegionId = currentCandidate.nextRegionId

    const regionCache = state.regionIntersectionCaches[nextRegionId]
    const regionCongestionCost = state.regionCongestionCost[nextRegionId]!
    const neighborPortPenalty = this.problem.portPenalty?.[neighborPortId] ?? 0
    let segmentDistanceCost = 0
    if (this.ADD_SEGMENT_DISTANCE_TO_G) {
      let segmentDistance = knownSegmentDistance
      if (segmentDistance === undefined) {
        const dx =
          topology.portX[currentCandidate.portId]! -
          topology.portX[neighborPortId]!
        const dy =
          topology.portY[currentCandidate.portId]! -
          topology.portY[neighborPortId]!
        segmentDistance = Math.sqrt(dx * dx + dy * dy)
      }
      segmentDistanceCost = segmentDistance * this.DISTANCE_TO_COST
    }
    const lowerBoundCost =
      currentCandidate.g +
      regionCongestionCost +
      neighborPortPenalty +
      segmentDistanceCost
    if (lowerBoundCost > maximumCost + 1e-9) {
      return Number.POSITIVE_INFINITY
    }
    let newSameLayerIntersections = 0
    let newCrossLayerIntersections = 0
    let newEntryExitLayerChanges =
      topology.portZ[currentCandidate.portId] !== topology.portZ[neighborPortId]
        ? 1
        : 0
    if (regionCache.existingSegmentCount > 0) {
      // Candidate scoring uses topology angles even when a subclass supplies
      // different geometry for inserting completed segments.
      const segmentGeometry = this.populateBaseSegmentGeometryScratch(
        nextRegionId,
        currentCandidate.portId,
        neighborPortId,
      )
      setNewIntersectionCounts(regionCache, segmentGeometry)
      newSameLayerIntersections = segmentGeometry.sameLayerIntersectionCount
      newCrossLayerIntersections =
        segmentGeometry.crossingLayerIntersectionCount
      newEntryExitLayerChanges = segmentGeometry.entryExitLayerChanges
    }

    if (
      newSameLayerIntersections > 0 &&
      this.isKnownSingleLayerRegion(nextRegionId)
    ) {
      return Number.POSITIVE_INFINITY
    }

    const newRegionCost =
      this.computeRegionCostForRegion(
        nextRegionId,
        regionCache.existingSameLayerIntersections + newSameLayerIntersections,
        regionCache.existingCrossingLayerIntersections +
          newCrossLayerIntersections,
        regionCache.existingEntryExitLayerChanges + newEntryExitLayerChanges,
        regionCache.existingSegmentCount + 1,
      ) - regionCache.existingRegionCost

    return (
      currentCandidate.g +
      newRegionCost +
      regionCongestionCost +
      neighborPortPenalty +
      segmentDistanceCost
    )
  }

  override tryFinalAcceptance() {
    const neverSuccessfullyRoutedRoutes =
      this.getNeverSuccessfullyRoutedRoutes()

    this.stats = {
      ...this.stats,
      neverSuccessfullyRoutedRouteCount: neverSuccessfullyRoutedRoutes.length,
    }

    if (
      this.ACCEPT_BEST_SOLUTION_ON_TIMEOUT &&
      this.bestSolvedStateSnapshot &&
      this.bestSolvedStateSummary
    ) {
      this.restoreBestSolvedState()
      this.stats = {
        ...this.stats,
        acceptedBestSolutionOnTimeout: true,
        maxRegionCost: this.bestSolvedStateSummary.maxRegionCost,
        totalRegionCost: this.bestSolvedStateSummary.totalRegionCost,
        bestMaxRegionCost: this.bestSolvedStateSummary.maxRegionCost,
        bestTotalRegionCost: this.bestSolvedStateSummary.totalRegionCost,
      }
      this.solved = true
      this.failed = false
      this.error = null
      return
    }

    if (
      this.ACCEPT_BEST_SOLUTION_ON_TIMEOUT &&
      this.tryGreedyFinalRouteAcceptance()
    ) {
      return
    }

    this.logNeverSuccessfullyRoutedRoutes()
  }

  protected getRouteHeuristic(routeId: RouteId, portId: PortId): number {
    const precomputedHCost = this.problemSetup.portHCostToEndOfRoute
    if (precomputedHCost) {
      return precomputedHCost[portId * this.problem.routeCount + routeId]
    }

    if (this.hCostEndRouteId !== routeId) {
      this.hCostEndRouteId = routeId
      const endPortId = this.getRouteEndPortId(routeId)
      this.hCostEndX = this.topology.portX[endPortId]!
      this.hCostEndY = this.topology.portY[endPortId]!
    }
    if (this.hCostRouteIdByPortId[portId] !== routeId) {
      const dx = this.topology.portX[portId]! - this.hCostEndX
      const dy = this.topology.portY[portId]! - this.hCostEndY
      this.hCostByPortId[portId] =
        Math.sqrt(dx * dx + dy * dy) * this.DISTANCE_TO_COST
      this.hCostRouteIdByPortId[portId] = routeId
    }
    return this.hCostByPortId[portId]!
  }

  computeH(neighborPortId: PortId): number {
    return this.getRouteHeuristic(this.state.currentRouteId!, neighborPortId)
  }

  override visualize(): GraphicsObject {
    return visualizeTinyGraph(this)
  }

  override getOutput() {
    return convertToSerializedHyperGraph(this)
  }
}

class GreedyFinalRouteSolver extends TinyHyperGraphSolver {
  override computeG(
    currentCandidate: Candidate,
    _neighborPortId: PortId,
  ): number {
    return currentCandidate.g
  }
}
