/** Validate an immutable, symmetric CSR with strictly ascending conflict rows. */
export function validatePortConflicts(
  offsets: Int32Array | undefined,
  ids: Int32Array | undefined,
  portCount: number,
): void {
  if (offsets === undefined && ids === undefined) return
  if (!(offsets instanceof Int32Array) || !(ids instanceof Int32Array) || offsets.length !== portCount + 1) {
    throw new Error("Port conflicts require both Int32Array fields and portCount + 1 offsets")
  }
  if (offsets[0] !== 0 || offsets[portCount] !== ids.length) {
    throw new Error("Port conflict offsets must span the complete conflict array")
  }
  for (let port = 0; port < portCount; port++) {
    const start = offsets[port]!, end = offsets[port + 1]!
    if (start < 0 || end < start || end > ids.length) {
      throw new Error(`Invalid conflict offsets at port ${port}`)
    }
    let previous = -1
    for (let index = start; index < end; index++) {
      const other = ids[index]!
      if (other < 0 || other >= portCount || other === port || other <= previous) {
        throw new Error(`Invalid or unsorted conflict port ${other} at port ${port}`)
      }
      previous = other
    }
  }
  for (let port = 0; port < portCount; port++) {
    for (let index = offsets[port]!; index < offsets[port + 1]!; index++) {
      const other = ids[index]!
      let lower = offsets[other]!, upper = offsets[other + 1]! - 1
      while (lower <= upper) {
        const middle = lower + ((upper - lower) >> 1)
        const value = ids[middle]!
        if (value === port) break
        if (value < port) lower = middle + 1
        else upper = middle - 1
      }
      if (lower > upper) throw new Error(`Asymmetric port conflict ${port} -> ${other}`)
    }
  }
}

/** Checks actual assigned/terminal owners; physical access eligibility is separate. */
export function hasConflictingPortOwner(
  offsets: Int32Array | undefined,
  ids: Int32Array | undefined,
  portId: number,
  netId: number | undefined,
  ownerByPort: ArrayLike<number | undefined>,
): boolean {
  if (offsets === undefined && ids === undefined) return false
  if (!(offsets instanceof Int32Array) || !(ids instanceof Int32Array)) {
    throw new Error("Port conflicts require both Int32Array fields")
  }
  if (!Number.isInteger(portId) || portId < 0 || portId >= offsets.length - 1) {
    throw new Error(`Invalid conflict lookup port ${portId}`)
  }
  for (let index = offsets[portId]!; index < offsets[portId + 1]!; index++) {
    const owner = ownerByPort[ids[index]!]
    if (owner === -2 || (owner !== undefined && owner !== -1 && owner !== netId)) return true
  }
  return false
}

/** Reject an incompatible complete seed batch before its first state mutation. */
export function assertPortConflictAssignments(
  offsets: Int32Array | undefined,
  ids: Int32Array | undefined,
  assignments: Iterable<readonly [number, number]>,
  assignedOwners: ArrayLike<number | undefined>,
  endpointOwners: ArrayLike<number | undefined>,
): void {
  if (offsets === undefined && ids === undefined) return
  if (!(offsets instanceof Int32Array) || !(ids instanceof Int32Array)) {
    throw new Error("Port conflicts require both Int32Array fields")
  }
  const plannedOwners = new Map<number, number>()
  for (const [port, net] of assignments) {
    const prior = plannedOwners.get(port)
    if (prior !== undefined && prior !== net) throw new Error(`Seed port ${port} has different net owners`)
    plannedOwners.set(port, net)
  }
  for (const [port, net] of plannedOwners) {
    const assigned = assignedOwners[port]
    if ((assigned !== undefined && assigned !== -1 && assigned !== net) ||
        hasConflictingPortOwner(offsets, ids, port, net, assignedOwners) ||
        hasConflictingPortOwner(offsets, ids, port, net, endpointOwners)) {
      throw new Error(`Seed port ${port} conflicts with a different assigned or endpoint net`)
    }
    for (let index = offsets[port]!; index < offsets[port + 1]!; index++) {
      const other = ids[index]!, owner = plannedOwners.get(other)
      if (owner !== undefined && owner !== net) {
        throw new Error(`Seed ports ${port} and ${other} conflict between different nets`)
      }
    }
  }
}
