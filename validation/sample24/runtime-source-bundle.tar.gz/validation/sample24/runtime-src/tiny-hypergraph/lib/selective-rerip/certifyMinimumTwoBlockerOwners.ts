/** Optional lower-bound proof only. Unknown leaves the original weighted search unchanged. */
export type State = { portId: number; nextRegionId: number }
export type Hop = { state: State; distance: number; owners: readonly number[] }
export type Context<K> = {
  goalPortId: number
  /** Must identify the exact (portId,nextRegionId) state, as native getHopId does. */
  getStateKey(state: State): K
  isKnownSingleLayerRegion(regionId: number): boolean
  isRegionReservedForDifferentNet(regionId: number): boolean
  getPortPosition(portId: number): { x: number; y: number }
  getHops(state: State): readonly Hop[]
  /** Multilayer exit states/owners depend only on destination; includes entry. */
  getHopTemplates(state: State): readonly Hop[]
}
export type Certificate = {
  kind: "certified"
  minimumOwnerCount: 2
  work: number
  expandedStates: number
  inspectedHops: number
  inspectedOwnerEntries: number
  ownerFreeStates: number
  candidateOwners: number[]
  checkedOwners: number
} | {
  kind: "unknown"
  reason: "budget" | "invalid" | "owner-free-goal" | "one-owner-goal"
  work: number
  expandedStates: number
  inspectedHops: number
  inspectedOwnerEntries: number
  ownerFreeStates: number
  candidateOwners: number[]
  checkedOwners: number
}

/**
 * Hops, masks, reservations and occupancy must remain fixed, exactly as for the
 * weighted search. Work is an aggregate budget across closure and all owners:
 * one unit per expanded state, inspected hop or owner entry. No weighted budget is consumed.
 * Provider allocations are outside this helper; multilayer templates avoid the
 * original clique. Incomplete/invalid proofs do not reject a path or alter errors.
 */
export function certifyMinimumTwoBlockerOwners<K>(
  input: { start: State; maxWork: number },
  context: Context<K>,
): Certificate {
  let work = 0, expandedStates = 0, inspectedHops = 0, inspectedOwnerEntries = 0, checkedOwners = 0
  let invalid = false, exhausted = false, totalDistance = 0
  const free = new Map<K, State>()
  const firstExits = new Map<number, Map<K, State>>()
  const metrics = () => ({ work, expandedStates, inspectedHops, inspectedOwnerEntries, ownerFreeStates: free.size,
    candidateOwners: [...firstExits.keys()], checkedOwners })
  const unknown = (reason: "budget" | "invalid" | "owner-free-goal" | "one-owner-goal"): Certificate =>
    ({ kind: "unknown", reason, ...metrics() })
  if (!Number.isSafeInteger(input.maxWork) || input.maxWork < 0) return unknown("invalid")
  const spend = (hop: boolean): boolean => {
    if (work >= input.maxWork) { exhausted = true; return false }
    work++
    if (hop) inspectedHops++; else expandedStates++
    return true
  }
  // Distinct owners, including duplicate occurrences of the same owner.
  const ownerClass = (owners: readonly number[]): number | null | undefined => {
    let single: number | undefined, multiple = false
    for (const owner of owners) {
      if (work >= input.maxWork) { exhausted = true; return undefined }
      work++; inspectedOwnerEntries++
      if (!Number.isSafeInteger(owner) || owner < 0) { invalid = true; return undefined }
      if (single === undefined) single = owner
      else if (single !== owner) multiple = true
    }
    return multiple ? null : single
  }
  const expand = (
    state: State,
    entriesByRegion: Map<number, number[]>,
    visit: (hop: Hop) => void,
  ): void => {
    if (!spend(false)) return
    if (context.isRegionReservedForDifferentNet(state.nextRegionId)) return
    const singleLayer = context.isKnownSingleLayerRegion(state.nextRegionId)
    if (!singleLayer) {
      const entries = entriesByRegion.get(state.nextRegionId) ?? []
      if (entries.includes(state.portId) || entries.length >= 2) return
      entries.push(state.portId)
      entriesByRegion.set(state.nextRegionId, entries)
    }
    const hops = singleLayer ? context.getHops(state) : context.getHopTemplates(state)
    for (const template of hops) {
      if (!singleLayer && template.state.portId === state.portId) continue
      if (!spend(true)) return
      if (!Number.isSafeInteger(template.state.portId) || template.state.portId < 0
          || !Number.isSafeInteger(template.state.nextRegionId) || template.state.nextRegionId < 0) { invalid = true; return }
      let distance = template.distance
      if (!singleLayer) {
        const from = context.getPortPosition(state.portId), to = context.getPortPosition(template.state.portId)
        distance = Math.hypot(from.x - to.x, from.y - to.y)
      }
      totalDistance += distance
      if (!Number.isFinite(distance) || distance < 0 || !Number.isFinite(totalDistance)) {
        invalid = true; return
      }
      visit(template)
      if (invalid || exhausted) return
    }
  }
  const validState = (state: State): boolean => Number.isSafeInteger(state.portId) && state.portId >= 0
    && Number.isSafeInteger(state.nextRegionId) && state.nextRegionId >= 0
  if (!validState(input.start) || !Number.isSafeInteger(context.goalPortId) || context.goalPortId < 0) return unknown("invalid")
  const queue = [input.start]
  free.set(context.getStateKey(input.start), input.start)
  const freeEntries = new Map<number, number[]>()
  for (let index = 0; index < queue.length; index++) {
    const state = queue[index]!
    if (state.portId === context.goalPortId) return unknown("owner-free-goal")
    expand(state, freeEntries, hop => {
      const owner = ownerClass(hop.owners)
      if (invalid || exhausted || owner === null) return
      const key = context.getStateKey(hop.state)
      if (owner === undefined) {
        if (!free.has(key)) { free.set(key, hop.state); queue.push(hop.state) }
      } else {
        const exits = firstExits.get(owner) ?? new Map<K, State>()
        exits.set(key, hop.state)
        firstExits.set(owner, exits)
      }
    })
    if (invalid || exhausted) return unknown(invalid ? "invalid" : "budget")
  }
  // Every <=1-owner path must first leave the completed free closure through
  // a singleton {r} hop. Seed every such exit; re-entering free states needs no
  // repeat expansion because their r-exits were already seeded. Each owner has
  // independent visited states and multilayer entry counters. No distance labels.
  for (const [owner, seeds] of firstExits) {
    const visited = new Set<K>()
    const ownedQueue: State[] = []
    const enqueue = (state: State): void => {
      const key = context.getStateKey(state)
      if (free.has(key) || visited.has(key)) return
      visited.add(key); ownedQueue.push(state)
    }
    for (const state of seeds.values()) enqueue(state)
    const ownedEntries = new Map<number, number[]>()
    for (let index = 0; index < ownedQueue.length; index++) {
      const state = ownedQueue[index]!
      if (state.portId === context.goalPortId) return unknown("one-owner-goal")
      expand(state, ownedEntries, hop => {
        const nextOwner = ownerClass(hop.owners)
        if (invalid || exhausted || nextOwner === null || (nextOwner !== undefined && nextOwner !== owner)) return
        enqueue(hop.state)
      })
      if (invalid || exhausted) return unknown(invalid ? "invalid" : "budget")
    }
    checkedOwners++
  }
  return { kind: "certified", minimumOwnerCount: 2, ...metrics() }
}
