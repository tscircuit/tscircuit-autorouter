export type DistinctOwnerBlockerHop<TState, TOwner, THopData = unknown> = {
  state: TState
  distance: number
  owners?: readonly TOwner[]
  data?: THopData
}

export type DistinctOwnerBlockerSearchOptions<
  TState,
  TStateKey,
  TOwner,
  THopData = unknown,
> = {
  start: TState
  getStateKey: (state: TState) => TStateKey
  isGoal: (state: TState) => boolean
  getHops: (
    state: TState,
  ) => Iterable<DistinctOwnerBlockerHop<TState, TOwner, THopData>>
  maxExpandedLabels?: number
  /** Reject disconnected graphs before enumerating owner sets. Hops must be stable during the search. */
  checkReachability?: boolean
  /** Certified lower bound from the caller's blocker analysis; defaults to zero. */
  minimumOwnerCount?: number
  /** An admissible, finite, non-negative lower bound; must be zero at goals. */
  getRemainingDistance?: (state: TState) => number
}

export type DistinctOwnerBlockerSearchSuccess<
  TState,
  TOwner,
  THopData = unknown,
> = {
  found: true
  states: TState[]
  hops: Array<DistinctOwnerBlockerHop<TState, TOwner, THopData>>
  owners: ReadonlySet<TOwner>
  distance: number
  expandedLabelCount: number
}

export type DistinctOwnerBlockerSearchFailure = {
  found: false
  reason: "no_path" | "expansion_limit"
  expandedLabelCount: number
}

export type DistinctOwnerBlockerSearchResult<
  TState,
  TOwner,
  THopData = unknown,
> =
  | DistinctOwnerBlockerSearchSuccess<TState, TOwner, THopData>
  | DistinctOwnerBlockerSearchFailure

type SearchLabel<TState, TStateKey, TOwner, THopData> = {
  state: TState
  stateKey: TStateKey
  owners: Set<TOwner>
  priorityOwnerCount: number
  distance: number
  estimatedTotalDistance: number
  parent: SearchLabel<TState, TStateKey, TOwner, THopData> | null
  incomingHop: DistinctOwnerBlockerHop<TState, TOwner, THopData> | null
  queueOrder: number
  active: boolean
}

const compareLabels = <TState, TStateKey, TOwner, THopData>(
  left: SearchLabel<TState, TStateKey, TOwner, THopData>,
  right: SearchLabel<TState, TStateKey, TOwner, THopData>,
): number => {
  const ownerCountDifference =
    left.priorityOwnerCount - right.priorityOwnerCount
  if (ownerCountDifference !== 0) return ownerCountDifference

  const distanceDifference =
    left.estimatedTotalDistance - right.estimatedTotalDistance
  if (distanceDifference !== 0) return distanceDifference

  return left.queueOrder - right.queueOrder
}

class SearchLabelQueue<TState, TStateKey, TOwner, THopData> {
  private readonly heap: Array<
    SearchLabel<TState, TStateKey, TOwner, THopData>
  > = []
  private pushesUntilCompaction = 4096

  push(label: SearchLabel<TState, TStateKey, TOwner, THopData>): void {
    if (--this.pushesUntilCompaction === 0) this.compactInactiveLabels()
    this.heap.push(label)
    let index = this.heap.length - 1

    while (index > 0) {
      const parentIndex = Math.floor((index - 1) / 2)
      if (compareLabels(this.heap[parentIndex]!, this.heap[index]!) <= 0) {
        break
      }
      ;[this.heap[parentIndex], this.heap[index]] = [
        this.heap[index]!,
        this.heap[parentIndex]!,
      ]
      index = parentIndex
    }
  }

  private compactInactiveLabels(): void {
    const previousLength = this.heap.length
    let length = 0
    for (let index = 0; index < previousLength; index++) {
      const label = this.heap[index]!
      if (label.active) this.heap[length++] = label
    }
    this.heap.length = length

    if (length < previousLength) {
      // Filtering can move children before parents. Rebuild with the same
      // comparator, preserving every active label and its path references.
      for (let root = Math.floor(length / 2) - 1; root >= 0; root--) {
        let index = root
        while (true) {
          const left = index * 2 + 1
          const right = left + 1
          let best = index
          if (
            left < length &&
            compareLabels(this.heap[left]!, this.heap[best]!) < 0
          ) best = left
          if (
            right < length &&
            compareLabels(this.heap[right]!, this.heap[best]!) < 0
          ) best = right
          if (best === index) break
          ;[this.heap[index], this.heap[best]] = [
            this.heap[best]!,
            this.heap[index]!,
          ]
          index = best
        }
      }
    }
    // Fix the next interval now so a growing heap cannot postpone the scan.
    this.pushesUntilCompaction = Math.max(4096, length)
  }

  pop(): SearchLabel<TState, TStateKey, TOwner, THopData> | null {
    const first = this.heap[0]
    const last = this.heap.pop()
    if (!first || !last) return null
    if (this.heap.length === 0) return first

    this.heap[0] = last
    let index = 0
    while (true) {
      const leftIndex = index * 2 + 1
      const rightIndex = leftIndex + 1
      let bestIndex = index
      if (
        leftIndex < this.heap.length &&
        compareLabels(this.heap[leftIndex]!, this.heap[bestIndex]!) < 0
      ) {
        bestIndex = leftIndex
      }
      if (
        rightIndex < this.heap.length &&
        compareLabels(this.heap[rightIndex]!, this.heap[bestIndex]!) < 0
      ) {
        bestIndex = rightIndex
      }
      if (bestIndex === index) break
      ;[this.heap[index], this.heap[bestIndex]] = [
        this.heap[bestIndex]!,
        this.heap[index]!,
      ]
      index = bestIndex
    }

    return first
  }
}

const isOwnerSubset = <TOwner>(
  possibleSubset: ReadonlySet<TOwner>,
  possibleSuperset: ReadonlySet<TOwner>,
): boolean => {
  if (possibleSubset.size > possibleSuperset.size) return false
  for (const owner of possibleSubset) {
    if (!possibleSuperset.has(owner)) return false
  }

  return true
}

const isOwnerSubsetOfUnion = <TOwner>(
  subset: ReadonlySet<TOwner>,
  existing: ReadonlySet<TOwner>,
  added: readonly TOwner[],
): boolean => {
  if (subset === existing) return true
  if (subset.size > existing.size + added.length) return false
  for (const owner of subset) {
    if (!existing.has(owner) && !added.includes(owner)) return false
  }
  return true
}

const labelDominates = <TState, TStateKey, TOwner, THopData>(
  left: SearchLabel<TState, TStateKey, TOwner, THopData>,
  right: SearchLabel<TState, TStateKey, TOwner, THopData>,
): boolean => {
  if (left.distance > right.distance) return false
  return isOwnerSubset(left.owners, right.owners)
}

const reconstructSuccessfulSearch = <TState, TStateKey, TOwner, THopData>(
  goal: SearchLabel<TState, TStateKey, TOwner, THopData>,
  expandedLabelCount: number,
): DistinctOwnerBlockerSearchSuccess<TState, TOwner, THopData> => {
  const states: TState[] = []
  const hops: Array<DistinctOwnerBlockerHop<TState, TOwner, THopData>> = []
  let cursor: SearchLabel<TState, TStateKey, TOwner, THopData> | null = goal
  while (cursor !== null) {
    states.push(cursor.state)
    if (cursor.incomingHop !== null) hops.push(cursor.incomingHop)
    cursor = cursor.parent
  }

  states.reverse()
  hops.reverse()
  return {
    found: true,
    states,
    hops,
    owners: new Set(goal.owners),
    distance: goal.distance,
    expandedLabelCount,
  }
}

const getNextActiveLabel = <TState, TStateKey, TOwner, THopData>(
  queue: SearchLabelQueue<TState, TStateKey, TOwner, THopData>,
): SearchLabel<TState, TStateKey, TOwner, THopData> | null => {
  while (true) {
    const label = queue.pop()
    if (label === null) return null
    if (label.active) return label
  }
}

const findDisconnectedSearch = <TState, TStateKey, TOwner, THopData>(
  options: DistinctOwnerBlockerSearchOptions<
    TState,
    TStateKey,
    TOwner,
    THopData
  >,
  maxExpandedStates: number,
): DistinctOwnerBlockerSearchFailure | undefined => {
  const queue = [options.start]
  const seenStateKeys = new Set([options.getStateKey(options.start)])
  let expandedStateCount = 0
  let totalHopDistance = 0

  for (let queueIndex = 0; queueIndex < queue.length; queueIndex++) {
    const state = queue[queueIndex]!
    if (options.isGoal(state)) return undefined
    // An incomplete precheck cannot rule out a path. Keep the original search
    // and its label budget when this traversal reaches the same work limit.
    if (expandedStateCount >= maxExpandedStates) return undefined
    expandedStateCount++

    for (const hop of options.getHops(state)) {
      totalHopDistance += hop.distance
      // Preserve the weighted search's validation and overflow behavior.
      if (hop.distance < 0 || !Number.isFinite(totalHopDistance)) {
        return undefined
      }
      const stateKey = options.getStateKey(hop.state)
      if (seenStateKeys.has(stateKey)) continue
      seenStateKeys.add(stateKey)
      queue.push(hop.state)
    }
  }

  return {
    found: false,
    reason: "no_path",
    expandedLabelCount: expandedStateCount,
  }
}

export const findDistinctOwnerBlockerPath = <
  TState,
  TStateKey,
  TOwner,
  THopData = unknown,
>(
  options: DistinctOwnerBlockerSearchOptions<
    TState,
    TStateKey,
    TOwner,
    THopData
  >,
): DistinctOwnerBlockerSearchResult<TState, TOwner, THopData> => {
  const maxExpandedLabels =
    options.maxExpandedLabels ?? Number.POSITIVE_INFINITY
  if (
    maxExpandedLabels !== Number.POSITIVE_INFINITY &&
    (!Number.isInteger(maxExpandedLabels) || maxExpandedLabels < 0)
  ) {
    throw new Error("maxExpandedLabels must be a non-negative integer")
  }

  const minimumOwnerCount = options.minimumOwnerCount ?? 0
  if (!Number.isInteger(minimumOwnerCount) || minimumOwnerCount < 0) {
    throw new Error("minimumOwnerCount must be a non-negative integer")
  }
  if (options.checkReachability) {
    const disconnected = findDisconnectedSearch(options, maxExpandedLabels)
    if (disconnected) return disconnected
  }
  const labelsByStateKey = new Map<
    TStateKey,
    Array<SearchLabel<TState, TStateKey, TOwner, THopData>>
  >()
  const queue = new SearchLabelQueue<TState, TStateKey, TOwner, THopData>()
  let nextQueueOrder = 0
  let expandedLabelCount = 0
  const startLabel: SearchLabel<TState, TStateKey, TOwner, THopData> = {
    state: options.start,
    stateKey: options.getStateKey(options.start),
    owners: new Set<TOwner>(),
    // Use a global lower bound, not an additional owner on each label.
    priorityOwnerCount: minimumOwnerCount,
    distance: 0,
    estimatedTotalDistance: options.getRemainingDistance
      ? options.getRemainingDistance(options.start)
      : 0,
    parent: null,
    incomingHop: null,
    queueOrder: nextQueueOrder++,
    active: true,
  }
  if (
    !Number.isFinite(startLabel.estimatedTotalDistance) ||
    startLabel.estimatedTotalDistance < 0
  ) {
    throw new Error("Distinct-owner blocker estimates must be finite and >= 0")
  }
  labelsByStateKey.set(startLabel.stateKey, [startLabel])
  queue.push(startLabel)

  while (true) {
    const current = getNextActiveLabel(queue)
    if (current === null) {
      return { found: false, reason: "no_path", expandedLabelCount }
    }
    if (options.isGoal(current.state)) {
      return reconstructSuccessfulSearch(current, expandedLabelCount)
    }
    if (expandedLabelCount >= maxExpandedLabels) {
      return { found: false, reason: "expansion_limit", expandedLabelCount }
    }
    expandedLabelCount++

    for (const hop of options.getHops(current.state)) {
      if (!Number.isFinite(hop.distance) || hop.distance < 0) {
        throw new Error(
          "Distinct-owner blocker hops require finite distances >= 0",
        )
      }

      const distance = current.distance + hop.distance
      if (!Number.isFinite(distance)) {
        throw new Error("Distinct-owner blocker path distance overflowed")
      }
      const stateKey = options.getStateKey(hop.state)
      const queueOrder = nextQueueOrder++
      const existingLabels = labelsByStateKey.get(stateKey) ?? []
      const addedOwners = hop.owners ?? []
      // Most proposed labels are dominated. Test the owner union without
      // allocating a label or copying its owner set for those rejected hops.
      let dominated = false
      for (const label of existingLabels) {
        if (
          label.distance <= distance &&
          isOwnerSubsetOfUnion(label.owners, current.owners, addedOwners)
        ) {
          dominated = true
          break
        }
      }
      if (dominated) continue

      // Labels never mutate their owner set after entering the queue. Most
      // hops encounter no new owner, so share the set until it changes.
      let owners = current.owners
      for (const owner of addedOwners) {
        if (owners.has(owner)) continue
        if (owners === current.owners) owners = new Set(current.owners)
        owners.add(owner)
      }
      const remainingDistance = options.getRemainingDistance
        ? options.getRemainingDistance(hop.state)
        : 0
      const estimatedTotalDistance = distance + remainingDistance
      if (
        !Number.isFinite(remainingDistance) ||
        remainingDistance < 0 ||
        !Number.isFinite(estimatedTotalDistance)
      ) {
        throw new Error(
          "Distinct-owner blocker estimates must be finite and >= 0",
        )
      }
      const candidate: SearchLabel<TState, TStateKey, TOwner, THopData> = {
        state: hop.state,
        stateKey,
        owners,
        priorityOwnerCount: Math.max(minimumOwnerCount, owners.size),
        distance,
        estimatedTotalDistance,
        parent: current,
        incomingHop: hop,
        queueOrder,
        active: true,
      }

      const survivingLabels: Array<
        SearchLabel<TState, TStateKey, TOwner, THopData>
      > = []
      for (const label of existingLabels) {
        if (labelDominates(candidate, label)) {
          label.active = false
        } else {
          survivingLabels.push(label)
        }
      }
      survivingLabels.push(candidate)
      labelsByStateKey.set(candidate.stateKey, survivingLabels)
      queue.push(candidate)
    }
  }
}
