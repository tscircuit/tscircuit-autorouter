import type { NetId, PortId } from "./types"

export function validatePortReservations(
  reservations: Int32Array | undefined,
  portCount: number,
): void {
  if (reservations === undefined) return
  if (!(reservations instanceof Int32Array) || reservations.length !== portCount) {
    throw new Error("portReservationNetId must be an Int32Array matching portCount")
  }
  for (let portId = 0; portId < reservations.length; portId++) {
    if (reservations[portId]! < -2) {
      throw new Error(`Invalid portReservationNetId at port ${portId}`)
    }
  }
}

export function isPortPhysicallyReservedForDifferentNet(
  reservations: Int32Array | undefined,
  routeNetId: NetId | undefined,
  portId: PortId,
): boolean {
  if (reservations === undefined) return false
  if (!Number.isInteger(portId) || portId < 0 || portId >= reservations.length) {
    throw new Error(`Invalid physical reservation port ${portId}`)
  }
  const reservedNetId = reservations[portId]!
  if (reservedNetId < -2) {
    throw new Error(`Invalid portReservationNetId at port ${portId}`)
  }
  return reservedNetId === -2 || (reservedNetId !== -1 && reservedNetId !== routeNetId)
}
