import { mkdirSync, readdirSync, writeFileSync } from "node:fs"
import { join } from "node:path"
import { RootCircuit } from "tscircuit"

const geometryOnly = process.argv.includes("--geometry-only")
const requested = process.argv.slice(2).find((arg) => !arg.startsWith("--"))
const boards = readdirSync(new URL("./boards/", import.meta.url)).filter((name) => name.endsWith(".tsx"))
if (!requested || requested === "--list") {
  console.log(boards.map((name) => name.slice(0, -4)).join("\n"))
  process.exit(0)
}
const filename = `${requested}.tsx`
if (!boards.includes(filename)) throw new Error(`Unknown board: ${requested}`)
const { default: Board } = await import(new URL(`./boards/${filename}`, import.meta.url).href)
const circuit = new RootCircuit()
circuit.add(<Board geometryOnly={geometryOnly} />)
await circuit.renderUntilSettled()
const out = new URL("./output/", import.meta.url)
mkdirSync(out, { recursive: true })
writeFileSync(new URL(`${requested}.circuit.json`, out), JSON.stringify(circuit.getCircuitJson()))
console.log(`Saved output/${requested}.circuit.json`)
