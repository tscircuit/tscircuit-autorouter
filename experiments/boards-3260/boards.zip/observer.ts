import {appendFileSync, writeFileSync, readFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {resolve} from 'node:path'
const dir=process.env.BOARD_RUN_OUT!
const started=performance.now()
const log=(key:string,payload:any)=>appendFileSync(resolve(dir,'events.jsonl'),JSON.stringify({key,seconds:(performance.now()-started)/1000,...payload})+'\n')
const classes=new WeakMap()
let index=0
;(globalThis as any).__observeFanout=(Base:any)=>{
 if(classes.has(Base))return classes.get(Base)
 class Observed extends Base {
  _step(...args:any[]) {
   const result=super._step(...args)
   if(performance.now()-(this.__lastCheckpoint??0)>30000){
    this.__lastCheckpoint=performance.now()
    log('fanout-progress',{iterations:this.iterations,attempts:this.attempts.length,best:this.bestAttempt?.plans.length})
    if(this.bestAttempt)writeFileSync(resolve(dir,'fanout-checkpoint.json.gz'),gzipSync(JSON.stringify({plans:this.bestAttempt.plans,output:this.bestAttempt.outputSrj,summary:this.bestAttempt.summary})))
   }
   return result
  }
  solve(...args:any[]){
   const id=++index, cpu=process.cpuUsage(), t=performance.now()
   writeFileSync(resolve(dir,`fanout-${id}-input.json.gz`),gzipSync(JSON.stringify(this.getConstructorParams())))
   try{return super.solve(...args)}finally{
    const used=process.cpuUsage(cpu),best=this.bestAttempt
    log('fanout',{id,wallMs:performance.now()-t,cpuMs:(used.user+used.system)/1000,requests:this.inputSrj.connections.length,solved:this.solved,failed:this.failed,error:this.error,iterations:this.iterations,attempts:this.attempts.length,best:best?.plans.length,summary:best?.summary})
    if(best)writeFileSync(resolve(dir,`fanout-${id}-best.json.gz`),gzipSync(JSON.stringify({plans:best.plans,output:best.outputSrj,summary:best.summary})))
   }
  }
 }
 classes.set(Base,Observed);return Observed
}
Bun.plugin({name:'observe-embedded-fanout',setup(build){build.onLoad({filter:/[/\\]@tscircuit[/\\]core[/\\]dist[/\\]index\.js$/},({path})=>{
 const src=readFileSync(path,'utf8'),needle='new FanoutSolver('
 if(src.split(needle).length!==4)throw Error('Fanout instrumentation sites changed')
 return {contents:src.replaceAll(needle,'new (globalThis.__observeFanout(FanoutSolver))('),loader:'js'}
})}})
const {Pipeline9HighDensitySolver}=await import('@tscircuit/capacity-autorouter')
const densityStep=Pipeline9HighDensitySolver.prototype._step
Pipeline9HighDensitySolver.prototype._step=function(...args){
 let result
 try { result=densityStep.apply(this,args) } catch(error) {
  const grow=this.activeFallbackSolver?.highDensitySolver?.activeSubSolver
  const portfolio=grow?.activeSubSolver
  const candidate=portfolio?.activeSubSolver
  log('density-exception',{error:String(error),node:this.activeNode?.capacityMeshNodeId,candidate:candidate?.getSolverName?.(),iterations:this.iterations})
  writeFileSync(resolve(dir,`density-exception-${Date.now()}.json.gz`),gzipSync(JSON.stringify({params:this.params,activeNode:this.activeNode,growth:grow?.scaleFactor,candidateName:candidate?.constructor.name,candidateParams:candidate?.getConstructorParams?.()})))
  throw error
 }
 if(this.failed&&!this.__capturedFailure){
  this.__capturedFailure=true
  const failures=this.failedSolvers??[]
  log('density-failure',{error:this.error,failed:failures.map(s=>({name:s.getSolverName?.(),error:s.error,iterations:s.iterations}))})
  const leaf=failures.findLast(s=>s.cellCenterX&&s.activeConnSeg)
  if(leaf)writeFileSync(resolve(dir,`density-${Date.now()}.json.gz`),gzipSync(JSON.stringify({error:leaf.error,node:leaf.getConstructorParams()[0],stats:leaf.gridStats,iterations:leaf.searchIterations})))
 }
 return result
}
const {AutoroutingPipelineSolver9_PreloadedTraceGraph}=await import('@tscircuit/capacity-autorouter')
const pipelineStep=AutoroutingPipelineSolver9_PreloadedTraceGraph.prototype._step
let pipelineIndex=0
const observedGraphs=new WeakSet()
AutoroutingPipelineSolver9_PreloadedTraceGraph.prototype._step=function(...args){
 this.__boardPipelineId??=++pipelineIndex
 const phase=this.getCurrentPhase()
 if(phase!==this.__boardPhase){
  this.__boardPhase=phase
  log('pipeline-stage',{pipeline:this.__boardPipelineId,phase,iterations:this.iterations})
  if(this.activeSubSolver&&/pathing|density/i.test(phase)){
   try{
    const params=this.activeSubSolver.getConstructorParams()
    writeFileSync(resolve(dir,`pipeline-${this.__boardPipelineId}-${phase}.json.gz`),gzipSync(JSON.stringify(params)))
   }catch(error){log('capture-error',{phase,message:String(error)})}
  }
 }
 const result=pipelineStep.apply(this,args)
 const active=this.activeSubSolver
 if(active&&active!==this.__capturedStageChild&&/uniformPortDistributionSolver|highDensityRouteSolver/.test(this.getCurrentPhase())) {
  this.__capturedStageChild=active
  const params=active.params??active.input
  if(params)writeFileSync(resolve(dir,`stage-${this.__boardPipelineId}-${this.getCurrentPhase()}.json.gz`),gzipSync(JSON.stringify(params)))
 }
 const hd=this.highDensityRouteSolver
 if(hd&&!hd.solved&&!hd.failed&&performance.now()-(this.__lastDensityProgress??0)>30000) {
  this.__lastDensityProgress=performance.now()
  log('density-progress',{pipeline:this.__boardPipelineId,iterations:hd.iterations,stats:hd.stats,node:hd.activeNode?.capacityMeshNodeId,child:hd.activeSubSolver?.getSolverName?.(),b01:hd.activeB01Solver?.error,regional:hd.activeFallbackSolver?.error})
 }
 const pathing=this.portPointPathingSolver
 const tiny=pathing?.tinyPipelineSolver
 const graph=tiny?.getSolver('solveGraph')
 if(graph&&!observedGraphs.has(graph)){
  observedGraphs.add(graph)
  const id=this.__boardPipelineId
  const ordinal=this.__boardGraphOrdinal=(this.__boardGraphOrdinal??0)+1
  writeFileSync(resolve(dir,`graph-${id}-${ordinal}-input.json.gz`),gzipSync(JSON.stringify({topology:graph.topology,problem:graph.problem,options:tiny.getSolveGraphOptions()},(_key,item)=>typeof item==='number'&&!Number.isFinite(item)?{number:String(item)}:ArrayBuffer.isView(item)?{typedArray:item.constructor.name,values:Array.from(item)}:item)))
  log('graph-created',{pipeline:id,graph:ordinal,routes:graph.problem.routeCount,ports:graph.topology.portCount,regions:graph.topology.regionCount,iterations:graph.iterations,reservedPorts:Array.from(graph.problem.portReservationNetId??[]).filter(n=>n>=0).length})
  const create=graph.createGreedyFinalRouteSolver
  graph.createGreedyFinalRouteSolver=function(options,attempt){
   const child=create.call(this,options,attempt)
   const reset=child.resetRoutingStateForRerip
   child.resetRoutingStateForRerip=function(){
    const before=this.state.unroutedRoutes.length+Number(this.state.currentRouteId!==undefined)
    const result=reset.call(this)
    log('graph-reset',{pipeline:id,graph:ordinal,attempt,before,after:this.state.unroutedRoutes.length+Number(this.state.currentRouteId!==undefined),rips:this.state.ripCount,budget:this.remainingReripBudget})
    return result
   }
   const solve=child.solve
   child.solve=function(){
    const result=solve.call(this)
    log('graph-finisher',{pipeline:id,graph:ordinal,attempt,pending:this.state.unroutedRoutes.length+Number(this.state.currentRouteId!==undefined),solved:this.solved,failed:this.failed,error:this.error,rips:this.state.ripCount,iterations:this.iterations})
    return result
   }
   return child
  }
 }
 if(this.failed)log('pipeline-failure',{pipeline:this.__boardPipelineId,phase,error:this.error,childError:this.activeSubSolver?.error,iterations:this.iterations})
 return result
}
const {RootCircuit}=await import('tscircuit')
const add=RootCircuit.prototype.add, seen=new WeakSet()
RootCircuit.prototype.add=function(...args){
 if(!seen.has(this)){
  seen.add(this)
  for(const phase of ['start','end','error'] as const)this.on(`autorouting:${phase}`,(event:any)=>{
   const {simpleRouteJson,debugGraphics,pcbTracePaths,...record}=event
   log(phase,{...record,traceCount:simpleRouteJson?.traces?.length,paths:pcbTracePaths?.length,obstaclesWithoutCircuitMetadata:simpleRouteJson?.obstacles?.filter(o=>!o.circuitJsonMetadata).length,fixedTraceCount:simpleRouteJson?.traces?.filter(t=>t.isFixed).length})
   if(simpleRouteJson)writeFileSync(resolve(dir,`${phase}-${event.phaseOrdinal??event.autorouterName??'router'}.srj.json.gz`),gzipSync(JSON.stringify(simpleRouteJson)))
  })
 }
 return add.apply(this,args)
}
