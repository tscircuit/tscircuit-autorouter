import source from "../local/ecp5.json"
import { NativeFullBoard, type NativeFullBoardSource } from "../local/native-full-board"

export default function Board({ geometryOnly = false }: { geometryOnly?: boolean } = {}) {
  return <NativeFullBoard source={source as NativeFullBoardSource} geometryOnly={geometryOnly} />
}
