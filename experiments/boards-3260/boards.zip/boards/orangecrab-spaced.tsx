import source from "../spaced/ecp5.json"
import { NativeFullBoard, type NativeFullBoardSource } from "../spaced/native-full-board"

export default function Board({ geometryOnly = false }: { geometryOnly?: boolean } = {}) {
  return <NativeFullBoard source={source as NativeFullBoardSource} geometryOnly={geometryOnly} />
}
