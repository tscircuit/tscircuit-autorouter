import source from "../spaced/glider.json"
import { NativeFullBoard, type NativeFullBoardSource } from "../spaced/native-full-board"

export default function Board({ geometryOnly = false }: { geometryOnly?: boolean } = {}) {
  return <NativeFullBoard source={source as NativeFullBoardSource} geometryOnly={geometryOnly} />
}
