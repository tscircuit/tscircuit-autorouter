import {appendFileSync, writeFileSync, readFileSync} from 'node:fs'
import {gzipSync} from 'node:zlib'
import {resolve} from 'node:path'
const dir=process.env.BOARD_RUN_OUT!
const started=performance.now()
const log=(key:string,payload:any)=>appendFileSync(resolve(dir,'events.jsonl'),JSON.stringify({key,seconds:(performance.now()-started)/1000,...payload})+'\n')
const classes=new WeakMap()
let index=0
;(globalThis as any).__observeFanout=(Base:any)=>{
 if(classes.has(Base))return classes.get(Base)
 class Observed extends Base {
  _step(...args:any[]) {
   const result=super._step(...args)
   if(performance.now()-(this.__lastCheckpoint??0)>30000){
    this.__lastCheckpoint=performance.now()
    log('fanout-progress',{iterations:this.iterations,attempts:this.attempts.length,best:this.bestAttempt?.plans.length})
    if(this.bestAttempt)writeFileSync(resolve(dir,'fanout-checkpoint.json.gz'),gzipSync(JSON.stringify({plans:this.bestAttempt.plans,output:this.bestAttempt.outputSrj,summary:this.bestAttempt.summary})))
   }
   return result
  }
  solve(...args:any[]){
   const id=++index, cpu=process.cpuUsage(), t=performance.now()
   writeFileSync(resolve(dir,`fanout-${id}-input.json.gz`),gzipSync(JSON.stringify(this.getConstructorParams())))
   try{return super.solve(...args)}finally{
    const used=process.cpuUsage(cpu),best=this.bestAttempt
    log('fanout',{id,wallMs:performance.now()-t,cpuMs:(used.user+used.system)/1000,requests:this.inputSrj.connections.length,solved:this.solved,failed:this.failed,error:this.error,iterations:this.iterations,attempts:this.attempts.length,best:best?.plans.length,summary:best?.summary})
    if(best)writeFileSync(resolve(dir,`fanout-${id}-best.json.gz`),gzipSync(JSON.stringify({plans:best.plans,output:best.outputSrj,summary:best.summary})))
   }
  }
 }
 classes.set(Base,Observed);return Observed
}
Bun.plugin({name:'observe-embedded-fanout',setup(build){build.onLoad({filter:/[/\\]@tscircuit[/\\]core[/\\]dist[/\\]index\.js$/},({path})=>{
 let src=readFileSync(path,'utf8')
 const needle='new FanoutSolver('
 if(process.env.BOARD_ANGLE_FIX==='1'){
  const first='sourceEscapePaths.push([sourcePoint, adjacentViaPoint])'
  if(src.split(first).length!==2)throw Error('Adjacent plane-via site changed')
  src=src.replace(first,'sourceEscapePaths.push(...getStraightOr45ConnectorVariants(sourcePoint, adjacentViaPoint))')
 }
 if(src.split(needle).length!==4)throw Error('Fanout instrumentation sites changed')
 return {contents:src.replaceAll(needle,'new (globalThis.__observeFanout(FanoutSolver))('),loader:'js'}
})}})
const {Pipeline9HighDensitySolver}=await import('@tscircuit/capacity-autorouter')
const densityStep=Pipeline9HighDensitySolver.prototype._step
Pipeline9HighDensitySolver.prototype._step=function(...args){
 const result=densityStep.apply(this,args)
 if(this.failed&&!this.__capturedFailure){
  this.__capturedFailure=true
  const failures=this.failedSolvers??[]
  log('density-failure',{error:this.error,failed:failures.map(s=>({name:s.getSolverName?.(),error:s.error,iterations:s.iterations}))})
  const leaf=failures.findLast(s=>s.cellCenterX&&s.activeConnSeg)
  if(leaf)writeFileSync(resolve(dir,`density-${Date.now()}.json.gz`),gzipSync(JSON.stringify({error:leaf.error,node:leaf.getConstructorParams()[0],stats:leaf.gridStats,iterations:leaf.searchIterations})))
 }
 return result
}
const {RootCircuit}=await import('tscircuit')
const add=RootCircuit.prototype.add, seen=new WeakSet()
RootCircuit.prototype.add=function(...args){
 if(!seen.has(this)){
  seen.add(this)
  for(const phase of ['start','end','error'] as const)this.on(`autorouting:${phase}`,(event:any)=>{
   const {simpleRouteJson,debugGraphics,pcbTracePaths,...record}=event
   log(phase,{...record,traceCount:simpleRouteJson?.traces?.length,paths:pcbTracePaths?.length})
   if(simpleRouteJson)writeFileSync(resolve(dir,`${phase}-${event.phaseOrdinal??event.autorouterName??'router'}.srj.json.gz`),gzipSync(JSON.stringify(simpleRouteJson)))
  })
 }
 return add.apply(this,args)
}
